package spring_web10;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SurveyController {

	@RequestMapping(value="/survey/survey.hbi")
	public String processStep1() {
		return "surveyForm";
	}
	
	@RequestMapping(value="/survey/surveyOk.hbi")
	public String processStep2(HttpServletRequest req) {
		
		String img [] = req.getParameterValues("ck");
		
		req.setAttribute("img", img);
		
		return "submmited";
	}
}
