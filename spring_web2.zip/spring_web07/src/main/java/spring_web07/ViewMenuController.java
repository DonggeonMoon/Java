package spring_web07;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ViewMenuController {

	@RequestMapping(value = "viewData.do")
	public String show(HttpServletRequest req) {
		
		String data = req.getParameter("message");
		
		req.setAttribute("message", data);
		
		return "view"; //-> /jsp/view.jsp
	}
}
