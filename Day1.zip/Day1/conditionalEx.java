package Day1;

public class conditionalEx {

	public static void main(String[] args) {
		int a = 5 - (int)(Math.random() * 10);
		//Math.random(): 0 ~ 1 사이의 임의 수를 발생 시킴
		//5-(0~10)
		int abs = (a>0)? a : - a;
		System.out.println(a + "의 절댓값은 : " + abs);
		//절댓값은 부호를 제외한 값..
	}

}
