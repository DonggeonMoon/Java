package Day1;

public class BooleanEx {

	public static void main(String[] args) {
		boolean one = false;
		boolean five = true;
		//boolean two = False; //F 대문자라서 에러
		//boolean three = "false"; // "문자열"이라 에러
		//boolean four = 1;// 정수라서 에러
		
		System.out.println(one);
		System.out.println(five);

	}

}
