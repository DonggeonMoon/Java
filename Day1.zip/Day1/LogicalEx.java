package Day1;

public class LogicalEx {

	public static void main(String[] args) {
		// & , + 하나씩만 썼을 경우 결과 값이 누적되어 연산이 된다.
		int x = 10, y = 20;
		if ((x != 10) & (++y == 21)) {
			System.out.println("true");
		}else { 
			System.out.println("false");
		}
		
		System.out.println("x:" + x + "y:" + y);
		
		if((x==10) | (++y) == 21) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
		
		System.out.println("x:" + x + "y:" + y);
		
		// &&, ||는 조건식에서만 연산되고 외부에서는 연산된 값이 반영 안 됨
		int a = 10, b = 20;
		
		if ((a != 10 ) && (++b == 21)) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
		System.out.println("a:" + a + "b:" + b);
		
		if ((a == 10 ) && (++b == 21)) {
			System.out.println("true");
		} else {
			System.out.println("false");
		}
		System.out.println("a:" + a + "b:" + b);
	}
}
