package Day1;
/*
 byte a = 10; -128~127
 int b = a; // promotion 묵시적 형변환 -2억 ~21억
 int c = 10;
 byte d = a;//에러 발생 
 byte d = (byte) c; 명시적으로 써야 한다. 
 
 */
public class TypeCastEx {

	public static void main(String[] args) {
		byte a = 100;
		int b = a;//묵시적 형 변환
		byte c = (byte) b;
		System.out.printf("%d, %d, %d", a, b, c);
		
		int x = 1522;
		byte y = (byte) x;// -128 ~ 127, 형 변환 시에 변환할 데이터 타입의 범위 주의
		System.out.println(y);
		
		double d = 3.6;
		int z = (int) d;// 실수를 정수로 casting하면 실수부가 버림당함.
		System.out.println(z);

	}

}
