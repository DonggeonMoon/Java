package Day1;

public class BitNotEx {

	public static void main(String[] args) {
		byte binData = 0b0000_1000;
		
		System.out.println(binData);// 1000 - > 8
		System.out.println(~binData);// ~반전 시켜라 0b1111_0111 ->  
		
		boolean isTrue = false;
		System.out.println(!isTrue);// false <-> true

	}

}
