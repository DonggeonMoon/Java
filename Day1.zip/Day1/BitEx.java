package Day1;
/*
 & : AND, 두 비트 전부 1일 때, 나머지는 0
 | : OR, 두 비트 중 하나 이상 1이면 1, 두비트 전부 0이면 0
 ^ : XOR(익스클루시브 오어), 두 비트가 다를 때 1, 두 비트가 같으면 0
 */
public class BitEx {

	public static void main(String[] args) {
		byte a = 5;// 0101
		byte b = 3;// 0011 
		System.out.println(a&b);// 0001 ->1
		System.out.println(a|b);// |\쉬프트하면 나온다. 0111 -> 7
		System.out.println(a^b);// 0110 -> 6
		

	}

}
