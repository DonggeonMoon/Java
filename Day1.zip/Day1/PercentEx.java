package Day1;

public class PercentEx {
	public static void main(String[]arg) {
		for (int i = 0; i<=100; i ++) {
			if (i%3 == 0) {
				System.out.println(i);
			}
		}
	}
}
