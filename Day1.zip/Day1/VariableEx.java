package Day1;

public class VariableEx {

	public static void main(String[] args) {
		int decimalValue = 7; //10진수 진수 0 ~ 9까지 그보다 커지면 다음 자리 올림. 
		int binValue = 0b1000_0101; //이진수 0b로 시작 0~1까지 그보다 커지면 다음 자리 올림.
		int octaValue = 077; // 8진수 0~7까지 그보다 커지면 다음 자리 올림.
		int hexaValue = 0xFEFE; //16진수 0x로 시작 0~9, a, b, c, d, e, f까지 그보다 커지면 다음 자리 올림. 
		
		System.out.println("10진수 7은 : " + decimalValue);
		System.out.println("2진수 0b1000_0101은 : " + binValue);
		System.out.println("8진수 077은 : " + octaValue);
		System.out.println("16진수 0xFEFE은 : " + hexaValue);
		
		byte a = 127; // -128 ~ 127 범위 주의, 0이 있어서 양수가 하나 더 작다.
		short b = 32767; // -32768~ 32767
		int c = 2147483647;// -2147483648 ~ 214748647 
		long d = 2148483648l;// long은 숫자 뒤에 long형이라 표기해줘야 한다. 
		
		System.out.printf("%d, %d, %d, %d\n", a, b, c, d);

	}

}