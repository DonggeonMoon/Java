package Day1;
// 버건디 색깔은 keyword, 예약어
// 기본자료형도 keyword로 자바가 미리 지정해 놓았다. 
// 금빛 색은 변수이름 

public class CharEx {

	public static void main(String[] args) {
		char one = 'A'; //char형은 ' ' 사용 
		char two = '\t';//tab만 띄어쓰기 
		char three = '\uAC00';// 가, char = ㅋ드값이 매칭되어 있다. 
		String four = "\uD604\uC218"; // 현수
		String five = "dream";// 문자열은" " 안에 기술한다. 엄밀히 말해 기본 자료형은 아니다. dream
		
		System.out.printf("%c, %c, %c, %s, %s", one, two, three, four, five);
		
		System.out.println("-------------------------------");
		//문자열 + 연산은 abc + def = abcdef 이어서 찍는 역할을 한다.
		System.out.println(100+200);//() 블럭 안에서 연산 처리가 가능
		System.out.println(100+"200");// "문자열" "200" 숫자가 아니고 문자이공공이다. 
		System.out.println(100+200+"Hello"); 
		System.out.println("Hello"+100+200);// hello100200 왜? 문자열이 먼저나오면 다음 숫자도 무조건 문자열로 자동변환된다.
		System.out.println("Hello"+(100+200));
		System.out.println('A' + 10);// 'A' 숫자 6이다.
	}

}
