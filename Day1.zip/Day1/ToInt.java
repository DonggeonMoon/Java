package Day1;
//반올림, 올림, 내림, 버림
// 반올림: 0~4 버림, 5~9 올림, 올림:무조건 올림, 내림: 무조건 내림, 버림: 무조건 버림
public class ToInt {

	public static void main(String[] args) {
		double a = -3.6;
		double b = -3.4;
		double c = 3.4;
		double d = 3.6;
		System.out.printf("%d, %d, %d, %d", Math.round(a), Math.round(b), Math.round(c), Math.round(d));
		//Math.round() Math클래스의 round 메서드를 호출한 거다.
		System.out.println();
		
		System.out.printf("%.1f %.1f %.1f %.1f", Math.ceil(a), Math.ceil(b), Math.ceil(c), Math.ceil(d));
		System.out.println();
		System.out.printf("%.1f %.1f %.1f %.1f", Math.floor(a), Math.floor(b), Math.floor(c), Math.floor(d));
		System.out.println();
		System.out.printf("%d, %d, %d, %d", (int) a, (int) b, (int) c, (int) d);
	}

}
