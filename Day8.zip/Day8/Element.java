package Day8;

public class Element {
	
	int atomicNumber;

}
