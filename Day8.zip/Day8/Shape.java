package Day8;

public interface Shape {

	void draw();
	void save();
}
