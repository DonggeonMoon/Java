package Day8;

public class Day7Man extends Day7 implements Day7Interface, Day7Inter2 {
	public Day7Man() {
		this("이름 없음", "주번 없음", "나이 없음");
	}
	public Day7Man(String name, String juminId, String age) {
		super.name = name;
		super.juminId = juminId;
		super.age = age;
	}

	@Override
	void eat() {
		System.out.println("남자가 밥을 먹습니다.");
		
	}

	@Override
	void sleep() {
		System.out.println("남자가 잠을 잡니다.");
		
	}
	
	@Override
	public void work() {
		System.out.println("일을 합니다.");
		
	}
	@Override
	public void play() {
		System.out.println("놀고 있습니다.");
		
	}
	@Override
	public void meeting() {
		System.out.println("미팅을 합니다.");
		
	}

}
