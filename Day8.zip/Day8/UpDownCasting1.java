package Day8;

import java.util.Vector;
//<>안에 데이터  타입이 기록된다.

public class UpDownCasting1 {
	
	public static void main(String[] args) {
		String name = new String("홍길동");
		Integer id = new Integer(1000);
		Vector <String> v = new Vector<String>();
		Vector <Integer> v2 = new Vector<Integer>();
		
		v.addElement(name);
		v2.addElement(id);
		
		// Object obj = v.elementAt(0);
		// String str1 = (String)obj;
		String str = v.elementAt(0);
		int num = v2.elementAt(0);
		
		System.out.println("이름:" + str + "번호: " + num);
	}
}
