package Day8;

public class ShapeEx {

	public static void main(String[] args) {
		
		Circle c = new Circle(5.0);
		Triangle t = new Triangle(5, 6);
		Rectangle r = new Rectangle(5, 6);
		
		c.draw();
		c.save();
		System.out.println("원의 반지름은: "+ c.getRadius() + "\n원의 넓이는: " + c.getArea() + "입니다.\n");
		
		t.draw();
		t.save();
		System.out.println("삼각형의 너비는: " + t.getWidth() + "\n삼각형의 높이: " + t.getHeight() + "\n삼각형의 넓이는: " + t.getArea() + "입니다.\n");
		
		r.draw();
		r.save();
		System.out.println("사각형의 너비는: " + r.getWidth() + "\n사각형의 높이는: " + r.getHeight() +  "\n사각형의 넓이는: " + r.getArea() + "입니다.\n");

	}

}
