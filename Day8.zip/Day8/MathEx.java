package Day8;

public class MathEx {

	public static void main(String[] args) {
		System.out.println("-10의 절댓값: " + Math.abs(-10));
		System.out.println("10.0dml 절대값:" + Math.abs(10.0));
		System.out.println("큰 값을 반환: " + Math.max(30, 60));
		System.out.println("작은 값을 반환" +  Math.min(10.0, 20.0));
		System.out.println(("Ceil값 반환" + Math.ceil(-10.3)));
		//매개변수보다 큰 정수 중에 가장 작은 정수.
		System.out.println(("Ceil값 반환" + Math.ceil(10.3)));
		System.out.println(("floor값 반환") + Math.floor(3.2));
		//매개변수보다 작은 정수 중에 가장 큰 정수.
		System.out.println(("floor값 반환") + Math.floor(-3.2));
		System.out.println("rint 값 반환" + Math.rint(-3.54));
		System.out.println("random값 반환" + Math.random());
		System.out.println("원주율값 반환" + Math.PI);
	}

}
