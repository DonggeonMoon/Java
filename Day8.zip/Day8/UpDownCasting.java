package Day8;

import java.util.Vector;
import Day8.SeaAirplane.*;
// java. util 패키지의 vector라는 클래스의 기능을 불러옴.

public class UpDownCasting {
	public static void main() {
		String name = new String("홍길동");// String 자료형의 class
		Integer id = new Integer(1000);
		//Integer: int Wrapper class
		//int 자료형을 객체로 생성할 필요성이 있을 때 사용한다.
		Vector v = new Vector();//Object형 자료의 저장 공간.
		
		v.addElement(name);//v에 자료를 추가 -> String형
		v.addElement(id);//v에 자료를 추가 -> Integer형
		
		//upcasting
		Object obj1= v.elementAt(0);//String
		Object obj2= v.elementAt(1);//Integer형 id
		
		//downcasting, 원래는 불가, 
		String str = (String) obj1; // 형 변환 obj1이 가지고 있는 값이: String name
		int num = (Integer) obj2;// obj2 값: Integer id
		System.out.println("이름:" + str + " 번호: " + num);
		
	}
}