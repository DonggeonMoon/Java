package Day8;

public class practice {
	public static void main(String[] args) {
		/* 원시(primitive) 자료형 */
		boolean b;// 불리언형: 1bit
		byte B;// 바이트형: 1byte
		char c;// 문자형: 2byte
		short s;// 쇼트형: 2byte
		int i;// 정수형: 4byte
		long l;//롱형: 8byte
		float f;// 플로트형: 4byte
		double d;// 더블형: 8byte
		/////////////////////////
		/* 참조(reference) 자료형 */
		String S;
	}
	
}
