package Day8;

public class Rectangle implements Shape {
	private double area;
	private double width, height;
	
	public Rectangle(double width, double height) {
		this.width = width;
		this.height = height;
	}
	
	@Override
	public void draw() {
		System.out.println("사각형을 그립니다. 사각형의 넓이는:" + (width * height) + "입니다.");
	}
	
	@Override
	public void save() {
		double a = (width * height);
		setArea(a);
	}

	public void setArea(double area) {
		this.area = area;
	}

	public double getWidth() {
		return width;
	}
	
	public double getHeight() {
		return height;
	}
	
	public double getArea() {
		return area;
	}


}
