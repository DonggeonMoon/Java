package Day8;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateEx {
	
	public static void main(String[] args) {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH-mm-ss");
		//yyyy: 년, MM: 월, dd:일, HH: 시, mm:분, ss:초
		System.out.println(date.toString());
		System.out.println(date.getTime());
		// 초로 값을 리턴해줌 1970 1월 1일 기준.
		System.out.println(sdf.format(date));
	}

}
