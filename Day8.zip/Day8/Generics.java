package Day8;

import java.util.ArrayList;
//java.util 패키지의 ArrayList라는 클래스를 불러다가 사용하겠다는 의미
public class Generics {
	
	public static void mains(String[] args) {
		
		ArrayList<String> lists = new ArrayList<String>();
		//<> 제네릭 <> 안에 "기술된 자료형만 입력 받겠다는 의미
		
		lists.add("first");
		lists.add("second");
		lists.add("third");
		//lists.add(new Integer(4)); String만 입력 가능하며 int는 입력 불가
		//lists.add(new Float(5.0f)); String만 입력 가능하며 float는 입력 불가
		
		for(String s: lists) {
			System.out.println(s);
		}
		
	}

}
