package Day8;

public class SystemEx {
	public static void main(String[] args) {
		long start, end;
		start = System.currentTimeMillis();
		System.out.println("현재 시간" + start);
		System.out.println("500,000회의 Loop을 반복 시작");
		for(int i = 0; i < 500000; i++) ;
		System.out.println("500,000회의 Loop을 반복 종료");
		end = System.currentTimeMillis();
		System.out.println("반복 종료 시간:" + end);
		System.out.println("반복에 소요된 시간: " + (end-start));		
	}
}
