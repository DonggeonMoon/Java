package Day8.SeaAirplane;

public abstract class Plane {
	public abstract void fly();
	public abstract int power();
}
