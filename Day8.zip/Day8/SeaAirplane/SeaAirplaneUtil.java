package Day8.SeaAirplane;

public class SeaAirplaneUtil {
	public static void show(Plane p) {
		System.out.println(p.power());
		p.fly();		
	}// overloading: 같은 클래스 , 매객변수의 타입 또는 개수의 차이로 성립
	public static void show(Ship s) {
		System.out.println(s.move() + "명을 태우고");
		System.out.println(s.carry()+ "kg의 짐을 싣고 가고 있다.");
	}
	public static void show(SeaAirplane s) {
		System.out.println(s);
	}
	public static void showOnly(Ship s) {
		System.out.println(s.move() + "명을 태우고");
		System.out.println(s.carry()+ "kg의 짐을 싣고 가고 있다.");
	}//Ship형 객체만 받겠다. Sea Airplane ship을 implements 했으니 
	// ship형 객체에 해당된다.
	
	public static void showPlane(Plane p) {
		System.out.println(p.power());
		p.fly();
	}// Plane형 객체만 받겠다. SeaAirplane이 Plane을 extends했으니
	 //Plane형 객체에도 해당된다. 
}
