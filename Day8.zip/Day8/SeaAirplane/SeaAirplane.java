package Day8.SeaAirplane;

public class SeaAirplane extends Plane implements Ship {
	private String id = "Air Balls";
	
	public SeaAirplane(){ 
		this.id = "LeeMass";
	}
	
	public SeaAirplane(String id) {
		this.id = id;
	}
	@Override
	public int move() {
		return 5;// 다섯 명을 태운다.
	}
	@Override
	public int carry() {
		return 300;// 300kg을 싣는다.
	}
	@Override
	public void fly() {
		System.out.println("엔진의 힘을 날아감");
		
	}
	@Override
	public int power() {
		return 10000;// 100000마력
	}
	
	public String toString() {
		return this.id + "가" + power() + "마력으로 " + move() + "명과 " + carry() + "kg의 짐을 싣고 날아간다.";
	}
}
