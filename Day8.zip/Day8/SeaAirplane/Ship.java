package Day8.SeaAirplane;

public interface Ship {
	
	int move();//승객을 몇 명 태우는가 -> 추상 메서드(public abstract 생략)
	int carry();//짐을 몇 kg 싣는가 -> 추상 메서드(public abstract 생략)

}
