package Day8.SeaAirplane;

public class SeaplaneEx {

	public static void main(String[] args) {
		SeaAirplane sea = new SeaAirplane("CS110");
		Plane p = sea;// 다형성: 부모는 자식의 객체 형태로 객체 생성이 가능
		Ship s = sea; // Plane: abstract class, Ship: interface
		
		SeaAirplaneUtil.show(sea);// SeaAirplane형 객체를 매개변수로 받는 show() 동작
		SeaAirplaneUtil.show(s);// Ship형 객체를 매개변수로 받는 show() 동작
		SeaAirplaneUtil.show(p);// Plane형 객체를 매개변수로 받는 show() 동작
		
		SeaAirplaneUtil.showOnly(sea);//Ship 타이, ship을 implements했으니까 매개변수 대입 가능
		SeaAirplaneUtil.showPlane(sea);//Plane 타입, Plane을 extends했으니까 매개변수 대입 가능
	}
}
