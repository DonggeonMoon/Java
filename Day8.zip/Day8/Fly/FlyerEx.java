package Day8.Fly;

public class FlyerEx {
	
	public static void main(String[] args) {
		System.out.println(Flyer.FAST);//final static 바로 호출가능.
		
		Bird b = new Bird();
		b.fly();
		b.isAnimal();
		FlyerUtil.show(b); //static이니까 객체를 인스턴스하지 않고 바로 호출 가능.
		
		Flyer f = new Bird();
		f.fly();
		f.isAnimal();
		FlyerUtil.show(f);
		
		Flyer ap = new Airplane();
		ap.fly();
		ap.isAnimal();
		FlyerUtil.show(ap);
	}

}
