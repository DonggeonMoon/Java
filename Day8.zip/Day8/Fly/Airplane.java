package Day8.Fly;

public class Airplane implements Flyer {

	@Override
	public void fly() {
		System.out.println("엔진의 힘으로 날아갑니다.");
		
	}

	@Override
	public boolean isAnimal() {
		return true;
	}

}
