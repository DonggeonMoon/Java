package Day8.Fly;

public interface Flyer {
	
	int FAST = 100;
	void fly();
	boolean isAnimal();// isAnimal() ? 동물이니? 
}
