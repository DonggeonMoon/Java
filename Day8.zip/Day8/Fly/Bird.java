package Day8.Fly;

public class Bird implements Flyer {

	@Override
	public void fly() {
		System.out.println("날개짓을 하며 날아감");
		
	}

	@Override
	public boolean isAnimal() {
		return true;
	}

}
