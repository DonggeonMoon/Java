package Day8.Fly;

public class FlyerUtil {
	public static void show(Flyer f) { //Flyer 인터페이스는 자식의 객체를 담을 수 있은 매개변수로 사용 가능하다.
		f.fly();
		System.out.println(f.isAnimal());
	}

}
