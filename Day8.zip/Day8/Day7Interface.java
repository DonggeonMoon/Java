package Day8;
// interface: 선언된 변수는 무조건 상수가 된다.
// 선언된 메서드는 무조건 추상메서드가 된다.
// implements 키워드 사용한다.

public interface Day7Interface {
	
	double HEIGHT = 178.5; // final static: 상수, 생략 가능
	double WEIGHT = 75.3; // final static은 상수화 된다.
	
	void work();//public abstract가 생략됨.
	void play();

}
