package Day8;

public class Day7Woman extends Day7 {
	public Day7Woman() {
		this("이름 없음", "주번 없음", "나이 없음");
	}
	public Day7Woman(String name, String juminId, String age) {
		super.name = name;
		super.juminId = juminId;
		super.age = age;
	}

	@Override
	void eat() {
		System.out.println("여자가 밥을 먹습니다.");
		
	}

	@Override
	void sleep() {
		System.out.println("여자가 잠을 잡니다.");
		
	}

}
