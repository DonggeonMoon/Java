package Day8;

public class Circle implements Shape {
	private double area;
	private double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	@Override
	public void draw() {
		System.out.println("원을 그립니다. 원의 넓이는:" + (radius * radius * Math.PI) + "입니다.");
	}
	
	@Override
	public void save() {
		double a = (radius * radius * Math.PI);
		setArea(a);
	}
	
	public void setArea(double area) {
		this.area = area;
	}
	
	public double getRadius() {
		return radius;
	}	

	public double getArea() {
		return area;
	}


	
	

}
