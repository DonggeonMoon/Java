package Day8;
//instanceof: 객체 비교 연산자. a instanceof b -> a가 b형 객체이니?

public class InstanceOfTest {
	
	public static void main(String[] args) {
		Element e = new Element();
		Point p = new Point();
		
		if (e instanceof Point) {
			System.out.println("e는 Point형 객체입니다.");			
		} else {
			System.out.println("e는 Element형 객체입니다.");
		}
		if( p instanceof Point) {
			System.out.println("p는 Point형 객체입니다.");
		} else {
			System.out.println(("는 Element형 객체입니다."));
		}
	}
}
