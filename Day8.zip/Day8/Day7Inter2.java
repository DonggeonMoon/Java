package Day8;

public interface Day7Inter2 {
	default void meeting() {
	}

}
