package Day8;

public class Point extends Element{
	
	int x, y;

}
