package Day8;

public class Day7Ex {
	public static void main(String[] args) {
		//Day7 d7 = new Day7();//Day7은 추상클래스이므로 인스턴스 생성 불가
		Day7Man man = new Day7Man("홍길동", "901102-1124809", "32");
		Day7Woman woman = new Day7Woman("신사임당", "921012-2022343", "30");
		//Day7Interface di = new Day7Interface();//Day7은 인터페이스이므로 인스턴스 생성 불가
		Day7Inter2 di2;
		
		
		System.out.println("남자 이름: " + man.name + " 주번: "+ man.juminId + " 나이: " + man.age);
		System.out.println("여자 이름: " + man.name + " 주번: "+ man.juminId + " 나이: " + man.age);
		man.eat();
		man.sleep();
		man.meeting();
		
		woman.eat();
		woman.sleep();
	}
}
