package Day8;
// 추상클래스: 추상 메서드가 하나라도 있으면 추상클라스가 되어야 한다.
// 추상클래스라고 해서 반드시 추상메서드가 있어야 되는 것은 아니다.
// 추상클래스는 자기 자신의 객체를 가지지 모샇ㄴ다. extends로 상속받아야 한다.
// 

public abstract class Day7 {
	
	String juminId;
	String name;
	String age;
	
	abstract void eat();
	abstract void sleep();
}
