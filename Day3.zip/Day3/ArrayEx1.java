package Day3;

public class ArrayEx1 {
	public static void main(String[] args) {
		char[] s = new char[5];//선언과 동시에 생성
		s[0] = 'A';
		s[1] = 'B';
		s[2] = 'C';
		s[3] = 'D';
		s[4] = 'E';
		
		String[] weekend = new String[7];
		weekend[0] = "일요일";
		weekend[1] = "월요일";
		weekend[2] = "화요일";
		weekend[3] = "수요일";
		weekend[4] = "목요일";
		weekend[5] = "금요일";
		weekend[6] = "토요일";
		
		
		String [] weekend1 = {"일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"};
		
		//Sting[] weekend1이 선언과 동시에 7개 짜리 배열로 생성이 되고, {내용으로} 초기화 된다.
		
		
		for (int i = 0; i<weekend.length; i++) {
			System.out.println(weekend1[i] + " ");	
		}// 일반적인 for문, 보통 많이 사용
		
		for (String str : weekend) { //weekend[0]~[6] 요소를 String str이 차례대로 받아서 출력
			System.out.println(str + " ");
		} //Enhanced for문, 향상된 for문
		
		
	}
}
