package Day3;
//Lotto 6자리 수가 일치하면 1등, 번호를 6개 추출해서 선택
public class Lotto {
	public static void main(String[] args) {
		int lotto[] = {0,0,0,0,0,0};
		int index = 0;
		
		while(true) {// 무한 루프
			int random = (int) (Math.random() * 45 + 1);
			// math.random() 0~1 사이의 임의의 수가 발생, 1~45
			System.out.print(random + " ");
			
			int i = 0;
			for (i=0;i<index; i++) {
				if (random == lotto[i]) { //추첨된 번호니까 탈출해라. 겹치는 것 있으면 탈출, 아니면 그냥 탈출
					break;
				}
			}
			
			if(index == i) {
				lotto[index++] = random;
			}
			
			if(index>5) break;
			
		}
		
		for(int i=0; i<lotto.length;i++) {
			System.out.print(lotto[i] + " ");
		}
	}

}
