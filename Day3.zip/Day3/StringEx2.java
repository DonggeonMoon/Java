package Day3;
//ascii 코드 : A~Z. a~z, 숫자, 일부 스튜디오
// 바이트 비열은 String 변수로 받으면 숫자의 값이 aschi
public class StringEx2 {
	public static void main(String[] args) {
		byte a[] = {66, 85, 83, 65, 78};
		System.out.println("초기 바이트 배열: {66, 85, 83, 65, 78}");
		String a1 = new String(a);
		String a2 = new String(a, 2, 3);
		System.out.println("byte형 배열을 문자열로 변환: " + a[1]);
		System.out.println("byte형 배열을 문자열로 변환: " + a[2]);
		System.out.println(a1);
		System.out.println(a2);
	}

}
