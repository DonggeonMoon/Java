package Day3;

//void : 없다, 자바: 리턴 타입이 없다., swap: 바꾸다
public class Swap {
	static void swap(int x, int y ) {
		int temp;
		temp = x;// temp == x
		x = y;// x = y
		y = temp;// y = x
		System.out.println("swap x:" + x + " swap y: " + y);
	}
	//접근제한자 반환형 메서드이름(매개변수 개수, 타입 선언)
	// return 반환형 타입 변수값
	static int add(int x, int y) {
		return x + y;
	}
	public static double devide(double x, double y) {
		return x / y;
	}

	
	
	public static void main(String[] args) {
		int x = 10;
		int y = 20;

		swap(x, y);
		
		int a = 10;
		int b = 20; 
		int c = add(x, y);
		
		System.out.println("c의 값은 : " + c);
		
		double d = devide(a, b);
		System.out.println("d의 값은 : " + d);
	}
}

