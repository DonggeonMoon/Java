package Day3;
// 참조값: reference type : call(copy) by reference
// reference type (객체형 자료형) : 값이 복사되는 것이 아니고 객체 자료에 주소값이 복사
//array1의 Java Virtual Machine의 heap memory
//-> @2401f4c3 주소값에 array1 배열이 int[8]개만큼의 공간으로 존재
//copy by reference -> @2401f4c3을 복사해준다.
// 기본 자료형(primitive data type) : int, long, double, char, boolean...)

public class ArrayReferenceEx {

	public static void main(String[] args) {
		int a = 10;// a == 10, 자바에서 제공하는 기본 자료형
		int b = a;// b == 10, 기본 자료형은 복사를 하면 메모리에 자동으로 생성이 된다.
		b = 100;// b== 20, call(copy) by value -> 값만 복사됨.
		System.out.println("a의 값은 : " + a + ", 의 값은 "+ b);
		
		int [] array1 = {2, 3, 5, 7, 11, 13, 17, 19};//선언, 생성, 초기화
		int [] array2;//선언
		
		printArray(array1);
		array2 = array1;// array1의 값을 array2에 대입함.
		array2[0] = 0;
		array2[2] = 0;
		System.out.println("array2 배열값 : ");
		printArray(array2);
		System.out.println();
		
			
	}
	
	public static void printArray(int[] array) {
		System.out.print('<');
		for (int i = 0; i<array.length;i++) {
			System.out.print(array[i]);
			if(i+1 < array.length) {
				System.out.print(" , ");
			}
		}
	}
	
}
