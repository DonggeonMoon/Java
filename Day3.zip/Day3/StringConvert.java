package Day3;
//static STring valueOf(double, long, char, object): 다른 형의 데이터를 문자열로 변환하는 메서드.
//String toLowerCase() : 모든 문자를 소문자로
//String toUpperCase() : 모든 문자를 대문자로
public class StringConvert {
	public static void main(String[] args) {
		int a = 2030;
		char b[] = {'W', 'o', 'r', 'l', 'd', 'c', 'u', 'p'};
		System.out.println(String.valueOf(a)+ " " + String.valueOf(b) + "은 한국에서");
		
		String s1 = String.valueOf(b);
		System.out.println(String.valueOf(a) + s1.toUpperCase()+ "은 한국에서");
	}
}
