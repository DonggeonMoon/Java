package Day3;

public class Coffee2Main {
	public static void main(String[] args) {
		int myMoneyA = 800;
		int cupsA = Coffee2Main.coffee(myMoneyA);
		Coffee2Main.printCoffee(cupsA);
		
		int myMoneyB = 150;
		int cupsB =coffee(myMoneyB);
		Coffee2Main.printCoffee(cupsB);
		
	}
	// 메서드 
	public static int coffee(int myMoney) {
		int cups = 0;
		
		if (myMoney > 0) {
			cups = myMoney / 200;
		} else if (myMoney == 0) {
			cups = 0;
		} else {
			cups = -1;
		}
		
		if (cups > 0) {
			System.out.println("커피 " + cups + "잔입니다.");
		} else { 
			System.out.println("잔액이 부족합니다.");
		}
		return cups;
	} 
	
	public static void printCoffee(int cups) {
		if (cups > 0) {
			System.out.println("커피 " + cups + "잔입니다.");
		} else { 
			System.out.println("잔액이 부족합니다.");
	}

}
}

