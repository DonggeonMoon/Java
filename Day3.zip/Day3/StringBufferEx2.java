package Day3;

public class StringBufferEx2 {
	public static void main(String[] args) {
		StringBuffer str1 = new StringBuffer();
		str1.append("안녕 자바");
		System.out.println("버퍼에 들어 있는 내용: "+ str1);
		str1.insert(3, "Power");
		System.out.println("버퍼에 들어 있는 내용: "+ str1);
		
		System.out.println("5번째 버퍼의 내용: "+ str1.charAt(4));
		str1.setCharAt(0, '정');//str1의 첫번째 글자를 '정으로 바꿈
		System.out.println("버퍼의 새로운 값: "+ str1);
		str1.setLength(12);//str1을 길이를 8로 설정, 8 이상은 삭제
		System.out.println("버퍼의 새로운 값 : "+ str1);
		System.out.println("문자열을 역순으로 찍기:" + str1.reverse());
		
	}
}
