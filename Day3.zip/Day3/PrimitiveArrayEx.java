package Day3;

// 배열: '같은 데이터 타입'이 '여러 개' 모여있는 자료모음.
//char [] s -> char 문자자료형, [] 배열, s 배열이름
//s = new char[5] -> s라는 문자 배열, = 대입해라, new 메모리에 s라는 공간을 생성해라
//					char[5] 5개짜리 공간을 가지는
//문자 배열 s에 5개 짜리 공간을 가지는 문자배열을 메모리에 생성해라.
//배열의 인덱스(첨자)는 C 계열 언어들은 0부터 시작한다.
//s[0] = 'A' -> s[0]: s라는 배열의 첫 번째 요소, = 대입, 'A' 값을 대입 또는 할당해라.

public class PrimitiveArrayEx {

	public static void main(String[] args) {
		char [] s;// 문자배열 S를 선언;
		s = new char[5]; // 문자배열 s를 생성
		
		s[0] = 'A'; //문자배열 s의 index 0에 'A' 값을 할당
		s[1] = 'B'; //문자배열 s의 index 1에 'B' 값을 할당
		s[2] = 'C'; //문자배열 s의 index 2에 'C' 값을 할당
		s[3] = 'D'; //문자배열 s의 index 3에 'D' 값을 할당
		s[4] = 'E'; //문자배열 s의 index 4에 'E' 값을 할당
		
		for (int i= 0; i<s.length; i++) {
			System.out.print(s[i] + "  "); 
		}//s.length: s는 문자 배열 변수, .length 길이의 값을 리턴해준다. 5가 리턴이 된다.
	}
}
