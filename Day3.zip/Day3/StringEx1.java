package Day3;

public class StringEx1 {
	public static void main(String[] args) {
		
		char a[] = {'c', 'o', 'm','p','u','t','e','r'};
		String s1 = new String(a); //문자열은 문자배열을 문자열로 받을 수 있다.
		String s2 = new String(a,3,2); //문자 배열 a의 index 3부터 2개 자리 수
		String s3 = new String("알기 쉽게 설명한 자바");//문자열로부터 직접 객체 생성
		String s4 = "알기 쉽게 설명한 자바"; //기본자료형 처럼 사용 가능
		
		System.out.println("문자열 s1: " + s1);
		System.out.println("문자열 s1의 길이: " + s1.length());
		System.out.println("문자열 s2: " + s2);
		System.out.println("문자열 s3: " + s3);
		System.out.println("문자열 s4: " + s4);
	}

}
