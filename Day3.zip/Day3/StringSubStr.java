package Day3;
//String substring(int startindex, int endindex):부분 문자열 반환
//				(1,3) 1번째 시작 인덱스 ,  2번 매개변수 3전까지라는 의미..
// String Concat(Sting constr): 결합된 문자열 출력
// String replace(char original, char replacement): 치환 
// String trim():문자열의 앞뒤 공백제거 
public class StringSubStr {
	public static void main(String[] args) {
		String str = "알기 쉬게 해설한 자바";
		System.out.println("인덱스 5부터 8이전까지의 문자: " + str.substring(5,8));
		System.out.println(str.concat("와 예제 프로그램"));
		System.out.println(str.replace('한', '된'));
		
		str = "  " + str + "  ";
		System.out.println(str +" trim () 전+ str 문자열 길이는:" + str.length());
		
		str = str.trim(); 
		System.out.println(str +"trim () 후 str 문자열 길이는:" + str.length());
		
	}

}
