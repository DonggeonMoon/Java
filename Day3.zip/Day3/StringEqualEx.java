package Day3;
//String의 메서드
//boolean equals (Object str): Str로 지정된 문자열과 현재 문자열이 같은지 비교(대소문자 구분)
//boolean eqaualsIgnoreCase(String str): 문자열 비교 시에 대소문자 무시
//boolean startsWith(String str): 현재 문자열이 str로 시작하면 true(대소문자 구분)
//boolean endsWith(String str): 현재 문자열이 str로 끝나면 true

public class StringEqualEx {
	public static void main(String[] args) {
		String a1 = "알기 쉽다.";
		String a2 = "Apple";
		String a3 = "APPLE";
		
		System.out.println("문자열 a1 : "+ a1);
		System.out.println("문자열 a1 : "+ a2);
		System.out.println("문자열 a1 : "+ a3);
		
		System.out.println("a1과 a2가 동일한 문자열?:" + a1.equals(a2));
		System.out.println("a2와 a3가 동일한 문자열?(대소문자 무시)" + a2.equalsIgnoreCase(a3));
		
		String s1 = "WorldCup Korea";
		System.out.println(s1.startsWith("wor"));
		System.out.println(s1.endsWith("rea"));
		
	}
}
