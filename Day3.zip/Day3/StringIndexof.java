package Day3;
//int indexOf(): 문자열 내에서 지정된 문자나 부분 문자열을 찾아내기 위한 메서드
//int lastIndexOf(): 문자열의 마지막에 위치하는 문자열의 값 위치를 리턴해준다.

public class StringIndexof {
	public static void main(String[] args) {
		String s = "알기 쉽게 해설한 JAVA, " + "java 배우기 쉽게 쓴 java 해설서";
		System.out.println(s);
		System.out.println("s.indexOf(해) = " + s.indexOf("해"));
		System.out.println("s.lastIndexOf(해) = " + s.lastIndexOf("해"));
		System.out.println("s.indexOf(a) = " + s.indexOf("a"));
		System.out.println("s.lastIndexOf(a) = " + s.lastIndexOf("a"));
		System.out.println("s.indexOf(a, 5) = " + s.indexOf("a", 5));
		System.out.println("s.lastIndexOf(a, 40) =" + s.lastIndexOf("a", 40));
		System.out.println("s.indexOf(java, 10) = " + s.indexOf("java", 10));
		System.out.println("s.lastIndexOf(java, 40) =" + s.lastIndexOf("java", 40));
	}
}
