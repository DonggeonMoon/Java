package Day3;

public class ArrayCopyEx {
	
	public static void main(String[] args) {
		int source[] = {1,2,3,4,5,6};
		int [] dest = {0,9,8,7,6,5,4,3,2,1};
		System.arraycopy(source, 0, dest, 0, source.length);
		//arraycopy(복사할 배열, 복사할 배열의 시작 위치, 복사당할 배열,
		//			복사당할 배열의 시작위치, 복사할 배열의 길이); 
		// 1, 2, 3, 4, 5, 6, 3, 2, 1
		for (int i = 0; i<dest.length; i++) {
			System.out.print(dest[i] + " ");
		}
		
		int a [] = {50, 63, 78, 82, 45, 25, 16, 98, 53, 88, 45, 79};//source
		int b [] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
		//0,0,63, 78, 82, 45, 25, 16, 98, 53, 0, 0 
		System.arraycopy(a, 1, b, 2, 8);  
		// 2 복사할 배열의 시작위치, 4 복사당할 배열의 시작위치, 5 복사할 배열의 길이
		for(int i = 0; i<b.length; i++) {
			System.out.println(b[i] + " ");
		}
	}

}
