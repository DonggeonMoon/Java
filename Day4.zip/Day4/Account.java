package Day4;

public class Account {
	// 명사적 기능, 변수선언
	public String name;
	public String accountNumber;
	public String password;
	public long balance;
	public double interest;
	
	// 동사적 기능, 메서드
	// 입금,출금, 조회, 이체
	
	public void saveMoney(long amount) {
		balance = balance + amount;
	}
	public void withdrawMoney(long amount) {
		balance = balance - amount;
	}
	
	public long getBalance() {
		return balance;
	}
	
	public void sendMoney(long amount) {
		balance = balance - amount;
	}
	
}
