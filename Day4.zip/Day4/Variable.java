package Day4;

/*
class Variable{
다음 라인부터 처음 메서드가 선언되기 전의 빈 공간 7~9 라인 : 멤버 필드
멤버 필드에 선언된 변수를 멤버 변수, 객체가 생성될 대 데이터 타입에 기본값으로 자동 초기화
기본값: 정수형 0, 실수형0.0, 불리언형 false, 객체 Null, 전역변수

지역 변수: 지역적으로만 사용되낟. 주로 메서드, if, 반복문 {} 안에서 선언된다.
 		메서드, if, 반목문에서만 쓰이고, 영역을 벗어나면 접근 불가..
 		
 매개변수: 메서드 () 안에서 호출될 때 입력해야 할 값을 저장하는 역할
 		지역변수의 성격을 가지고 있다.
 		

 */

public class Variable {
	
	int a;// 멤버변수
	
	public void printNum(int c) { //매개변수
		int b = 1; // 지역변수
		System.out.println("멤버변수: "  + a);
		System.out.println("지역변수: "  + b);
		System.out.println("매개변수: "  + c);
	}
}
