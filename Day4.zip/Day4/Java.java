package Day4;// 꾸러미, 묶음: package Day4: 관련된 클래스 모음...

import java.util.Scanner;

/* 
1.자바는 class 단위로 운영된다. class로 시작, class로 끝난다.
 */
//접근제한자 class 클래스이름{.......}
public class Java {
	
	//main: 자바 프로르ㅐㅁ을 실행해주는 메서드, 종료하는 메서드
	public static void main(String[] args) {
		int sum = add(10, 20);
		System.out.println(sum);//'.'의 의미는 소속의 의미
		// 조건문: 조건이 맞으면 if(){} 실행, 틀리면 else{} 실행.
		if (sum == 30) {
			if(sum > 30) {
				System.out.println("sum값이 크네요.");
			} else {
				System.out.println("sum값은: " + sum + "입니다.");
			}
		} else if (sum == 20) {
			System.out.println("sum값이 20이군요.");
		} else if (sum == 10) { 
			System.out.println("아 sum이 10이군요");
		} else {
			System.out.println("그럼 도대체 얼마인건가...");
		}
		
		switch(sum) {//다중 조건할 때 사용, 입력값
		case 30: // case 값1: 값1일 경우 동작, 아니면 패스.
			System.out.println("30점입니다.");
			break; // switch 구문을 탈출한다. 40번 라인으로 감...
		case 20:
			System.out.println("20점입니다.");
			break;
		default:
			System.out.println("탈락.");
			break;
		}
		//반복문 1~100까지 더 해보자..
		int num = 1;
		int numSum = 0;
		while(num <= 100) {//while(조건이 참일 때 반복){실행문; 증감식;}
			numSum = numSum + num;
			num++;
		}
		System.out.println(numSum);
		num = 1;
		numSum = 0;
		do {
			numSum = numSum + num;
			num++;
		} while(num <= 100);
		System.out.println(numSum);
		num = 0; 
		numSum = 0;
		for(num = 0;num<=100;num++) {
			numSum = numSum + num;
		} System.out.println(numSum);
		
		//배열:같은 데이터 타입이 '순서 있게' 여러개 모여 있는 공간, 집합
		//index가 0부터 시작
		//1번
		int a[];
		a = new int[5];
		a[2] = 1; 
		a[0] = 1;
		a[4] = 3;
		a[1] = 2;
		
		int b[] = new int[5];// 선언과 동시에 생성
		b[2] = 1; 
		b[0] = 1;
		b[4] = 3;
		b[1] = 2;
		
		int c[] = {1,2,3,4,5};// 선언, 생성, 초기화가지 한 번에 
		
		//index = 0, 1, 2, 3, 4, a.length == 5
		for (int i=0; i<a.length; i++) {
			System.out.println(a[i]);
		}
		
		
		for (int i: a) {
			System.out.print(i + " ");
		}
		
	}
	//모든 메서드의 선언방식
	//접근제한자, 리턴 타입 선언, 메서드 이름, (매개변수의 타입과 개수){....}
	//메서드는 선언만 되어 있을 경우에는 아무것도 안 한다.
	//메인에서 호출, 그 때 동작한다.
	public static int add(int a, int b) {
		int c = a + b;
		return c; // return 돌려줘라, 호출한 애한테
	}
}
