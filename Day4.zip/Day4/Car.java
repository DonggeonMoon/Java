package Day4;
// 추상호된 자동차를 구체화 시켜보자
public class Car {
	public String carType;
	public String gasType;
	public int howManyPeople;
	public int color;
	public int maxSpeed;
	public int currentSpeed;
	public double fuelRemaining;
	public boolean headlightTurnedOn;
	public boolean wiperTurnedOn;
	public boolean leftIndicatorTurnedOn;
	public boolean rightIndicatorTurnedOn;
	
	
	public void accelerate(int speed) {
		currentSpeed = currentSpeed + speed;
		if (currentSpeed > 0) {
			System.out.println("시속 " + speed + "km/h로 ");
			this.goForward();
		} else if (currentSpeed < 0) {
			System.out.println("시속 " + (-speed) + "km/h로 ");
			this.goBackward();
		} else {
			System.out.println("정지");
		}
	}
	public void goForward() {
		System.out.println("앞으로 이동");
	}
	public void goBackward() {
		System.out.println("뒤로 이동");
	}
	
	public void brake() {
		currentSpeed = 0;
		System.out.println("브레이크");
	}
	
	public void addFuel(double fuel) {
		fuelRemaining = fuelRemaining + fuel;
		System.out.println("현재 남은 연료: " + fuelRemaining);
	}
	
	public void leftIndicator() {
		leftIndicatorTurnedOn = true;
		System.out.println("좌측깜박이 켜짐(" + "leftIndicatorTurnedOn ="+ leftIndicatorTurnedOn + ")");
	}
	
	public void rightIndicator() {
		rightIndicatorTurnedOn = true;
		System.out.println("우측깜박이 켜짐(" + "rightIndicatorTurnedOn ="+ rightIndicatorTurnedOn + ")");
	}
	
	public void wiper() {
		wiperTurnedOn =true;
		System.out.println("와이퍼 켜짐(" + "wiperTurnedOn ="+ wiperTurnedOn + ")");
	}
	
	public void headlight() {
		headlightTurnedOn =true;
		System.out.println("라이트 켜짐(" + "headlightTurnedOn ="+ headlightTurnedOn + ")");
	}
	
public static void main(String[] args) {
	Car mc = new Car();
	mc.accelerate(100);
	mc.accelerate(-200);
	mc.brake();
	mc.addFuel(20.5);
	mc.addFuel(10);
	mc.leftIndicator();
	mc.rightIndicator();
	mc.wiper();
	mc.headlight();
}
}
