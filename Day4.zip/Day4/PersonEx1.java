package Day4;

public class PersonEx1 {
	public static void main(String[] args) {
		
		Person brother = new Person(); // brother라는 이름으로 객체 인스턴스했다.
		brother.age = 25;
		brother.height = 180l;
		brother.weight = 80.5;
		brother.name = "홍길동";
		System.out.println("brother의 나이는 " + brother.age + "brother의 키는 " + brother.height + "brother의 몸무게는 " + brother.weight + "brother의 이름은 " + brother.name);
		brother.eat();
		brother.sleep();
		brother.wc();
		
		Person sister = new Person();
		sister.age = 2;
		sister.height = 50;
		sister.weight = 20;
		sister.name = "영희";
		
		System.out.println("sister의 나이는 " + sister.age + "sister의 키는 " + sister.height + "sister의 몸무게는 " + sister.weight + "sister의 이름은 " + sister.name);
		sister.eat();
		sister.sleep();
		sister.wc();
		
		Person student = new Person();
		
		student.age = 15;
		student.height = 178;
		student.weight = 83;
		student.name = "강감찬";
		
		System.out.println("student의 나이는 " + student.age + "student의 키는 " + student.height + "student의 몸무게는 " + student.weight + "student의 이름은 " + student.name);
		student.eat();
		student.sleep();
		student.wc();
		
		People pe = new People();
		pe.juminid=(String) "600504";
		pe.address = "서울";
		pe.cellphone =" 010-3354-2222";
		System.out.println("pe 주번" + pe.juminid + "pe 주소" + pe.address + "pe 전번" + pe.cellphone);
		
		People pe2 = new People();
		pe2.juminid=(String) "870202";
		pe2.address = "서울";
		pe2.cellphone="010-4622-4445";
		System.out.println("pe2 주번" + pe2.juminid + "pe2 주소" + pe2.address + "pe2 전번" + pe2.cellphone);
		}
}
