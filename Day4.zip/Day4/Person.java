package Day4;
// 사람 클래스, Person: 인격을 가지고 있는 사림이라는 뜻.
// 변수, 메서드를 멤버라고 부른다. 멤버변수, 메서드
// 4개의 멤버변수, 메서드 2개, 총 6개의 멤버를 가지고 있다.
public class Person {
	int age; //나이
	double weight; //몸무게
	long height; //키
	String name; // 이름
	
	public static void eat() {
		System.out.println("식사를 합니다.");
	}
	public static void sleep() {
		System.out.println("잠을 잡니다.");
	}
	
	public static void wc() {
		System.out.println("화장실을 갑니다.");
	}
}
