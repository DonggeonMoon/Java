package Day4;

public class VariableEx {
	public static void main(String[] args) {
		Variable var = new Variable();
		var.printNum(2);
	}
}
