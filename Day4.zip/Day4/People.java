package Day4;

public class People {
	String juminid;
	String address;
	String cellphone;
}