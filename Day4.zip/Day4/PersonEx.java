package Day4;
//클래스를 하나의 자료형으로 사용 가능하다. 

public class PersonEx {
	public static void main(String[] args) {
		int a = 10;
		double d = 3.14;
		char c = 'A';
		String str = "Hello World";
		System.out.println(a + "," + d + "," + c + "," + str);
		
		int b[] = new int[5];
		Person p = new Person();
		//Person 타입의 p라는 변수로 메모리에 생성됨 객체 인스턴스라고 한다.
		/*
		int age; //나이
		double weight; //몸무게
		long height; //키
		String name; // 이름
		public int add(int x, int y)
		public int add(int x, int y)
		 */
		
		p.age = 20;
		p.height = 180l;
		p.weight = 80.5;
		p.name = "홍길동";
		p.eat();
		p.sleep();
		p.wc();
		
		System.out.println(p.age + ", " + p.height + ", "  + p.weight + ", "  + p.name);
		
	}
}
