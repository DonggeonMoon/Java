package Day4;
/* 절차 지향적 프로그래밍 요소
1. 변수 (데이터 타입, 연산자)
	변하는 수(variable): 일정한 저장공간인데, 그 공간에 내용이 바뀔 수 있는 것.
						지정된 데이터 형식(기본 자료형, 객체 자료형)으로 사용되어야 한다.
						int a; <- 4byte 정수형 변수 a이다. 변수 a는 정수 4byte 자료만 저장이 가능하다.
						a에 10 20, 5000 정수 값이 저장 가능, 10.5, 20.1f, 'A', "JAVA" 저장 불가
						기본 자료형
						정수형 (byte, short, int, long): 크기의 차이 1, 2, 4 byte; long L = 10l
						실수형 (float, double): 크기의 차이 4, 8byte; float f = 10.1f;
						불리언형 (boolean): true false 두 값만 존재 1bit
						문자형 (char): 2byte, 문자가 정수 값으로 매칭 되어 있다.
						-----
						문자열 (String): String : 크기 무제한... 문자열의 크기를 알 수 없다. 기본 데이터 형처럼 쓰이지만, 객체형 자료형.
						객체 (Object): 객체를 생성해서 사용하는 자료형.
2. 제어문: 조건문
	if(조건) {} else{}: 만약 조건이 참이면 if {}를 실행하고, 아니면 else {}를 실행하라
	조건은 다중 조건(if~else if~else), 중첩 조건(if(if()))들을 사용할 수 있다. 
	switch (조건) case A: ~break; case B: ~ break; default ~ break;
3. 제어문: 반복문
	for(초기화; 조건; 증감식): 반복 횟수를 알고 있거나 알 수 있을 때 사용한다.
	while(조건): 조건이 참일 때만 반복하지만, 조건이 거짓이면 중단.
	do~while: 적어도 한 번은 실행 후, 조건이 참이면 반복, 거짓이면 중단.
 */

public class practice {
	public static void main(String[] args) {
		String weekend [] = {"Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"};
		System.out.print("weekend[]: ");
		for (int i=0; i<weekend.length; i++) {
			System.out.print(weekend[i] + " ");
		}
		System.out.println();
		
		String str = " 알기 쉽게 설명한 JAVA";
		System.out.println("str: " + str);
		System.out.println("str.replace(\"설명\", \"해설\"): " + str.replace("설명", "해설"));
		System.out.println("str.trim(): " + str.trim());
		
		System.out.println("add(10, 20) : " + add(10, 20));
	}
	
	public static int add(int a, int b) {
		return a + b;
	}
}
