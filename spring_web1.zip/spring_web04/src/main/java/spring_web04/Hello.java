package spring_web04;

public interface Hello {
	public String sayHello();

}
