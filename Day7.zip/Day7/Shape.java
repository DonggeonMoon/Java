package Day7;

public abstract class Shape {
	
	public abstract void draw(); // 추상메서드
	public abstract void delete(); // 선언부만 있고, 구현부 없음
	
	public void doAll() {
		draw();
		delete();
	}
}
