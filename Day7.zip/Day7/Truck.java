package Day7;

public class Truck extends Car {

	@Override
	public void run() {
		System.out.println("트럭이 달립니다.");
		
	}

	@Override
	public void stop() {
		System.out.println("트럭이 멈춥니다.");
		
	}

}
