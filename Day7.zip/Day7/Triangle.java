package Day7;

public class Triangle extends Shape {
	int width;
	int height;

	@Override
	public void draw() {
		System.out.println("삼각형을 그립니다. 삼각형의 넓이는:" + (this.width * this.height /2) + "입니다.");
	}

	@Override
	public void delete() {
		
	}

}
