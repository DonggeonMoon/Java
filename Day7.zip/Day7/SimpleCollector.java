package Day7;

public class SimpleCollector extends SimpleAdate{

}
