package Day7;
//this: 자기자신을 포함하는 객체
//ThisTest 멤버: 변수 + 메서드 변수 1, 메서드 2(메인 메서드도 포함) int i, mth1(), main()
// 자신의 클래스에서 자신을 객체 인스턴스 가능하다. 
public class ThisTest {
	int i = 4;// 멤버 변수 i 
	
	void mth1() {
		int i = 10;// 멤버가 아니다. 지역변수는 멤버가 아니다. 
		System.out.println("local:" + i);
		System.out.println("global:" + this.i);
		//this(자신의 객체).i 멤버변수 i를 가리킨다.
	}
	public static void main(String[] args) {
		ThisTest tt = new ThisTest();
		tt.mth1();
		System.out.println("객체의 멤버변수 i: " + tt.i);
		/*tt의 멤버: tt.i = 10 ; tt.mth1(); tt.main(args);
		*/
		
	}

}
