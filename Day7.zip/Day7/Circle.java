package Day7;

public class Circle extends Shape{
	
	int radius;
	
	@Override
	public void draw() {
		System.out.println("원을 그립니다. 원의 넓이는: " + (this.radius * this.radius * Math.PI) + "");
		//Math.PI: 3.14 Math 클래스는 static이다. 
	}

	@Override
	public void delete() {
		System.out.println("원을 지웁니다.");
	}
}
