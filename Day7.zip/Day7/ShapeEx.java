package Day7;

public class ShapeEx {
	
	public static void main(String[] args) {
		Circle c = new Circle();
		Triangle t = new Triangle();
		Rectangle r = new Rectangle();
		
		Shape s;
		s = c;
		
		c.radius = 10;
		c.draw();
		c.delete();
		
		t.width = 10;
		t.height = 10;
		t.draw();
		t.delete();
		
		r.width = 10;
		r.height = 10;
		r.draw();
		r.delete();
	}

}
