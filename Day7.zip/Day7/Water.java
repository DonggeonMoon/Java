package Day7;

public interface Water {
	public abstract void swimming();
	public abstract void breathUnderWater();
}
