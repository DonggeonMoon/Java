package Day7;

public class Rectangle extends Shape {
	
	int width;
	int height;
	
	@Override
	public void draw() {
		System.out.println("사각형을 그립니다. 사각형의 넓이는: "+ (this.width * this.height) + "입니다.");
	}

	@Override
	public void delete() {
		System.out.println("사각형을 지웁니다.");
	}

}
