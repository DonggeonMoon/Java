package Day7;

public class Day6Woman extends Day6 {
	public Day6Woman() {
		this("이름", "나이", "주민번호");
	}
	public Day6Woman(String name, String age, String juminId) {
		super.name = name;
		super.age = age;
		super.juminId = juminId;
	}
	
	void eat() {
		System.out.println("많이 먹습니다.");
	}
	
	void sleep() {
		System.out.println("늘어지게 잡니다.");
	}

}
