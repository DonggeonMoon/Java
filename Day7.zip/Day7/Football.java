package Day7;

public interface Football {
	void kick();
	void defence(); 

}
