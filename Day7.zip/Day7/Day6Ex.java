package Day7;
// 부모 자신이 상속해준 자신의 멤버 외에는 자식의 고유 멤버에 접근 불가함.
public class Day6Ex {
	public static void main(String[] args) {
		Day6Man man = new Day6Man("홍길동", "22", "990101-1025774");
		Day6Woman woman = new Day6Woman("성춘향", "25", "960304-2250241");
		
		System.out.println("남자(" + man.name + ", " + man.age + ", " + man.juminId + ")");
		
		System.out.println("남자는:");
		man.eat();
		man.sleep();
		
		System.out.println("여자(" + woman.name +", " + woman.age + ", " + woman.juminId + ")");
		
		System.out.println("여자는:");
		woman.eat();
		woman.sleep();
		
		Day6 d = new Day6Man();
		//System.out.println(d.food);
		
		//이종모음 hetero collection
		Day6 dArr[] = new Day6[3];
		dArr[0] = new Day6();
		dArr[1] = new Day6Man(); 
		dArr[2] = new Day6Woman();
		
		for (int i = 0; i < dArr.length; i++) {
			System.out.println(dArr[i]);
		}
	}
}
