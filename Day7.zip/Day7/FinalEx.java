package Day7;
/*
 final: 마지막 -> 더 이상 변경불가. 수정불가.
 클래스: 상속 불가능, 사용하려면 객체 인스턴스를 해서 사용해야 한다. (String)
 변수: 상수를 만들 때, static 따라 다닌다. 반드시 초기화해야 한다. 암묵적으로 대문자로 작성 
 메서드: overriding 불가능, 일부러 재정의 못하게 final 붙일 수 있다.
 final로 선언된 변수는 반드시 초기화해야 한다.
 멤버 변수에 static final을 붙이면 상수가 된다.
 암묵적으로 상수화하는 변수는 대문자로 만든다.
*/
public class FinalEx {
	
	public final static int DATA = 100;
	
	public static void main(String[] args) {
		doIt("홍길동");
		doIt("이순신");
	}
	
	public static void doIt(final String name) {
		final int age = 28;
		//name = "이순신";// name은 입력받은 매개변수로 고정된다.
		//age = 40;
		System.out.println(name + "님의 나이는 " + age + "살입니다.");
	}
	
}
