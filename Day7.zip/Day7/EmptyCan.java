package Day7;
/*추상클래스: abstract 키워드 사용
추상메서드가 있으면 클래스는 추상클래스가 되어야 한다.
추상클래스는 추상메서드를 반드시 포함할 필요는 없다.
추상클래스는 일반 메서드를 가질 수 잇다.
추상클래스는 자신의 객체를 생성 불가, 그래서 자식 타입으로 객체를 생성해서 사용해야 됨.
추상클래스를 상속받는 일반클래스는 추상클래스의 추상메서드를 받드시 오버라이딩해야 함.
오버라이딩하지 않으면 자식 클래스도 추상클래스가 되야 한다.  
*/ 
public abstract class EmptyCan {
	
	public abstract void sound(); // 구현한 몸체 없음. 선언만 함.
	public abstract void who();
	
	public void doSth() {// 구현된 몸체 있음.
		sound();
		who();
	}

}
