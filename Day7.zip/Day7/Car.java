package Day7;
//abstract: 영어사전적 의미: 추상적, 추상의, 추상클래스, 추상메서드
//완전하게 구현된 클래스가 아니다. 그래서 자신의 객ㅊ를 만들 수 없다.
// furniture (가구) furniture(추상적인 세계) desk, chair, bed(실제적인 세계)
public abstract class Car {
	
	public abstract void run(); // 명세서, 설계도
	public abstract void stop();

}
