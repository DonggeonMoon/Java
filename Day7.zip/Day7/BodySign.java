package Day7;
//interface에서 변수를 선언하면 static final이 된다. 상수화된다.
//메서드는 무조건 abstract method가 된다.
public interface BodySign {
	int STRAIGHT = 1;
	int CURVE = 2;
	int DOWN = 1;
	int UP = 2;
	int LEFT = 3;
	int RIGHT = 4;
	
	public abstract void countFinger(int how_ball);
	void directionBall(int how_ball); // public abstract 생략 가능
}
