package Day7;

public class Cruise extends Ship{

	@Override
	public int move() {
		return 6;
	}

	@Override
	public int carry() {
		return 100;
	}
	
	public String name() {
		return "퀸 메리 ";
	}
}
