package Day7;

public abstract class Ship {
	
	public abstract int move();
	public abstract int carry();

}
