package Day7;

public class Forward implements Football {

	@Override
	public void kick() {
		System.out.println("공격수가 공을 찹니다.");
		
	}

	@Override
	public void defence() {
		System.out.println("공격수가 수비를 합니다.");
	}

}
