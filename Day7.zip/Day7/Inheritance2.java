package Day7;

public class Inheritance2 extends Inheritance1 {
	
	int num3;
	int num4;
	
	public Inheritance2(int s, int a) {
		super(s);// 부모의  생성자를 호출, 부모 먼저 생성되야 한다. 안 그러면 에러
		System.out.println("클래스 Inheritance2의 생성자 수행");
		num4 = a;
		num3 = a * a; 
	}//constructor: 생성자: 객ㅊ가 생성될 대 이렇게 만들어라는 일종의 예시..
}
