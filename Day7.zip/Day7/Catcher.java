package Day7;

public class Catcher implements BodySign {

	@Override
	public void countFinger(int how_ball) {
		if (how_ball == BodySign.STRAIGHT) {
			System.out.println("직구를 던집니다.");
		} else if(how_ball == BodySign.CURVE) {
			System.out.println("커브를 던집니다.");
		}
		
	}

	@Override
	public void directionBall(int how_direct) {
		if(how_direct == BodySign.UP) {
			System.out.println("높은 공을 던집니다.");
		} else if(how_direct == BodySign.DOWN) {
			System.out.println("낮은 공을 던집니다.");
		} else if(how_direct == BodySign.LEFT) {
			System.out.println("왼쪽으로 공을 던집니다.");
		} else if(how_direct == BodySign.RIGHT) {
			System.out.println("오른쪽으로 공을 던집니다.");
		}
	}
	
	public static void main (String[] args) {
		Catcher c = new Catcher();
		c.countFinger(BodySign.UP);
		c.directionBall(BodySign.LEFT);
		c.countFinger(BodySign.STRAIGHT);
		c.countFinger(BodySign.CURVE);
	}

}
