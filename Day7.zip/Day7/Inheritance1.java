package Day7;

public class Inheritance1 {
	int num1;
	int num2;
	public Inheritance1(int s) {
		System.out.println("Inheritance1의 생성자 수행");
		num2 = s;
		num1 = s * s;
		
	}
}
