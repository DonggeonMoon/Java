package Day7;

public class Day6 {
	String juminId;
	String name;
	String age;
	
	void eat() {
		System.out.println("잘 먹습니다.");
	}
	
	void sleep() {
		System.out.println("잘 잡니다.");
	}

}
