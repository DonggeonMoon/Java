package Day7;

public class Boat extends Ship {

	@Override
	public int move() {
		return 6;
	}// 승객을 몇 명 태우는가

	@Override
	public int carry() {
		return 100;
	}//짐을 몇 kg 싣는가

	public String name() {
		return "쌩쌩보트";
	}
}