package Day7;

public class GoalKeeper implements Football{

	@Override
	public void kick() {
		System.out.println("골키퍼가 공을 찹니다.");
		
	}

	@Override
	public void defence() {
		System.out.println("골키퍼가 수비를 합니다.");		
	}

}
