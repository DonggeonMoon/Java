package Day7;

public class NewCan extends EmptyCan {
	
	public static void main(String[] args) {		
		NewCan nc = new NewCan();
		//EmptyCan ec = new EmptyCan();// 추상클래스는 자신의 클래스로는 객체 생성불가.
		EmptyCan ec = nc;//부모는 자식의 타입으로 객체 생성 가능하다.
		ec.sound(); //nc로 만들어진 부모의 객체
		ec.who();
		ec.doSth();
	}
	//public abstract void sound()
	@Override
	public void sound() {
		System.out.println("빈 깡통이 요란하다.");
	}//Overriding
	//public abstract void who()
	@Override
	public void who() {
		System.out.println("나는 빈 깡통입니다.");
		
	}

}
