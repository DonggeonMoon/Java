package Day7;
//부모에게 선언된 멤버만 사용이 가능하다.
//자식 자체의 멤버는 사용 불가.

public class CarEx {
	
	public static void  main(String[] args) {
		Bus b = new Bus();
		Truck t = new Truck();
		Sedan s = new Sedan();
		
		Car c;
		c = b;
		c.run();
		c.stop();
		
		c = t;
		c.run();
		c.stop();
		
		c = s;
		c.run();
		c.stop();
	}

}
