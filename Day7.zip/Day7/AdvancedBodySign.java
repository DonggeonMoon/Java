package Day7;

public interface AdvancedBodySign extends BodySign {
	void throwDeadBall();
	
}
