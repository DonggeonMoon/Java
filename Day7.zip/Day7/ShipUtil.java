package Day7;
//instanceof 연산자 
//s instanceof Boat : s가 Boat형 객체이냐? 맞으면 true, 틀리면 false값 리턴
//s instanceof Cruise : s가 Cruise형 객체이냐?
public class ShipUtil {

	public static void search(Ship s) {
		System.out.println(s.carry());
		System.out.println(s.move());
		
		if(s instanceof Boat) {
			Boat b = (Boat)s; //부모의 자료형이 상위클래스이라 캐스팅을 사용하였다.
			System.out.println("Boat 이름 : " + b.name());
		}else if(s instanceof Cruise) {
			Cruise c = (Cruise)s;//부모의 자료형이 상위 클래스라 캐스팅 사용함.
			System.out.println("Cruise 이름 : " + c.name());
		}
		
	}

	
}
