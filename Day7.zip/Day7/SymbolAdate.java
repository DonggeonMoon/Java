package Day7;

public abstract class SymbolAdate {

	public void printHello() {
		System.out.println("SimpleAdapte의 println()");
	}
}
