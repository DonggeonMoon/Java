package Day7;

public class WaterEx {

	public static void main(String[] args) {
		//         Water water = new Water();//interfaceㄷ 자신의 객체 생성 불가
		Water water = new Mermaid(); //자식의 객체형으로 객체 선언.
		water.swimming();
		water.breathUnderWater();
	}
}
