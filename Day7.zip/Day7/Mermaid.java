package Day7;

public class Mermaid implements Water {
	
	public void swimming() {
		System.out.println("인어는 물속에 수영을 엄청 빠르게 잘 해요");
	}
	
	public void breathUnderWater() {
		System.out.println("인어는 물에서도 호흡을 할 수 있어요.");
	}	

}
