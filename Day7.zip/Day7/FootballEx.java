package Day7;

public class FootballEx {
	public void main(String[] args) {
		Football fw1 = new GoalKeeper();
		Football fw2 = new Forward();
		
		fw1.kick();
		fw1.defence();
		
		fw2.kick();
		fw2.defence();
	}
}
