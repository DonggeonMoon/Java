package Day7;

public class Sedan extends Car {

	@Override
	public void run() {
		System.out.println("세단이 달립니다.");
		
	}

	@Override
	public void stop() {
		System.out.println("세단이 멈춥니다.");
	}

}
