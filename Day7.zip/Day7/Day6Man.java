package Day7;

public class Day6Man extends Day6 {
	public Day6Man() {
		this("이름", "나이", "주민번호");
	}
	public Day6Man(String name, String age, String juminId) {
		super.name = name;
		super.age = age;
		super.juminId = juminId;
	}
	
	String food = "파스타";
	
	void eat() {
		System.out.println("잘 못 먹습니다.");
	}
	void sleep() {
		System.out.println(("뒤척이며 잡니다."));
	}

}
