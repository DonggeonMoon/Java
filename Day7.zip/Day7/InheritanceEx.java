package Day7;

public class InheritanceEx {
	public static void main(String[] args) {
		Inheritance2 ih2 = new Inheritance2(10, 20);
		System.out.println("10의 제곱은: " + ih2.num3);
		System.out.println("20의 제곱은: " + ih2.num1);		
	}

}

