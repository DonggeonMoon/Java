package test01;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {

	public static void main(String[] args) {
		/*Test test = new TestImple1();
		//다형성 : 상속, 자신이 상속해준 멤버만 사용가능.
		test.drink("중딩");*/		
		BeanFactory factory = new XmlBeanFactory
				(new FileSystemResource("src/app.xml"));
		
		Object obj = factory.getBean("b1");
		System.out.println("Obj : " + obj);
		
		Test test = (Test)obj;
		test.drink("민수");
	}

}
