package test01;

public class TestImple1 implements Test{
	
	private String product;
	
	public TestImple1() {
		product = "생수";
	}
	
	public TestImple1(String product) {
		this.product = product;
	}
	
	@Override
	public void drink(String name) {
		System.out.println(name+"님이 "+product+"을 마십니다.");
	}

}
