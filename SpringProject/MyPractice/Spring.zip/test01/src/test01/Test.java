package test01;

public interface Test {
	void drink(String name);
}
