package test01;

public class TestImple2 implements Test{

	private String product;
	
	public TestImple2() {}
	
	public TestImple2(String product) {
		this.product = product;
	}
	
	public void eat(String food) {
		System.out.println(food + "를 맛있게 먹습니다.");
	}
	
	@Override
	public void drink(String name) {
		System.out.println(name+"님이 "+product+"을 마십니다.");
	}
}
