package spring_app12.dao;

import java.util.List;

import spring_app12.dto.DeptDTO;
import spring_app12.service.ConnectionManager;

public class DeptDao implements DAO{
	
	ConnectionManager cm;
	
	public void setCm(ConnectionManager cm) {
		this.cm = cm;
	}
	
	@Override
	public List<DeptDTO> selectAll() {
		return cm.getFactory().openSession(true).selectList("selectAll");
	}

	@Override
	public DeptDTO selectOne(int no) {
	
		return null;
	}

	@Override
	public void insertOne(DeptDTO dto) {
		
	}

	@Override
	public void updateOne(DeptDTO dto) {
			
	}

	@Override
	public void deleteOne(int no) {
			
	}

}
