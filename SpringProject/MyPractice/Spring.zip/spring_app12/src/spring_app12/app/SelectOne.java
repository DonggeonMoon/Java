package spring_app12.app;

public class SelectOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
