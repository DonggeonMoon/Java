package spring_app09.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app09.service.DAO;
import spring_app09.service.EmpDTO;

public class ListAll {

	public static void main(String[] args) {
	
		ApplicationContext context = 
			new GenericXmlApplicationContext("app.xml");

		DAO d = context.getBean("dao", DAO.class);
		
		List<EmpDTO> list = d.selectAll();
		
		for(EmpDTO dto : list) {
			System.out.println("empno : " + dto.getEmpno() 
					  + "\t" + "ename : " + dto.getEname()
					  + "\t" + "sal : " + dto.getSal()
					  + "\t" + "deptno : " + dto.getDeptno() );
		}
		
		System.out.println("------------------------------------------------------------");
	}

}
