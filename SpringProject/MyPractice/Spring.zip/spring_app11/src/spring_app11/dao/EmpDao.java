package spring_app11.dao;

import java.util.List;

import spring_app11.dto.EmpDTO;
import spring_app11.service.ConnectionManager;

public class EmpDao implements DAO{
	
	ConnectionManager cm;
	
	public void setCm(ConnectionManager cm) {
		this.cm = cm;
	}

	@Override
	public List<EmpDTO> selectAll() {		
		return cm.getFactory().openSession(true)
				.selectList("selectAll");
	}

	@Override
	public EmpDTO selectOne(int no) {
		return cm.getFactory().openSession(true)
				.selectOne("selectOneByEmp",no);
	}

	@Override
	public void insertOne(EmpDTO dto) {
		cm.getFactory().openSession(true)
			.insert("insertOneByEmp", dto);		
	}

	@Override
	public void updateOne(EmpDTO dto) {
		cm.getFactory().openSession(true)
		.update("updateOneByEmp", dto);		
	}

	@Override
	public void deleteOne(int no) {
		cm.getFactory().openSession(true)
		.delete("deleteOneByEmp",no);		
	}
	
}
