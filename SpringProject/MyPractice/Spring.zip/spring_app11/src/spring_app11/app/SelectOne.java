package spring_app11.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app11.dao.DAO;
import spring_app11.dto.EmpDTO;

public class SelectOne {

	public static void main(String[] args) {
	
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		
		DAO d = context.getBean("dao",DAO.class);
		
		EmpDTO empDto = new EmpDTO();
		empDto = d.selectOne(7950);
		
		System.out.println("empno : " + empDto.getEmpno());
		System.out.println("ename : " + empDto.getEname());
		System.out.println("sal : " + empDto.getSal());
		System.out.println("deptno : " + empDto.getDeptno());
		
	}

}
