package spring_app10.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app10.service.DAO;
import spring_app10.service.DeptDTO;

public class InsertOne {

	public static void main(String[] args) {
		
		ApplicationContext context = 
				new GenericXmlApplicationContext("app.xml");
		
		DAO d = context.getBean("dao", DAO.class);
		
		DeptDTO deptDto = new DeptDTO();
		
		int deptno = 50;
		String dname = "IT";		
		String loc = "LA";
		
		deptDto.setDeptno(deptno);
		deptDto.setDname(dname);
		deptDto.setLoc(loc);
		
		d.insertOne(deptDto);
		
	}

}
