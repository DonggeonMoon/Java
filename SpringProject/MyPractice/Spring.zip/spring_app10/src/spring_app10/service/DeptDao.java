package spring_app10.service;

import java.sql.ResultSet;
import java.util.List;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class DeptDao implements DAO{

	private JdbcTemplate jdbcTemplate;
	ResultSet rs;
	StringBuffer sb = new StringBuffer();
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<DeptDTO> selectAll() {
		sb.setLength(0); // sb의 내용을 초기화시킴.
		sb.append("select * from dept ");//sb selet~ 을 추가
		
		RowMapper<DeptDTO> rm = new RowMapper<DeptDTO>() {
			@Override
			public DeptDTO mapRow(ResultSet rs, int rowNum) throws SQLException{
				return new DeptDTO(rs.getInt("deptno"),
						rs.getString("dname"), rs.getString("loc")); 
			}
		};
		
		List<DeptDTO> list = jdbcTemplate.query(sb.toString(), rm);
		return list;
	}
	
	public DeptDTO selectOne(int no) {
		sb.setLength(0);
		sb.append("select deptno ,dname , loc ");
		sb.append("from dept where deptno = ? ");
		
		RowMapper<DeptDTO> rm = new RowMapper<DeptDTO>() {
			public DeptDTO mapRow ( ResultSet rs, int rowNum) throws SQLException{
			DeptDTO dto = new DeptDTO(rs.getInt("deptno"),
				rs.getString("dname"), rs.getString("loc"));
				
				return dto;
			}
		};
		DeptDTO dto = jdbcTemplate.queryForObject(sb.toString(), rm, no);
		
		return dto;
	}

	@Override
	public void insertOne(DeptDTO dto) {
		sb.setLength(0);
		sb.append("insert into dept(deptno, dname, loc ) ");
		sb.append("values (?, ?, ? ) ");
		
		int result = jdbcTemplate.update(sb.toString(), dto.getDeptno(), dto.getDname(), dto.getLoc());
		
		System.out.println("insert result : "+ result);
		
	}

	@Override
	public void updateOne(DeptDTO dto) {
		
		sb.setLength(0);
		sb.append("update dept ");
		sb.append("set dname = ?, loc = ? ");
		sb.append("where deptno = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), dto.getDname(), dto.getLoc(), dto.getDeptno());
		
		System.out.println("update result : "+ result);
		
	}

	@Override
	public void deleteOne(int no) {
		sb.setLength(0);
		sb.append("delete dept ");		
		sb.append("where deptno = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), no);
		
		System.out.println("delete result : "+ result);
		
	}
	
}
