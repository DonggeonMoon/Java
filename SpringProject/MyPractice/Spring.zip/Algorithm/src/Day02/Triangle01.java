package Day02;

import java.util.Scanner;

public class Triangle01 {

	public static void main(String[] args) {
	
		Scanner stdIn = new Scanner(System.in);
		int n;
		
		System.out.println("삼각형을 출력합니다.");
		do{
			System.out.println("몇 단으로 찍을까요? ");
			n = stdIn.nextInt();			
		}while(n <= 0);//1이상의 값을 입력받게하기 위해 처리
		
		for(int i=1; i<=n ; i++) {//i가 n이 될때까지 반복
			for(int j=1; j<=i ; j++) {
				System.out.print("*");
			}
			System.out.println();
		}//n=10
		//i = 1, j = 1번 반복. * 
		//i = 2, j = 2번 반복. **
		//i = 3, j = 3번 반복. ***
		//....
		//i = 10, j = 10번 반복. **********
		
	}

}
