package Day01;

import java.util.Scanner;
//숫자 4개를 입력받아 가장 작은수를 출력해보자
//int a, b, c, d, min
public class Min4 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.println("4수를 입력하세요.");
		System.out.println("a: ");
		int a = stdIn.nextInt();
		System.out.println("b: ");
		int b = stdIn.nextInt();
		System.out.println("c: ");
		int c = stdIn.nextInt();
		System.out.println("d: ");
		int d = stdIn.nextInt();
		
		int min = a;
		if(b < min) min = b;
		if(c < min) min = c;
		if(d < min) min = d;
		
		System.out.println("입력하신 4수 중의 가장 작은 수는 : " + min + "입니다.");

	}

}
