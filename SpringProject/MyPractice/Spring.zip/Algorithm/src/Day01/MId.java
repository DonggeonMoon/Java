package Day01;

import java.util.Scanner;

public class MId {

	static int mid3(int a, int b, int c) {
		if(a >= b ) {
			if (b >= c ) {
				return b; // case 1
			}
			else if (a <= c) {
				return a; // case 2
			}
			else {
				return c; // case 3
			}
		}// a > b
		else if (a > c) {
			return a; // case 4
		}// a < b
		else if (b > c) {		
			return c; // case 5
		}// a < b, a > c
		else {
			return b; // case 6		
		}
		
	}
	
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		
		System.out.println("정수 3개를 입력하세요.");
		System.out.println("a: ");
		int a = stdIn.nextInt();
		System.out.println("b: ");
		int b = stdIn.nextInt();
		System.out.println("c: ");
		int c = stdIn.nextInt();
		
		System.out.println("중앙값은 : " + mid3(a,b,c) + "입니다.");

	}

}
