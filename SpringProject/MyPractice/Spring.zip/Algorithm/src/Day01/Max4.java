package Day01;

import java.util.Scanner;
//4개의 값을 입력받아서 비교하고 최대값을 출력 코드 작성
//int a, b, c, d , max
public class Max4 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		System.out.println("4개의 숫자를 입력하세요.");
		System.out.println("a : ");
		int a = stdIn.nextInt();
		System.out.println("b : ");
		int b = stdIn.nextInt();
		System.out.println("c : ");
		int c = stdIn.nextInt();
		System.out.println("d : ");
		int d = stdIn.nextInt();
		
		int max = a;
		if (b > max) max = b;
		if (c > max) max = c;
		if (d > max) max = d;
		
		System.out.println("a: "+a+" b: "+b+" c: "+c
				+" d: " + d +"입니다.");
		System.out.println("이중에 가장 큰 값은 : " + max + "입니다.");
	}

}
