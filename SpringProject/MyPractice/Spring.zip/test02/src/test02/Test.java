package test02;

public interface Test {
	public int selectCount();
}
