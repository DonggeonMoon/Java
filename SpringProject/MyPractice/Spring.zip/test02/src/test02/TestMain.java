package test02;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		ApplicationContext context = 
				new GenericXmlApplicationContext("app.xml");
		
		Test test = context.getBean("dao", Test.class);
		//Test test1 = (Test) context.getBean("dao");
		
		System.out.println("급여등급테이블의 총 row 수 : " + test.selectCount());

	}

}
