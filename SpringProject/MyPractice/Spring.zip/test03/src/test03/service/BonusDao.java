package test03.service;

import java.sql.ResultSet;
import java.util.List;
import java.sql.SQLException;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class BonusDao implements DAO{

	private JdbcTemplate jdbcTemplate;
	ResultSet rs;
	StringBuffer sb = new StringBuffer();
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<BonusDTO> selectAll() {
		sb.setLength(0);
		sb.append("select * from bonus ");
		
		RowMapper<BonusDTO> rm = new RowMapper<BonusDTO>() {
			@Override
			public BonusDTO mapRow(ResultSet rs, int rowNum) throws SQLException{
				return new BonusDTO(rs.getString("ename"), rs.getString("job"),
						rs.getInt("sal"), rs.getInt("comm")); 
			}
		};
		
		List<BonusDTO> list = jdbcTemplate.query(sb.toString(), rm);
		return list;
	}
	
	public BonusDTO selectOne(String name) {
		sb.setLength(0);
		sb.append("select ename ,job , sal, comm ");
		sb.append("from bonus where ename = ? ");
		
		RowMapper<BonusDTO> rm = new RowMapper<BonusDTO>() {
			public BonusDTO mapRow ( ResultSet rs, int rowNum) throws SQLException{
			BonusDTO dto = new BonusDTO(rs.getString("ename"), rs.getString("job"),
					rs.getInt("sal"), rs.getInt("comm"));
				
				return dto;
			}
		};
		BonusDTO dto = jdbcTemplate.queryForObject(sb.toString(), rm, name);
		
		return dto;
	}

	@Override
	public void insertOne(BonusDTO dto) {
		sb.setLength(0);
		sb.append("insert into bonus(ename, job, sal, comm ) ");
		sb.append("values (?, ?, ?, ? ) ");
		
		int result = jdbcTemplate.update(sb.toString(), dto.getEname(), 
				dto.getJob(), dto.getSal(), dto.getComm());
		
		System.out.println("insert result : "+ result);
		
	}

	@Override
	public void updateOne(BonusDTO dto) {
		
		sb.setLength(0);
		sb.append("update bonus ");
		sb.append("set job = ?, sal = ? , comm = ? ");
		sb.append("where ename = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), dto.getJob(), dto.getSal(),
				dto.getComm(), dto.getEname());
		
		System.out.println("update result : "+ result);
		
	}

	@Override
	public void deleteOne(String name) {
		sb.setLength(0);
		sb.append("delete bonus ");		
		sb.append("where ename = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), name);
		
		System.out.println("delete result : "+ result);
		
	}
	
}
