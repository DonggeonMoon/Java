package test03.service;

import java.util.List;

public interface DAO {

	public List<BonusDTO> selectAll();
	public BonusDTO selectOne(String name);
	public void insertOne(BonusDTO dto);
	public void updateOne(BonusDTO dto);
	public void deleteOne(String name);
	
}
