package test03.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;


import test03.service.DAO;
import test03.service.BonusDTO;

public class UpdateOne {

	public static void main(String[] args) {
		ApplicationContext context = 
				new GenericXmlApplicationContext("app.xml");
		
		DAO d = context.getBean("dao", DAO.class);
		
		BonusDTO bonusDto = new BonusDTO();
		
		String ename = "JONES";
		String job = "ACCOUTING";
		int sal = 3500;
		int comm = 0;		
		
		bonusDto.setEname(ename);
		bonusDto.setJob(job);
		bonusDto.setSal(sal);
		bonusDto.setComm(comm);
		
		
		d.updateOne(bonusDto);

	}

}
