package test03.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test03.service.DAO;
import test03.service.BonusDTO;

public class InsertOne {

	public static void main(String[] args) {
		
		ApplicationContext context = 
				new GenericXmlApplicationContext("app.xml");
		
		DAO d = context.getBean("dao", DAO.class);
		
		BonusDTO bonusDto = new BonusDTO();
		
		String ename = "JONES";
		String job = "SALES"; 
		int sal = 3000;
		int comm = 10;		
		
		bonusDto.setEname(ename);
		bonusDto.setJob(job);
		bonusDto.setSal(sal);
		bonusDto.setComm(comm);
		
		d.insertOne(bonusDto);
		
	}

}
