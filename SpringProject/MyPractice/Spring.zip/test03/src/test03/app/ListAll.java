package test03.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test03.service.DAO;
import test03.service.BonusDTO;

public class ListAll {

	public static void main(String[] args) {
		ApplicationContext context = 
				new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		List<BonusDTO> list = d.selectAll();
		
		for(BonusDTO dto: list) {
			System.out.println("ename : " + dto.getEname() +
					"\t" + "job : " + dto.getJob() + 
					"\t" + "sal : " + dto.getSal() +
					"\t" + "comm : " + dto.getComm());
		}
	
	}

}
