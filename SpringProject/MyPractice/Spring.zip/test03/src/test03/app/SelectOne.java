package test03.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test03.service.DAO;
import test03.service.BonusDTO;

public class SelectOne {

	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		
		DAO d = context.getBean("dao", DAO.class);
		
		BonusDTO bonusDto = new BonusDTO();
		bonusDto = d.selectOne("JONES");
		
		System.out.println("ename : " + bonusDto.getEname());
		System.out.println("job : " + bonusDto.getJob()); 
		System.out.println("sal : " + bonusDto.getSal());
		System.out.println("comm : " + bonusDto.getComm());
	
	}

}

