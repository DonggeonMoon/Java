package spring_app02;

public class CoffeeImple implements Beverage{

	private String product;
	
	//오버로딩 : 같은클래스에서 같은 메서드의 중복정의
	//조건 : 매개변수의 개수, 타입이 다를것.
	//오버라이딩 : 부모의 메서드를 자식이 재정의 하여 사용
	//조건 : 상속, 리턴타입, 이름, 매개변수 모두 동일 
	//{구현부가 달라야됨..}
	public CoffeeImple() {
		product="냉수";
	}
	
	public CoffeeImple(String product) {
		this.product = product;
	}
	
	@Override
	public void drink(String name) {
		System.out.println(name + "님이 " + product +
				"를 마십니다.");		
	}	
}