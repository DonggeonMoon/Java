package spring_app02;
//인터페이스에 선언된 변수는 무조건 상수가 된다.
//인터페이스에 선언된 메서드는 무조건 추상메서드가 된다.
public interface Beverage {
	public void drink(String name);
}
