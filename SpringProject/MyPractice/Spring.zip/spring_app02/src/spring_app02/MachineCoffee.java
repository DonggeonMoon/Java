package spring_app02;

public class MachineCoffee implements Beverage{
	
	String product;
	
	public MachineCoffee() {}
	
	public MachineCoffee(String product) {
		this.product = product;
	}
	
	@Override
	public void drink(String name) {
		System.out.println(name + "님이 " + product +
				"를 홀짝 홀짝 마십니다.");
	}
}
