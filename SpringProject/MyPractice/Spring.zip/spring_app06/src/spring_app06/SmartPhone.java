package spring_app06;

import org.springframework.beans.factory.annotation.Autowired; 

public class SmartPhone implements Phone{
	@Autowired
	PhoneOs os;
	
	public void setOs(PhoneOs os) {
		this.os = os;
	}
	
	public void call(String callNumber) {
		os.printOs();
		System.out.println(callNumber + " 전화거는중");
	}
	
	public void playGame(String title) {
		System.out.println(title + "게임하기");
	}
	
	public void sendMsg(String msg) {
		System.out.println("문자왔음 : " +msg);
	}
}

