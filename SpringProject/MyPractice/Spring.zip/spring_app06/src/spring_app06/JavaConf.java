package spring_app06;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConf {

	@Bean(name="sp")
	public PhoneOs phoneOs() {
		PhoneOs po = new PhoneOs();
		po.setName("안드로이드");
		po.setVersion("11버전");
		return po;
	}
	
	@Bean(name="p")
	public SmartPhone smartPhone() {
		SmartPhone sp = new SmartPhone();
		sp.setOs(phoneOs());
		return sp;
	}
	
	
}
