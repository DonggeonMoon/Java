package spring_app06;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		ApplicationContext context = 
				new AnnotationConfigApplicationContext(JavaConf.class);
		Phone phone = context.getBean("p",Phone.class);
		
		phone.call("010-1111-2222");
		phone.sendMsg("감기인가?");

	}

}
