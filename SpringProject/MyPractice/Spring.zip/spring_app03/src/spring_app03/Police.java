package spring_app03;

public class Police implements Character{
	
	Weapon w;
	Gun g;
	StunGun s;
	
	int hp;
	
	public Police() {
		hp = 100;
	}

	public void walk() {
		System.out.println("뚜벅뚜벅");
	}
	public void eat(String it) {
		System.out.println(it + "공짜 도넛");
	}
	public void attack(Object obj) {
		System.out.println(obj + "공격");
	}
	public void get(Object obj) {
		System.out.println(obj + "아싸 득템");
	}
		
	public Weapon getW() {
		return w;
	}

	public void setW(Weapon w) {
		this.w = w;
	}

	public Gun getG() {
		return g;
	}

	public void setG(Gun g) {
		this.g = g;
	}

	public StunGun getS() {
		return s;
	}

	public void setS(StunGun s) {
		this.s = s;
	}

	public int getHp() {
		return hp;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}
	
	

}
