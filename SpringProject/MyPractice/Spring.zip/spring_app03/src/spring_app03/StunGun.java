package spring_app03;

public class StunGun implements Weapon{

	int bullet;
	
	public StunGun() {
		bullet = 1;
	}
	
	public void use() {
		if(bullet > 0) {
			System.out.println("찌지직...");
			bullet--;
		}
	}
	
	public void reuse(){
		System.out.println("재장전..");
		bullet = 1;
	}
	
	public void drop() {
		System.out.println("전기 충전 필요..");
		bullet = 0;
	}
}
