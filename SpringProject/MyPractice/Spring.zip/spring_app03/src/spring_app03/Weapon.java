package spring_app03;

public interface Weapon {
	public void use();
	public void reuse();
	public void drop();

}
