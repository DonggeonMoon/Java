package spring_app03;

public class Gun implements Weapon{

	int bullet;
	public Gun() {
		bullet = 6;
	}
	
	public void use() {
		if(bullet > 0) {
			System.out.println("빵~");
			bullet--;
		}
	}
	
	public void reuse() {
		System.out.println("재장전");
		bullet = 6;
	}
	
	public void drop() {
		System.out.println("어이쿠~");
		bullet = 0;
	}
}
