package spring_app05;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.
			ClassPathXmlApplicationContext;


public class TestMain {

	public static void main(String[] args) {
    ApplicationContext context = 
		new ClassPathXmlApplicationContext("app.xml");
		Monitor mt = context.getBean("sm",Monitor.class);
		Monitor mt1 = (Monitor) context.getBean("sm");
		
		mt.showMonitor();
		mt1.showMonitor();
		
	}

}
