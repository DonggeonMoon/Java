package spring_app05;

//privitive (기본) 자료형 : 정수(byte1, short2, int4, long8), 
//실수(float4, double8), 문자(char2), 불리언(boolean 1bit)
//reference (참조) 자료형 : 주소의 시작값.
public class SystemMonitor implements Monitor{
	
	Sender sender;//reference type 자료형, 배열, class ....
		
	public void setSender(Sender sender) {
		this.sender = sender;
	}
	
	@Override
	public void showMonitor() {
		if(sender!=null)sender.show();
		else System.out.println("sender is null");
	}

}
