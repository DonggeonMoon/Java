package spring_app04;

import org.springframework.beans.factory
			.annotation.Autowired;

public class GreetingImple implements Greeting{

	private String msg;
	@Autowired
	NowTime nt;
	
	@Override
	public void printMsg() {
		System.out.println("현재시간 : " + nt.getTime() + msg);
	}
	
	public void setNt(NowTime nt) {
		this.nt = nt;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
