package Day6;

public class Super1 {
	int x;
	void p(int x, double y) {
		System.out.println("Super1 p() is called");
	}

}
