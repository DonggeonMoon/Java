package Day6;

public class Super2 extends Super1{
	String x;
	void p(int x, double y) {
		System.out.println("Super2 p() is called");
	}
}
