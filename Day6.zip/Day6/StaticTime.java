package Day6;

public class StaticTime {
	private static int sint = 0;
	static {
		sint = 100;
		System.out.println("sint:" + sint);		
	}//StaticTime 클래스명이 호출, 사용되는 순간 자동으로 1번만 실행됨.
	
	public static void main(String[]args) {
		StaticTime s = null;//StaticTime s 변수의 선언..
		StaticTime s1 = null;	
	}
}
