package Day6;

public class StaticMethod {
	private static int sint = 100;
	public int nint = 0;
	
	private static void setStaticInt(int x) {
		sint = x;
		System.out.println("ddddd");
	}
	
	public static int getStaticInt() {
		return sint;
	}
	
	public static void main(String[] args) {
		StaticMethod.setStaticInt(33333);
		// static method는 객체를 만들 필요가 없다. main 실행과 동시에 메모리에 생성되므로
		int s = StaticMethod.getStaticInt();//메모리에 존재하므로 호출해서 바로 사용
		System.out.println("static 값은:" + s);
		
		StaticMethod.setStaticInt(245);
		int s1 = StaticMethod.getStaticInt();
		System.out.println("static 값은:" + s1);
		
	}
}
