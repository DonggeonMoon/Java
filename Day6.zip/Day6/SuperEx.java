package Day6;

public class SuperEx {
	public static void main(String[] args) {
		Super2 s2 = new Super2();
		s2.p(100, 2.3);//오버라이딩된 메서드가 호출됨.
		s2.x = "자바 강좌";
		System.out.println("객체 s2에 들어 있는 x 값은:" + s2.x);
		Super1 s3 = new Super1();
		s3.x = 5000;
		System.out.println("객체 s2에 들어 있는 x 값은:" + s3.x);
		//서브 클래스의 변수와 슈퍼 클래스의 변수가 이름이 같을 때 
		//서브클래스의 변수가 적용이 되고 슈퍼클래스의 변수는 가려진다.
		 
	}
}
