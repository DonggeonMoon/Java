package Day6;
//멤버: 5, 변수: 3, 메서드: 2

public class People {
	String name;
	String juminId;
	String gender;
	
	public void sleep() {
		System.out.println("쿨쿨 잘 잡니다.");
	}
	
	public void eat() {
		System.out.println("음식을 맛있게 먹습니다.");
	}
	
}
