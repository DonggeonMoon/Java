package Day6;
//import java.lang.*; 자동으로 임포트 됨.
//상속 시에는 extends 키워드를 사용한다.
//public class 자식클래스명 extends 부모클래스명
//부모(super 또는 상위)클래스
//자바는 단일 상속만 가능. 부모클래스를 하나밖에 가질 수 없다.

public class Student extends Person{
	String studentId;//학번
	String major;//전공, 학과
	//overriding: 부모의 메서드를 자식에서 재정의하여 사용하는 것.
	//전제: 상속관계, 접귽제한자 리턴타입, 이름, 매개변수 전부 동일
	//{실행코드를 재정의하여 사용한다.}
	public Student(String name, int age, String studentId, String major) {
		super(name, age);//부모의 생성자. 부모의 생성자 먼저 호출 후 
		this.studentId = studentId;// 자식의 생성자가 생성됨.
		this.major = major;//super: 부모를 의미, this: 자신을 의미
	}
	public Student() {
		
	}
	public String getDetails(){
		return "이름: " + name + " , 나이:" + age + ", 학번: " + studentId + ", 학과:" + major;
	}
	
	public void printName() {
		System.out.println("이름:"+ name + "입니다.");
	}
}
