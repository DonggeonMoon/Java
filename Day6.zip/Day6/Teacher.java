package Day6;

public class Teacher extends Person{
	String teacherId;//교번
	String classId;// 과목
	
	public Teacher() {
	}
	
	public Teacher(String name, int age, String teacherId, String classId) {
		super(name, age);
		this.teacherId = teacherId;
		this.classId = classId;	
	}
	public String getDetails() {
		return "이름:" + name + ", 나이: " + age + ", 교번:" + teacherId + ", 과목: " + classId;
	}
}
