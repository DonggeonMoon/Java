package Day6;

public class Employee extends Person{
	String employeeId;//사번
	String department;//부서
	
	public Employee() {
	}
	
	public Employee(String name, int age, String employeeId, String department) {
		super(name, age);
		this.employeeId = employeeId;
		this.department = department;
	}
	
	public String getDetails() {
		return "이름:" + name + ", 나이: " + age + ", 사번:" + employeeId + ", 부서: " + department;
	}
}
