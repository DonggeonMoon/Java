package Day6;
//People 상속 받았으니 멤버 5개
public class Sister extends People {
	int hair;
	
	public void hairSwing() {
		System.out.println("긴머리 찰랑찰랑");
	}
}
