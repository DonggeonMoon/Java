package Day6;

public class PeopleEx {
	public static void main(String[] args) {
		
		People p = new People();//people형 p변수, 상속기반은 가능하다.
		Brother b = new Brother(); // People이 가지고 있는 메서드만 사용 가능.
		Sister s = new Sister();
		
		People p1 = new People();
		p1 = new Sister();
		p1.eat();
		p1.sleep();
		//p1.hairSwing();
		//People이 메서드가 없어서 호출 불가하다.
		//People 객체 자식 형태 객체 생성이 가능하지만, 자신이 가지고 있는 멤버만 접근이 가능한다. 
		
		//이종모음... 상속이 전제... 부모가 자식을 품을 수 있으니까 가능.(상속이므로 가능)
		People pArr[] = new People[3];
		pArr[0] = new People();
		pArr[1] = new Brother();
		pArr[2] = new Sister();
		
		for(int i = 0; i<pArr.length;i++) {
			System.out.println(pArr[i]);// 객체 정보만 나온다.
		}
		
		
		p.name = "이순신"; 
		p.juminId = "111100-1000000";
		p.gender = "male";
		System.out.println(p.name + ", " + p.juminId + ", " + p.gender);
		p.sleep();
		p.eat();
		System.out.println("----------------------------------------------");
		b.name = "홍길동";
		b.juminId = "111101-1020223";
		b.gender = "male";
		System.out.println(b.name + ", " + b.juminId + ", " + b.gender);
		b.sleep();
		b.eat();
		System.out.println("----------------------------------------------");
		s.name = "황진이";
		s.juminId = "111102-2012451";
		s.gender = "female";
		s.hair = 50;
		System.out.println(s.name + ", " + s.juminId + ", " + s.gender + ", "  + s.hair);
		s.sleep();
		s.eat();
		s.hairSwing();
		System.out.println("----------------------------------------------");
	}

}
