package Day6;
//public class Person (extends Object){
//Object는 자동으로 상속
// Object는 자바의 가장 최상위 조상격 클래스
// 다중 상속은 안 되지만, 할아버지 a -> 아버지, b-> a, b
// this, super 

public class Person { // extends Object 자동으로 생성된다.
	int age;
	String name;
	//public Person() {} 자동으로 생성
	
	public Person(String name, int age) {
		this.name = name;
		this.age= age;
	}
	public Person(String name) {
		this.name = name;
	}
	public Person() {
		this("noname", 1);
	}
	
	public String getDetails() {
		return "이름: " + name + " , 나이:" + age;
	}
}
