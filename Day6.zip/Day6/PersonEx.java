package Day6;

public class PersonEx {
	public static void main(String[] args) {
		Person p = new Person();
		Person p1 = new Person("고길동", 43);
		Student s = new Student();
		Student s1 = new Student("둘리", 10020, "20201001002", "고고학");
		Teacher t = new Teacher();
		Teacher t1 = new Teacher("도우너", 200, "201203", "천체물리");
		Employee e = new Employee();
		Employee e1 = new Employee("마이콜", 28, "2010221", "예체능부");
		
		
		p.age = 10;
		p.name = "희동이";
		
		s.studentId = " 210001001";
		s.major = "ComputerScience";
		s.age = 20;
		s.name = "홍길동";
		System.out.println("학번은: " + s.studentId + ", 전공은: " + s.major + ", 나이는: " + s.age + ", 이름은:" + s.name);
		
		e.employeeId = "2000001";
		e.department = "총무과";
		e.name = "허균";
		e.age = 35;
		System.out.println("사번은: " + e.employeeId + ", 부서는: " + e.department + ", 나이는: " + e.age + ", 이름은:" + e.name);
		
		t.teacherId = "1998002";
		t.classId = "국문학";
		t.name = "허난설헌";
		t.age = 45;
		System.out.println("교번은: " + t.teacherId + ", 부서는: " + t.classId + ", 나이는: " + t.age + ", 이름은:" + t.name);
		
		System.out.println(p.getDetails());
		System.out.println(s.getDetails());
		System.out.println(e.getDetails());
		System.out.println(t.getDetails());
		System.out.println(p1.getDetails());
		System.out.println(s1.getDetails());
		System.out.println(e1.getDetails());
		System.out.println(t1.getDetails());
		
	}

}
