package Day6;

public class Day5 {
	private int day;
	private int month;
	private int year;
	
	public Day5() {
		this.day = 17;
		this.month = 5;
		this.year = 2021;
	}
	
	public Day5(int day, int month) {
		this.day = day;
		this.month = month;
		this.year = 2021;
	}
	
	public Day5(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	public int getDay() {
		return this.day;
	}
	public void setDay(int day) {
		if (day < 1 || day > 31) {
			System.out.println("입력 값이 잘못되었습니다.");
			this.day = 1;
		} else {
		this.day = day;
		}
	}
	public int getMonth() {
		return this.month;
	}
	public void setMonth(int month) {
		if (month <1 || month > 12) {
			System.out.println("입력 값이 잘못되었습니다.");
			this.month = 1;
		} else { 
		month = this.month;
		}
	}
	public int getYear() {
		return this.year;
	}
	public void setYear(int year) {
		if (year <1900 || year > 2021) {
			System.out.println("입력 값이 잘못되었습니다.");
			this.year = 2021;
		} else {
		this.year = year;
		}
	}
}
