package Day6;
//이종 모음: 다른 것들의 모임.
//배열: '같은' 데이터 타입이 여러 개 '순서대로' 모인 자료공간..
//Person() int age, String name, public String getDetails()
//다형성을 배열에 적용하면 배열이 다른 타입 객체를 가질 수 있다.
public class HeteroCollectionEx {
	public static void main(String[] args) {
		Person pArr[] = new Person[4];//4개짜리 공간을 가진 Person 타입의 배열
		
		pArr[0] = new Person("홍길동", 20);
		pArr[1] = new Student("허현수", 17, "20102112", "국문과");
		pArr[2] = new Student("허균", 50, "199502112", "국문과");
		pArr[3] = new Student("허난설헌", 30, "20102112", "예술과");
		
		for(int i = 0; i<pArr.length; i++) {
			System.out.println(pArr[i].getDetails());
		}
	}
}
