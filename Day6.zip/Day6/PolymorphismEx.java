package Day6;
/*
다형성, 다형적 객체, 상속 전제
부모는 자식의 객체 타입을 가질 수 있다.
 */
public class PolymorphismEx {
	
	public static void main(String[] args) {
		Person p;//Person p라는 변수 선언
		//Person p1 = new Person();
		//Student t = new Student();
		
		p = new Student("홍길동", 28, "202101002", "체육학과");// 다형적, 다형성
		System.out.println(p.getDetails());
		//student의 오버라이딩된 p.getDetails() 호출됨.
		//p.printName(); 자식의 고유의 메서드는 호출 불가.
		p = new Teacher("허균", 45, "201001010", "국문학과");// 상속의 경우 가능.
		System.out.println(p.getDetails());
		//teacher의 오버라이딩된 p.getDetails() 호출됨.
		p = new Employee("허난설헌", 38, "201111", "총무과");// 부모는 자식의 객체 타입을 가질 수 있다.
		System.out.println(p.getDetails());
		//employee의 오버라이딩된 p.getDetails() 호출됨.
	}

}
