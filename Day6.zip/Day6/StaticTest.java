package Day6;
//static: main 메서드, sint 멤버 변수 프로세스가 생성될 때, 매모리에 존재
//sint = 0 + 1, 1 + 1, 2 + 1 = 3, ... 9 + 1 = 10
//static 한번 생성되면 다시 생성되지 않는다. 
public class StaticTest {
	private static int sint = 0;// static 키워드
	//메인이 실행될 때 같이 메모리에 업로드 된다. 
	private int nint = 0;
	
	public StaticTest() {
		sint = sint + 1;
		nint = nint + 1;			
	}
	
	public void sayMember() {
		System.out.println("sint:" + sint + ", nint:" + nint);
	}
	
	public static void main(String[] args) {
		for(int i = 0; i < 10; i++) {
			StaticTest s = new StaticTest();
			s.sayMember();
		}
	}
}
