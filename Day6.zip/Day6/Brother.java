package Day6;
//People 상속 받았으니 멤버 5개
//메서드가 오버라이딩이 되면, 오버라이딩된 메서드가 동작한다.
//부모의 메서드는 가려진다.(동작하지 않는다.)
public class Brother extends People {
	public void sleep() {
		System.out.println("뒤척이다 잠을 겨우 잡니다.");
	}//메서드가 오버라이딩됨.
	// 접근제한자, 리턴타입, 메서드 이름, 매개변수 모두 같아야 한다.
	//{구현부만 재정의해서 사용한다.}
	
	public void eat() {
		System.out.println("음식도 깨작깨작 먹습니다.");
	}//메서드가 오버라이딩됨.
	
}
