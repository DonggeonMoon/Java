package Day6;

// static: 프로그램이나 프로세스가 시작될 때,  static 키워드가 붙은 멤버변수나 메서드, 스태틱 블럭 등은 자동으로 메모리에 업로드된다.  

public class Day5Ex {
	
	public static void main(String[] args) {
		Day5 myDay = new Day5();
		myDay.setDay(36);
		myDay.setMonth(13);
		myDay.setYear(3000);
		
		System.out.println(myDay.getYear() + "년 " + myDay.getMonth() + "월 " + myDay.getDay() + "일");
		
		Day5 nopar = new Day5();
		System.out.println(nopar.getYear() + "년 " + nopar.getMonth() + "월 " + nopar.getDay() + "일");
		
		Day5 dm = new Day5(1, 1);
		System.out.println(dm.getYear() + "년 " + dm.getMonth() + "월 " + dm.getDay() + "일");
		
		Day5 dmy = new Day5(1, 1, 2000);
		System.out.println(dmy.getYear() + "년 " + dmy.getMonth() + "월 " + dmy.getDay() + "일");
	}
}
