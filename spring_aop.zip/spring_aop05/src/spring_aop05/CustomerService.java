package spring_aop05;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
