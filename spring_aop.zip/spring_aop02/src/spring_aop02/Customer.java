package spring_aop02;

public interface Customer {
	public void printName();
	public void printEmail();
}
