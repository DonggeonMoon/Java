package basic;

public class script {

}
