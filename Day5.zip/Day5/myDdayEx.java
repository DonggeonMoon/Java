package Day5;
/*
1. 은닉화
방법: 멤버변수를 private 제한자로 선언,
	멤버변수를 public method로 접근하는 방법
	getXXX -> getter, setXXX -> setter
 */
public class myDdayEx {
	public static void main(String[] args) {
		myDday md = new myDday();
		md.setYear(2011);
		md.setMonth(12);
		md.setDay(11);
		md.setMessage("메시지");
		
		System.out.println(md.getYear() + "년 " + md.getMonth() + "월 " + md.getDay() + "일: " + md.getMessage());
	}
}
