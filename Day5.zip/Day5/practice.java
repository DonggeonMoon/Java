package Day5;

public class practice {

}
