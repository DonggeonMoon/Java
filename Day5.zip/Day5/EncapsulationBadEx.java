package Day5;

public class EncapsulationBadEx {
	public static void main(String[] args) {
		EncapsulationBad myBirth = new EncapsulationBad();
		myBirth.day = 38;
		myBirth.month = 14;
		myBirth.year = 3300;
		
		System.out.println(myBirth.year + "년 " + myBirth.month + "월 " + myBirth.day + "일");
	}

}
