package Day5;
//getXXX, setXXX 형식의 메서드를 선언해서
//멤버 변수에 접근하도록 하는 방식을 사용
//은닉화(encapsulation)

public class EncapsulationGood {

	private int day;// 1~31
	private int month;// 1~12
	private int year;//1900~2070
	
	public int getDay() {
		return day;
	}
	public void setDay(int a) {
		if((a<0)||(a>31)) {
			System.out.println("잘못된 값을 입력했습니다.");
			day = 1;
		} else {
			day = a;
		}
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int b) {
		if((b<1)||(b>12)) {
			System.out.println("잘못된 값을 입력했습니다.");
			month = 1;
		} else {
			month = b;
		}
	}
	public int getYear() {
		return year;
	}
	public void setYear(int c) {
		if((c<1900)||(c>2021)) {
			System.out.println("잘못된 값을 입력했습니다.");
			year = 1;
		} else {
			year = c;
		}
	}
}
