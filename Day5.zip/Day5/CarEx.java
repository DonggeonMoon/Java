package Day5;

public class CarEx {
	public static void main(String[] args) {
		
		Car c1 = new Car("카니발");
		System.out.println("차종:" + c1.getName() + " 가격:" + c1.getPrice() + "원");
		
		Car c2 = new Car("제네시스");
		System.out.println("차종:" + c2.getName() + " 가격:" + c2.getPrice() + "원");
		
		Car c3 = new Car("산타페" , 40000000);
		System.out.println("차종:" + c3.getName() + " 가격:" + c3.getPrice() + "원");
		
		// Car sta = new Car(100) 선언되지 않은 타입의 생성자는 에러
	}
}
