package Day5;
/*
overloading: 가틍ㄴ 이름을 가진 메서드의 중복정의 방법
오버로딩의 조건:
1. (매개변수) 개수를 다르게 한다.
2. 매개변수의 데이터 타입을 다르게 한다.
3. 둘 다 또는 하나만 조건이 만족해도 된다.
4. (전제조건) 같은 클래스에서만 적용된다.



 */
public class TestReferenceEx {
	public static void main(String[] args) {
		TestReference hong;// Testreference(클래스) 자료형 hong이라는 변수명으로 선언
		hong = new TestReference();
		hong.setName("홍길동");
		hong.setAge(30);
		hong.setTelephone("010-1111-2222");
		System.out.println(hong.getAge() + hong.getName() + hong.getTelephone());
		
		TestReference kim = new TestReference();
		kim.setName("김삿갓");
		kim.setAge(40);
		kim.setTelephone("없음");
		System.out.println(kim.getAge() + kim.getName() + kim.getTelephone());
		
		TestReference babo;//babo 홍길동의 별명
		babo = hong;// 값(value)이 복사되는 것이 아니고,
					//hong이 저장된 주소의 값이 참조된다. 주소값이 저장됨.
		
		System.out.println(babo.getAge() + babo.getName() + babo.getTelephone());
	}
}
