package Day5;

public class SumMul {
	private int mul;
	private int sum;
	
	public void setValue(int x, int y) {
		sum = x + y;
		mul = x * y;
	}
	
	public int getValue() {
		int s = sum + mul;
		return s;
	}
}
