package Day5;

public class PenEx {
	public static void main(String[] args) {
		Pen Pen = new Pen();
		System.out.println("펜의 색은" + Pen.getColor() + "입니다.");
		
		Pen redPen = new Pen("red");// 생성자는 일종의 모델, 샘플이다.
		System.out.println("펜의 색은" + redPen.getColor() + "입니다.");
		
		Pen exPen = new Pen("black", 20000);
		System.out.println("펜의 색은" + exPen.getColor() + "입니다.");
		System.out.println("펜의 가격은" + exPen.getPrice() + "입니다.");
		
	}

}
