package Day5;
// overloading: 같은 클래스에서 메서드의 중복 정의 
// 오버로딩의 성립조건이 파라미터 타입이 다르거나, 또는 타입이 같으면 파라미터 개수가 다른 경우

public class OverloadingTrain {
	double mul(int a, int b) {
		return a * b;
	}
	
	double mul(int a) {
		return a;
	}
	
	double mul(double a, double b) {
		return a * b;
	}
	
	double mul(double a) {
		return a;
	}
		
	public static void main(String[] args) {
		
		OverloadingTrain ol = new OverloadingTrain();
		System.out.println("두 정수(10, 20): " + ol.mul(10, 20));
		System.out.println("하나의 정수(10): " + ol.mul(10));
		System.out.println("두 실수(10.1, 20.1): " + ol.mul(10.1, 20.2));
		System.out.println("하나의 실수): " + ol.mul(10.1));
		
	}

}
