package Day5;

/*
overloading: 같은 클래스에서 메서드가 중복으로 정의되어 사용하는 기법
조건1. 매개변수의 숫자가 다를 것.(매개변수의 타입이 같을 경우) 
조건2. 매개변수의 타입이 다를 것.
조건3. 둘 다 달라도 된다.
조건4. 리턴 타입은 상관없음.
 */

public class OverloadingEx {	
	public int plus(int a, int b) {
		return a + b;
	}
	
	public int plus(int c) {
		return c;
	}
	
	public double plus(double a, double b) {
		return a + b;
	}
	
	public char plus(char a, char b) {
		return (char) (a + b);
	}
	
	public String plus(String a, String b) {
		return a + b;
	}
	
	public static void main(String[] args) 	{
		OverloadingEx oc = new OverloadingEx();
		int i = oc.plus(10);
		int j = oc.plus(10, 20);
		double d= oc.plus(10.1, 2.3);
		char c = oc.plus('A', 'B');
		String str = oc.plus("Hello ", "World");
		
		System.out.println(i + " ");
		System.out.println(j + " ");
		System.out.println(d + " ");
		System.out.println(c + " ");
		System.out.println(str + " ");
		
		
	}
}
