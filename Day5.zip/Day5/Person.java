package Day5;

public class Person {
	public int age;
	public long height;
	private float weight;
	
	float setWeight(float a) {
		return a;
	}
	// (default): 접근제한자가 생략되어 있다. 같은 패키지, 같은 클래스에서 접근 가능
	//private: 같은 클래스에서만 접근 가능;
}
