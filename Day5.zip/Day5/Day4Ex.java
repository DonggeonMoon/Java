package Day5;

public class Day4Ex {
	public static void main(String[] args) {
		Day4 d1 = new Day4();
		d1.age = 20;
		d1.name = "홍길동";
		d1.address = "서울시 구로구";
		d1.phone = "010-1111-1111";
		
		System.out.println("이름:" + d1.name);
		System.out.println("나이:" + d1.age);
		System.out.println("주소:" + d1.address);
		System.out.println("전화번호:" + d1.phone);
		
		System.out.println(d1.add(10, 20));
		
		Day4 d2 = new Day4();
		d2.age = 25;
		d2.name = "김영희";
		d2.address = "서울시 중구";
		d2.phone = "010-2222-2222";
		
		System.out.println("이름:" + d2.name);
		System.out.println("나이:" + d2.age);
		System.out.println("주소:" + d2.address);
		System.out.println("전화번호:" + d2.phone);
		
		System.out.println(d2.add(10, 20));
		
		
		
	}
}
