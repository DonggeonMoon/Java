package Day5;

public class SumMulEx {
	public static void main(String[] args) {
		SumMul sm = new SumMul();
		sm.setValue(3, 5);
		int s = sm.getValue();
		System.out.println(" 두 수의 합과 곱을 더한 합은 :" + s);
	}
}