package Day5;

public class PersonEx {
	public static void main(String[] args) {
		Person brother = new Person();
		brother.age = 30;
		brother.height = 180L;
		brother.setWeight(80.5f);
		
		System.out.println("나이: " + brother.age);
		System.out.println("키: " + brother.height);
		System.out.println("몸무게: " + brother.setWeight(80.5f));
		
	}
}
