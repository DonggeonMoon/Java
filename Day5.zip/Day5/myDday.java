package Day5;

public class myDday {
	private int year;
	private int month;
	private int day;
	private String message;
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		if ((year < 1900) || (year < 2021)) {
			System.out.println("잘못된 값을 입력하였습니다.");
			this.year = 2021;
		} else {
			this.year = year;
		}
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		if ((month < 1) || (month < 12)) {
			System.out.println("잘못된 값을 입력하였습니다.");
			this.month = 1;
		} else {
			this.month = month;
		}
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		if ((day < 1) || (year < 31)) {
			System.out.println("잘못된 값을 입력하였습니다.");
			this.day = 1;
		} else {
			this.day = day;
		}
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	

}
