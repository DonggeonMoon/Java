package Day5;

public class EncapsulationGoodEx {
	public static void main(String[] args) {
		EncapsulationGood myBirth = new EncapsulationGood();
		myBirth.setDay(31);
		myBirth.setMonth(3);
		myBirth.setYear(1900);
		
		System.out.println(myBirth.getYear() + "년 " + myBirth.getMonth() + "월 " + myBirth.getDay() + "일");
	}

}
