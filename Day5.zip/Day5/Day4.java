package Day5;
/* 
JDK : JRE(Java Runtime Environment) + 개발 도구
JVM : 자바 가상 머신, 자바의 모든 것을 처리. 모든 것을 JVM 처리

stack: fifo, queue: lifo


 */

public class Day4 {
	int age;
	String name;
	String address;
	String phone;
	
	public int add(int x, int y) {
		int c = x + y;
		return c;
	}
	
}
