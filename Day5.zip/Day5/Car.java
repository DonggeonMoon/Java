package Day5;

public class Car {
	private String name = "소나타";
	private int price;
	
	public Car() {
		
	}
	
	public Car(String model) {
		name = model;
	}
	
	public Car(String model, int money) {
		name = model;
		price = money;
		
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
