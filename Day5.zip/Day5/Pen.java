package Day5;

public class Pen {
	private String color;
	private int price;
	
	public Pen() {
		color = "black";
		System.out.println("생성자를 이용하여 color 값을 초기화함");
	}// 생성자 메서드 리턴타입 없음, 클래스 이름이 동일.
	
	
	public Pen(String str) {
		color = str;
		System.out.println("생성자를 이용하여 color 값을 초기화함");
	}
	
	public Pen(String str, int x) {
		color = str;
		price = x;
		System.out.println("생성자를 이용하여 color 값을 초기화함");
	}//오버로딩 
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	

}
