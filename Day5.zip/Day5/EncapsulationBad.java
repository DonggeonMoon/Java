package Day5;

public class EncapsulationBad {

	public int day;// 1~31
	public int month;// 1~12
	public int year;//1900~2070
}
