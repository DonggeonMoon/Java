package Day9;

import java.io.*;

public class MyException extends Exception{
	
	public String toString() {
		return("글자를 입력하세요.");
	}
	public void reInput() {
		try {
			String str = null;
			InputStreamReader isr;
			BufferedReader br;
			isr = new InputStreamReader(System.in);
			br = new BufferedReader(isr);
			System.out.println("read:" + str.toString());
			if(str.hashCode() == 0) throw new MyException();
			
		} catch(MyException e) {
			System.out.println(e.toString());
			e.reInput();
		}
	}

}
