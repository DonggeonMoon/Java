package Day9;

import java.util.*;
//Iterator : Object형 자료를 받는다, DownCasting을 해서 사용해야됨
//String str = (String)iter.next();
//<String>쓰면(제네릭 String) DownCasting 생략 가능.
//String str = iter.next();

public class SetIterEx {
	
	public static void main(String[] args) {
		HashSet<String> set = new HashSet<String>();
		set.add("lee"); //0
		set.clear();
		set.add("cho"); //1
		set.add("kim"); //2
		set.add("min"); //3
		set.add("chung"); //4
		set.add("min"); //3동일, 중복 불가
		System.out.println(set.size());
		System.out.println(set.contains("chung"));
		
		set.remove("kim");
		System.out.println(set.size());
		
		System.out.println("---------------");
		
		print(set);// Set set 객체 변수
		System.out.println("---------------");
		print(set.toArray());//set를 Object[]로 만듦
		
	}
	
	//iterator: 열거자 인터페이스, set 계열들을 받아서 하났기 출력해주는 역할. 
	public static void print(Set<String> set) {
		Iterator<String> iter = set.iterator(); 		
		while(iter.hasNext()) {//Iterator 다음 요소가 있을 때까지
			System.out.println("----------");
			String str = (String) iter.next();// iter에 다음 요소를 받아준다.)
			System.out.println(str);//출력, 반복횟수를 모를때
		}// index는 없다. 
	}
	
	public static void print(Object[] obj) {
		int count = obj.length;
		for(int i = 0; i < count; i++) {
			System.out.println(obj[i]);
		}
	}
}
