package Day9;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

public class IOEx6 {

	public static void main(String[] args) throws IOException{
		
		File f = new File("C:/javawork/primitive.txt");
		FileOutputStream fos = new FileOutputStream(f);
		FileInputStream fis = new FileInputStream(f);
		
		
		//저장은 txt로 되어 있지만, Data형태로 저장되게 하는 클래스
		DataOutputStream dos = new DataOutputStream(fos);
		dos.writeUTF("홍길동");//String 입력 시 사용
		dos.writeInt(20);// Int입력
		dos.writeDouble(183.3);//double 입력
		dos.writeBoolean(false);//boolean 입력 시 사용
		
		//Data 형태로 저장된 파일을 읽어 오는 클래스
		DataInputStream dis = new DataInputStream(fis);
		
		String name = dis.readUTF(); //String을 읽엉는 메서드
		int age = dis.readInt();//int를 읽어오는 메서드
		double height = dis.readDouble();//double을 읽어오는 메서드
		boolean isChange = dis.readBoolean();// boolean 읽어오는 메서드
		
		System.out.println("캐릭터명 : " + name);
		System.out.println("나   이 : " + age);
		System.out.println("신   장 : " + height);
		System.out.println("전직유무 : " + isChange);

	}

}
