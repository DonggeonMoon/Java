package Day9;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedInputStream;
import java.io.FileWriter;
import java.io.IOException;

public class IOEx2 {
	public static void mains(String[] args) throws IOException {
		
		File f = new File("C:/javawork/time.txt");
		File f2 = new File("C:javawork/timecopy.txt");
		
		FileReader fr = new FileReader(f);
		FileWriter fw = new FileWriter(f2);
		
		int v = 0;
		while((v=fr.read()) !=-1){
			fw.write(v);
			System.out.println((char) v);
		}
		
		fw.flush();
		fr.close();
		
		
	}
}
