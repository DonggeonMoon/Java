package Day9;

public class practice {
	public static void main(String[] args) {
		System.out.println(System.in.getClass());
	}
}