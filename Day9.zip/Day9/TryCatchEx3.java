package Day9;

import java.io.*;

public class TryCatchEx3 {
	public static void main(String[] args) {
		InputStream in = null;
		try {
			in = new FileInputStream(new File("a.txt"));
		} catch(FileNotFoundException e) {
			System.err.println("FileNotFoundException");
			System.err.println(e.getMessage());
			System.out.println("-------------------------------");
			System.err.println(e.toString());
			System.out.println("-------------------------------");
			e.printStackTrace();
		} catch(IOException e) {
			System.err.println("IOException");
			System.err.println(e.getMessage());
			System.out.println("-------------------------------");
			System.err.println(e.toString());
			System.out.println("-------------------------------");
			e.printStackTrace();
		} catch(Exception e) {
			System.err.println("Exception");
			System.err.println(e.getMessage());
			System.out.println("-------------------------------");
			System.err.println(e.toString());
			System.out.println("-------------------------------");
			e.printStackTrace();
		} finally {
			System.out.println("finally 수행");
		}
	}

}
