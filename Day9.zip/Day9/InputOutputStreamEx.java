package Day9;

import java.io.*;
public class InputOutputStreamEx {
	public static void main(String[] args) throws IOException {
		System.out.println("아무 글이나 입력하고 Enter를 치세요");
		System.out.println("'S'를 입력하면 프로그램이 종료됩니다.");
		
		int ch;
		InputStream in = System.in;
		OutputStream out = System.out;
		while((ch = in.read()) != -1){
			if (ch == 'S') { //대문자 S가 들어오면 
				byte[] arr = new byte[4];
				arr[0] = 83; //S
				arr[1] = 84; //T
				arr[2] = 79; //O
				arr[3] = 80; //P
				out.write(arr);
				out.flush(); //작업한 메모리를 비워내라
				out.close(); //자원 반납
				System.exit(-1);//프로세스를 종료해라, (-1) 완전 종료
			}
			System.out.println("Char: " + (char)ch + ", Available: " + in.available());
			
			
		}
	}
}
