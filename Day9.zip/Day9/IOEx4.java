package Day9;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class IOEx4 {
	public void main(String[] args) throws IOException {
		File f = new File("C:/javawork/keyboard.txt");
		FileOutputStream fos = new FileOutputStream(f);
		//2byte 문자가 깨지지 ㅇ낳고 저장된다.
		//Buffered Writer
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		
		InputStreamReader isr = new InputStreamReader(System.in);
		
		System.out.println("내용을 입력하세요(끝내려면 ctrl+z");
		int v= 0;
		while(((v=isr.read()) != -1)){
			bos.write(v);
			System.out.println((char) v);
		}
		
		bos.flush();
		bos.close();
		
		System.out.println("종료되었습니다.");
		
	}
}
