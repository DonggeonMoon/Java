package Day9;

import java.io.*;

public class IOEx1 {
	public static void main(String[] args) throws IOException {
		File f = new File("c:/javawork/HelloWorld.java");
		File f2 = new File("c:/javawork/CopyHelloWorld.java");
		
		//파일에 접근해서 읽어 오는 클래스
		FileInputStream fis = new FileInputStream(f);
		//접근 속도를 향상시킬 수 있는 입력계열 클래스
		BufferedInputStream bis = new BufferedInputStream(fis);
		
		//파일에 접근해서 출력, 저장하는 클래스
		FileOutputStream fos = new FileOutputStream(f2);
		//접근 속도를 향상시킬 수 있는 출력 계열 클래스
		BufferedOutputStream bos = new BufferedOutputStream(fos);
		
		//char 자료형은 문자 한글자이지만, 글자 하나가 정수로 매칭되어 있어서
		//정수를 받을 수 있다.
		int v = 0;
		while((v=bis.read()) != -1) {//bis.read() != -1의 의미는 값이 없다는 것. 값이 있을 동안 반복한다.)
			bos.write(v);
			System.out.print((char) v);
		}
		bos.flush();// buffer(메모리)에 있는 내용을 내려쓰라는 메서드이다.
	}

}
