package Day9;

import java.io.*;

public class ThrowEx {
	public static void main(String[] args) {
		String str = null;
		InputStreamReader isr;
		BufferedReader br;
		
		try {
			isr =new InputStreamReader(System.in);
			br = new BufferedReader(isr);
			str = br.readLine();//BufferedReader에서 읽어들인 한줄의 값을 저장.
			System.out.println("입력 문자:" + str.toString());
			//toString(): 문자열로 값을 내보냄.
			if(str.hashCode() == 0) throw new MyException();
		}catch(MyException e) {
			System.out.println(e.toString());
			e.reInput();
		}catch(Exception e) {
			System.out.println(e.toString());
		}
		System.out.println("프로그램의 종료");
		
	}
}
