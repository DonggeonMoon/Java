package Day9;

import java.util.*;

public class MapIterEx {
	public static void main(String[] args) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("0", "lee"); //0
		map.clear();
		map.put("1", "cho"); //1
		map.put("2", "kim"); //2
		map.put("3", "min"); //3
		map.put("4", "chung"); //4
		map.put("5", "min"); //3동일, 중복 불가
		System.out.println(map.size());
		System.out.println(map.containsValue("chung"));
		map.remove("2");//key 2값 제거
		
		print(map);
	}
	
	public static void print(Map<String, String> sets) {
		Set<String> set = sets.keySet();
		Iterator<String> iter = set.iterator();
		while(iter.hasNext()){
			String key = iter.next();
			System.out.println(key + " "+ sets.get(key));
			//sets.get(key): key값으로 value값을 읽어옴.
		}
	}
}
