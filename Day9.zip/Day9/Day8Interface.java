package Day9;
//변수는 상수처리(final static), 메서드는 추상클래스(public abstract)
//자신의 객체 생성 불가, 상속받는 자식의 형태로 객체 생성하여 사용.
public interface Day8Interface {
	
	void walk();//public abstract 생략.
	void run();
}
