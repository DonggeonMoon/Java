package Day9;

public class TryCatchEx1 {
	public static void main(String[] args) {
		String sNum = "123";
		String nNum = "h";
		
		try {//에러가 발생할 수 있는 코드를 작성한다.
			int a = Integer.parseInt(nNum);
			//Integer(int wrapper class).parseInt(sNum)
			//parseInt: 문자형으로 된 숫자를 정수로 변환시켜 리턴.
			System.out.println(a);
		} catch(NumberFormatException a) {
			System.out.println("int인지 확인해 보세요");
		}
		catch (Exception e) {
			System.out.println("기타 에러");
		} finally {
			System.out.println("에러던 말던 무조건 실행");
		}
		
		System.out.println("끝까지 실행됨!!");
	}
}
