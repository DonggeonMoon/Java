package Day9;

public class Day8Logic extends Day8Abstract implements Day8Interface {
	
	@Override
	public void walk() {
		speed = 10; 
		System.out.println("걷습니다. 현재속도:" + speed + distance);
	}

	@Override
	public void run() {
		speed = 15;
		System.out.println("걷습니다. 현재속도:" + speed  + distance);
	}

	@Override
	public void fly() {
		speed = 30;
		System.out.println("걷습니다. 현재속도:" + speed  + distance);
	}

	@Override
	public void sea() {
		speed = 25;
		System.out.println("바다 위를 이동합니다. 현재속도:" + speed + distance);
	}
}