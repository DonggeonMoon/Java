package Day9;

public class TryCatchEx2 {
	public static void main(String[] args) {
		String sNum = "123";
		String nNum = "h";
		
		try {
			int a = Integer.parseInt(nNum);
			System.out.println(a);
			
		} catch(Exception e) { //Exception 모든 예외 처리, 가장 상위 exception
			System.out.println("==>에러 !!!");
			System.out.println(e +"<==");
		} finally {
			System.out.println("next!!");
		}
		
		try {
			int x = 5;
			int y = 20/(5-x); //돌려보기 전에는 모른다.
			
		} catch(ArithmeticException e) {// 0으로 나누면 안 된다. 
			System.out.println("혹시 0으로 나누셨나요?");
			e.printStackTrace()
;
		}
	}
}
