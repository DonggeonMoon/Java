package Day9;
// 추상 클래스: 추상메서드 하나 이상 존재하면 추상클래스가 된다.
// 일반 멤버 변수, 일반 메서드 선언 가능.
public abstract class Day8Abstract {
	
	int speed;
	String distance = " 거리를 이동하였습니다.";
	
	public abstract void fly();
	public void sea() {};
}
