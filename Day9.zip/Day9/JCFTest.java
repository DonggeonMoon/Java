package Day9;

import java.util.*;
//import java.util.*; java.util.* 패키지의 모든 클래스를 불러와서 사용하겠다.
//<> 제네릭: <String> 안에 해당하는 String 데이터만 입력받겠다.
// 			<int> 안에 해당하는 int형 데이터만 입력받겠다.
public class JCFTest {
	
	public static void main(String[] args) {
		Set<String> set = new HashSet<String>();//Set 인터페이스
		set.add("lee");
		set.add("lee");
		System.out.println(set);
		System.out.println("--------------------------");
		
		List<String> list = new ArrayList<String> ();//List 인터페이스
		list.add("lee");//index: 0
		list.add("lee");//index: 1 중복 허용
		list.set(0, "cho");//set(인덱스, 값), 바뀔 인덱스 번호, 바뀔 값
		System.out.println(list);
		System.out.println("--------------------------");
		
		Map<String, String> map = new HashMap<String, String> ();
		map.put("1", "kim");
		map.put("1", "cho");// 중복 안 됨, key 값이 덮어씀.
		map.put("2", "lee");
		System.out.println(map);
	
		
	}

}
