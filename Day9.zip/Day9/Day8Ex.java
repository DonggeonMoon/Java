package Day9;

public class Day8Ex {
	
	public static void main(String[] args) {
	Day8Logic dl = new Day8Logic();
	dl.walk();
	dl.run();
	dl.fly();
	dl.sea();
	}
}
