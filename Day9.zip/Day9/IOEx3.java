package Day9;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileNotFoundException;

public class IOEx3 {

	public static void main(String[] args) throws IOException {
		File f = new File("C:/javawork/time.txt");
		File f1 = new File("C:javawork/timecopy.txt");
		
		FileReader fr = new FileReader(f);
		FileWriter fw = new FileWriter(f1);
		
		BufferedReader br = new BufferedReader(fr);
		BufferedWriter bw = new BufferedWriter(fw);
		
		String s;
		while((s=br.readLine()) != null){
			fw.write(s);
			bw.newLine();
			System.out.println(s);
			
		}
		
		fw.flush();
		fr.close();

	}

}
