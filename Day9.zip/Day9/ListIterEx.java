package Day9;

import java.util.*;

public class ListIterEx {
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("lee"); //0
		list.clear();
		list.add("cho"); //1
		list.add("kim"); //2
		list.add("min"); //3
		list.add("chung"); //4
		list.add("min"); //3동일, 중복 불가
		System.out.println(list.size());
		System.out.println(list.contains("chung"));
		
		list.remove("kim");
		list.remove(3);
		System.out.println(list.size());
		System.out.println(list.indexOf("min"));
		
		print(list);
		print(list.toArray());
		List<String> sublist = list.subList(0, 2);
		
		System.out.println("------------");
		print(sublist);
		System.out.println("------------");
		printGet(list);
	}
	
	public static void print(List<String> obj) {
		Iterator iter = obj.iterator();
		while(iter.hasNext()){
			String str = (String)iter.next();
			System.out.println(str);
		}
	}
	
	public static void print(Object[] obj) {
		for (int i = 0; i<obj.length;i++) {
			System.out.println(obj[i]);
		}			
	}
	
	public static void printGet(List<String> list) {
		int count = list.size();
		for (int i = 0; i<count;i++) {
			System.out.println(count);
		}
	}


}
