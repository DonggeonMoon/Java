package Day2;
/*
while (boolean 조건식) {
	처리식 A;
	증감식;
}
조건식이 참인 동안에 반복해라.
 */

public class WhileEx1 {

	public static void main(String[] args) {
		//1에서 10까지 더하는 프로그램을 작성해보자.
		int sum = 0;
		int i = 1;
		while (i<=10) {
			sum += i; //1 +2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10 = 55
			i++;//조건을 만족 시키기 위해 증가식을 사용한다
		}
		System.out.println("1에서 10까지의 합은: " + sum);
	}

}
