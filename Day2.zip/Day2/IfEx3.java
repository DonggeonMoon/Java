package Day2;
/*
중첩 if문
if(boolean 조건식1) {
	if(boolean 조건식1) {
		실행문 A-1;
	} else {
		실행문 A-2;
		......
	}
} else {
	실행문 B;
	......
}
 */

public class IfEx3 {

	public static void main(String[] args) {
		int jumsu = (int)(Math.random() * 110);
		System.out.println("당신의 점수는: " + jumsu);
		
		if (jumsu > 90) {
			if(jumsu > 100) { 
				System.out.println("잘못된 점수를 입력하였습니다.");
			} else {
				System.out.println("당신의 학점은 A학점입니다.");
			}
		} else if (jumsu >= 80) {
			if (jumsu >= 85) {
				System.out.println("당신의 학점은 B+입니다.");
			}
			System.out.println("당신의 학점은 B입니다.");
		} else if (jumsu >= 70) {
			System.out.println("당신의 학점은 C입니다.");
		} else if (jumsu >= 60) {
			System.out.println("당신의 학점은 D입니다.");
		} else {
			System.out.println("당신의 학점은 F입니다.");
			System.out.println("재수강 대상입니다.");
		}
	}
}
