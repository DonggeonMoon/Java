package Day2;

public class AssignmentEx {
// = 기본 기호이다. a = b ; b의 값을 a에 대입해라. 연산자 우선순위 가장 낮다.
// =, +=, -=, *=, /=, %=가 주로 쓰인다.
	
	public static void main(String[] args) {
		int a = 5; // a에 5를 대입해라.
		int b = 5; // b에 5를 대입해라.
		a += 3;// a = a + 3; a + 3 -> a =8
		b =+ 3;// b = + 3 -> b = +3 순서를 잘지켜서 작성해야 한다. 
		
		b -= 1;// b = b - 1; b = 3 - 1; b = 2
		
		b *= 2;// b = 2 * 2; b = 4
		
		b /= 2;// b = 4 / 2; b = 2
		
		b %=2;// b = 2 % 2; b = 0
		
		System.out.println("a의 값은 :" + a + ", b의 값은 :" + b);
	}
}
