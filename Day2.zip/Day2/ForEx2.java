package Day2;
/*
중첩 for문
for(최기값; 조건식; 증감식){
	for(초기값; 조건식; 증감식){
		처리식B
	}
	처리식A
}
 */

public class ForEx2 {
	//외부for 1, 내부for ~2~9 반복, 외부 for2 ,내부 for 2~9 반복.....
	//외부for가 1 증가 후 내부for가 지정된 반복 횟수 만큼 반복 후, 외부 for 증가...
	public static void main(String[] args) {
		for (int i= 2; i<=9; i++) {// 곱한는 수 1~9
			for (int j = 2; j<10; j++) {// 단부분
				System.out.printf("%d*%d=%2d\t", j, i, i*j);
				//print: 지정된 형식으로 프린트 해라..
				//"%d*%d=%2\t" -> j* i = i*j \t: tab만큼 띄어쓰기.
			}
			System.out.println();// 다음 줄로 이동.
		}

	}

}
