package Day2;

public class ReturnEx {

	public static void main(String[] args) {
		int a = 20;
		int b = 30;
		System.out.println("넓이는: " + calcRect(a, b));

	}
	
	//메서드 생성
	public static int calcRect(int width, int height) {
		return (width * height);
		// return: 처리한 결과 값을 호출한 곳에 돌려주는 역할..., 메서드가 종료... 
	}

}
