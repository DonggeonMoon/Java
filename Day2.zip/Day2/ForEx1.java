package Day2;
/* 
for(초기값; boolean 조건식; 증감식) {
	실행문A;
}
 */
//1~10까지 합을 구하자.
public class ForEx1 {
	public static void main(String[] args) {
		int sum = 0;
		for(int i = 0; i <= 10; i++) {
			sum = sum + i;//
		}
		System.out.println("1에서 10의 합은: " + sum);
	}

}
