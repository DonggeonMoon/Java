package Day2;

import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class test {
	public static void main(String[] args) {
	JFrame frame = new JFrame("제목");
	JLabel label = new JLabel("Hello World");
	frame.setPreferredSize(new Dimension(500, 300));
	frame.add(label);
	frame.pack();
	frame.setVisible(true);
	}
}
