package Day2;

import java.util.Scanner; //키보드 입력을 받는 클래스

public class ReverseWord {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);// 키보드 입력을 받겠다.
		String str = scan.nextLine();
		
		for(int i = str.length(); i > 0; i--) {
			System.out.print(str.charAt(i-1));
		}
		
		scan.close();
		
	}

}
