package Day2;
/*
 * switch(int형 or String형 표현식){
	case 값1;
	실행문1;
	break;
	
	switch~case~break 세트, 다중 조건 시 사용한다.
 */
public class SwitchCaseEx {

	public static void main(String[] args) {
		int jumsu = (int)(Math.random() * 100);
		System.out.println("당신의 점수는:" + jumsu);
		
		switch (jumsu / 10) {
		case 9:// case : 콜론을 쓴다. if (jumsu >=90){}
			System.out.println("당신의 학점은 A입니다.");
			break;// break: 탈출문이다. brㄷak를 만나면 {}블럭을 탈출하고 명령을 끝낸다.
		case 8:// else if(jumsu >=80){}
			System.out.println("당신의 학점은 B입니다.");
			break;
		case 7:// else if(jumsu >=70){}
			System.out.println("당신의 학점은 C입니다.");
			break;
		case 6: // else if(jumsu >=60){}
			System.out.println("당신의 학점은 D입니다.");
			break;
		default: // else{}
			System.out.println("당신의 학점은 F입니다");
			System.out.println("재수강 대상입니다.");
			break;
}

	}

}
