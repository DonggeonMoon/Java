package Day2;
// primenumber : 소수 : 1과 자신만으로 나눠지는 수, 공배수가 2개인 수
// %: 나머지 연산자 값이 0, 배수를 세는 count라는 변수가 누적 수가 2 -> 소수 

public class PrimeNumber {

	public static void main(String[] args) {
		System.out.println("소수를 구합니다.");
		int count; // % 연산자로 나머지가 0인 수를 카운트하는 역할
		int pcount = 0;// 소수가 몇 개인지세어 보기 위해서 선언..
		int acount = 0;// 총 연산 횟수 
				
		for (int i = 1; i<10000; i++) {
			count = 0;// count reset을 해줘야 소수 카운트를 구할 수 있다.
			for (int j = 1; j<=i; j++) {
				if(i % j == 0) {
					count++;
				}// idml 증가만큼 반복한다. i: 1~10000
				acount++;
			}
			
			if(count == 2) {
				pcount++;
				System.out.print(i + " ");
			}
		}
		System.out.println();
		System.out.println("1~10000까지의 소수의 개수는: " + " ");
		System.out.println("1~10000까지의 2중 for 반복 횟수는: " + acount);
	}

}
