package Day2;
//break는 {} 블럭을 탈출한다.



public class BreakEx {

	public static void main(String[] args) {
		for(int i = 0; i<10; i++) {
			if(i == 5) {
				break;
			}
			System.out.println(i);
		}
		
		System.out.println("For문이 종료되었습니다.");

	}

}
