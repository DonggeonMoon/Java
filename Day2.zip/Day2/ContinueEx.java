package Day2;

public class ContinueEx {

	public static void main(String[] args) {
		for(int i = 0; i<10; i++) {
			if (i==5) {
				continue;// 5이면 건너뛰고 다음으로 이동해라. 
			}
			System.out.println(i);
		}
		System.out.println("For 반복문이 종료되었습니다.");
	}

}
