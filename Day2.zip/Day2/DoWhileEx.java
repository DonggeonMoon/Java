package Day2;
/*
do {
	실행문;
	증감식;
while(boolean 조건식);
 */
public class DoWhileEx {

	public static void main(String[] args) {
		int i = 1;
		int sum = 0;
		/*while(i<=10) {
		 	sum = sum + i;
		 	i++;
		 } 기존 while 반복문*/
		do {
			sum = sum + i;
			i++;
		}// 적어도 한 번 이상 실행될 필요가 있을 때 do~while을 사용한다.
		while (i<= 10);
		System.out.println("1에서 10의 합은: " + sum);
		

	}

}
