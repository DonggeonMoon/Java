package Day2;

public class ForStar {

	public static void main(String[] args) {
		int dan = 5;
		for(int i = 0; i < dan ; i++) {
			for (int j = 5; j > i; j--) {
				System.out.print("*");//print(), 쭉 옆으로 연달아서 출력
			}
			System.out.println();//println() , 다음라인으로 이동
		}
		
		
		for(int i = 0; i < dan ; i++) {
			for (int j = 5; i < j;j--) {
				System.out.print(" ");
			}
			for (int j = 0; i > j; j++) {
				System.out.print("*");//print(), 쭉 옆으로 연달아서 출력
			}
			System.out.println();//println() , 다음라인으로 이동
		}

	
		for(int i = 0; i < dan ; i++) {
			for (int j = 0; i > j ;j++) {
				System.out.print(" ");
			}
			for (int j = 5; i < j; j--) {
				System.out.print("*");//print(), 쭉 옆으로 연달아서 출력
			}
			System.out.println();//println() , 다음라인으로 이동
		}
		
	}
}
