package Day2;
/*
if(boolean형 조건식){
	실행구문A;
	.....
} else{
	실행구문B;
	.....
}
 */
public class IfEx1 {

	public static void main(String[] args) {
		int jumsu = (int) (Math.random()*100);
		System.out.println("당신의 점수는: " + jumsu);
		
		if(jumsu >= 60) {// 조건식이 참(true)일 때 실행됨.
			System.out.println("60점 이상을 맞으셨습니다.");
			System.out.println("합격입니다.");
		} else {// 조건식이 거짓(false)일 때 실행됨. 
			System.out.println("점수가 60점 미만입니다.");
			System.out.println("불합격입니다.");
		}
	}

}
