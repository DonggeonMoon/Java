package Day2;
/*
다중 조건
if(boolean형 조건식 1){
	실행문 A;
	......
} else if (boolean형 조건식2){
	실행문 B;
} else if (boolean형 조건식3){
	실행문 C; 
} else {
	실행문 D;
}
 */

public class IfEx2 {

	public static void main(String[] args) {
		int jumsu = (int) (Math.random() * 100);
		System.out.println("당신의 점수는: " + jumsu);
		
		if (jumsu >= 90) {
			System.out.println("당신의 학점은 A입니다.");
		} else if (jumsu >= 80) {
			System.out.println("당신의 학점은 B입니다.");
		} else if (jumsu >= 70) {
			System.out.println("당신의 학점은 C입니다.");
		} else if (jumsu >= 60) {
			System.out.println("당신의 학점은 D입니다.");
		} else {
			System.out.println("당신의 학점은 F입니다.");
			System.out.println("재수강 대상입니다.");
		}

	}

}
