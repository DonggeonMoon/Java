package ClientInfo;

import java.util.ArrayList;
import java.util.Scanner;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.util.*;  
 

 
public class ClientMangement {
//implements Serializable  { 
	
	static ArrayList<ClientInfo> Clientinfo = new ArrayList<ClientInfo>();//ArrayList 객채룰 생성한다. 이는 list종류줌 하나이.
	
	static Scanner scan = new Scanner(System.in); //scan = 입력받다 / 화면을 통해 
	static boolean flag = false;
	static boolean sexFlag =false;
	
	 
	/////////////////////////////////////////////////////////////////////////////////////////////////////	
	public static void clientSave() {
		
		ClientInfo clfo = new ClientInfo();		//set을 이용하여 저장한다.	
		System.out.print("이름 : ");	
		clfo.setName( scan.nextLine().trim());  
		
		sexFlag = true;
		while(sexFlag) {
			
			System.out.print("성별 (M,F)로  표기합니다. ");				//성별을 받아서 성별의 값을 chk한다.
			String  sexfm = scan.nextLine().trim();
			if  (  sexfm.length() <= 0 || sexfm  ==  null)  sexFlag = true ;
			
			if ( sexfm.equalsIgnoreCase("M") ||sexfm.equalsIgnoreCase("F") ) {
				clfo.setSex(sexfm ); sexFlag = false;
			}else {				
				sexFlag = true;
			}
			
		}
		
		
		System.out.print("이메일 : ");			
		clfo.setEmail(scan.nextLine().trim()); 
		
		flag = true;
		while (flag) {
			System.out.print(" 숫자로 생년월일을 입력해주세요: ");	
			
			String select =  scan.nextLine().trim();					
			int select1 = intReturn(select );	
			
			clfo.setBirthday(select1);		 
			}
		
		Clientinfo.add(clfo); 
		printClientInfo(Clientinfo.size()-1)	;  
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////	

	
	public static void printClientInfo(int idx) {
		 
		ClientInfo cls = Clientinfo.get(idx); 
		
		//현재 리스트에 값을 출력하기 위해 출력한다
		System.out.println("*****************************************");
		System.out.println(" 이름은    : " + cls.getName());
		System.out.println(" 성별       : " + cls.getSex());
		System.out.println(" 이메일    : " + cls.getEmail());
		System.out.println(" 출생년도 : " + cls.getBirthday());
		
		System.out.println("*****************************************");
		
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////	
 
	
	public static void allPrintClientInfo( ) {
		
		int count = Clientinfo.size(); 
		ClientInfo ccs ;
		
		if ( count <= 0 ) {
				System.out.println(" 회원정보가 없습니다 ");
		
			} else {
					 	
						
						for(int i=0; i< count ; i++) {	
						
							ccs = Clientinfo.get(i);
							
							//현재 리스트에 값을 출력하기 위해 출력한다
							System.out.println("*****************************************");
							System.out.println(" 이름은    : " + Clientinfo.get(i).getName() );
							System.out.println(" 성별       : " + Clientinfo.get(i).getSex());
							System.out.println(" 이메일    : " +Clientinfo.get(i).getEmail());
							System.out.println(" 출생년도 : " + Clientinfo.get(i).getBirthday());
							
							System.out.println("*****************************************");
					}
		
		}
	}
		
	/////////////////////////////////////////////////////////////////////////////////////////////////////	

	
	
	//해당고객을 지우다.
	public static void deleteNameCardInfo(int idx) {
		//arraylist의 remove메소드를 이용할 수 있다.
		Clientinfo.remove(idx);
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	//SEARCH 해당고객이 존재하는지 찾는다.
	public static int searchNameCardByName() {
		
		System.out.print("이름을 입력하세요 : "); //찿고자 하는 이름을 검색한다
		String name = scan.nextLine().trim(); //입력된 이름을 name에 저장하여
		
		for(int i=0; i< Clientinfo.size(); i++) {
			if(Clientinfo.get(i).getName().equals(name)) { //리스트에 있는 값과 방금 받은 값을 비교한다..
				return i;	//0과 1을 리턴			
			}
		}
		return -1;
	} 
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////	

	
	//예외처리를 하다
	public static int  strChak(String val) {
		//매개변수로 String val을 받는다.
		//들어온값이 q이면 종료됨을 알려준다.
		String str1 = "";
				
		if (val.length() < 0 || val.length() > 1) {
			return 1;
		}else if(val.length() == 1) {
	//한글자가 들어올때엔 
			//현재값을 string으로 받아서 ,을 기준으로 배열에 담아 비교할 수도 있다.
				 String arrString= "I,A,C,S,P,N,Q,D,U,G,F,R,O,J";
				 String[] arradd = arrString.split(",");
				
				
				for(int i =0; i<arradd.length; i++) {
						str1 = arradd[i];						
						if ( val.equalsIgnoreCase(str1)) { 
							return 2;							 
						} 
				} //for문 
				return 1;
	
		}//else if
		return 1;
			 
	}//해당 메소드
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////	

	/*
	public static int  strChak(String val) {
		//매개변수로 String val을 받는다.
		//들어온값이 q이면 종료됨을 알려준다.
		String str1 = "";
				
		if (val.length() < 0 || val.length() > 1) {
			return 1;
		}else if(val.length() == 1) {
	//한글자가 들어올때엔 
			//현재값을 string으로 받아서 ,을 기준으로 배열에 담아 비교할 수도 있다.
				String arr[]= { "I","A","S","U","D","P","N", "C"};
				
				for(int i =0; i<arr.length; i++) {
						str1 =arr[i];						
						if ( val.equalsIgnoreCase(str1)) { 
							return 2;							 
						} 
				} //for문 
				return 1;
	
		}//else if
		return 1;
			 
	}//해당 메소드
	
*/
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////	
		
	
	//해당정보를 UPDATE하라	
	public static void updateNameCardInfo(int idx) {	// 해당인덱스에 값을 Update수정한다.
		
			System.out.println(" 고객정보를 수정합니다........");
			ClientInfo cms = Clientinfo.get(idx); 	//수정하고자 하는 해당 인덱스의 값을 가지고 온다
			
			///////////////////////////////////////////////////////
			System.out.printf(" 이름 (%s)  : " , cms.getName( ));
		 	String name = scan.nextLine().trim();					//입력받은 값의 공백을 제거한다.
			if(name != null && name.length()>=0) { 		 
				cms.setName(name); 					 
			}
			
			System.out.printf(" 성별 (%s) :",  cms.getSex());
			
			
			while(sexFlag) {
				System.out.print("성별 (M,F)로  표기합니다. ");				//성별을 받아서 성별의 값을 chk한다.
				String sex = scan.nextLine().trim();
				
				 	if  (sex.length() <= 0 || sex  ==  null)  sexFlag = true ;
				 
					if (  sex.equalsIgnoreCase("M") || sex.equalsIgnoreCase("F") ) {	cms.setSex(sex ); sexFlag = false;}
					else { sexFlag = true;}
			}
			 
			///////////////////////////////////////////////////////
			System.out.printf(" 이메일  (%s) :" ,  cms.getEmail());
			String email = scan.nextLine().trim();					//입력받은 값의 공백을 제거한다.
			if(email != null && email.length()>=0) { 		 
				cms.setEmail(email); 					 
			}
			///////////////////////////////////////////////////////
			
			System.out.printf(" 출생년도(%d)  : " ,  cms.getBirthday() );
			System.out.println();
			
			while (flag) {
				// 예외처리 메소드 호출문
				System.out.println("숫자로 입력해주세요  : ");
				String select =  scan.nextLine().trim();					
				int select1 = intReturn(select );					 	 
				cms.setBirthday(select1);
				 
			}
			
			printClientInfo(Clientinfo.size()-1);
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////	

	public static int intReturn(String str) {
		
		int selec = 0;
	
		try {
				selec = Integer.parseInt(str); //str을 받아서 무조곤 정수로 반환한다. //이를 통해 문제발생시 catch문으로 이동한다
				flag = false; 
		} catch (NumberFormatException e) {
			flag = true; //그래서 flag의 값을 true를 반환한다. 그럼 while문을 다시 돌게 된다.
			return 0;
		}
		return selec;
	} 
/////////////////////////////////////////////////////////////////////////////////////////////////////	
	

	//파일에 있는 값을 가지고 와서 파일에 다시 뿌려준다.
		public static void FileDownLoading() {
			try {
				//ClientInfo clfo = new ClientInfo();
				
				//File file = new File("C:/javawork/result.txt");
				File file = new File("result.txt");
				FileInputStream fis = new FileInputStream(file);
				InputStreamReader isr = new InputStreamReader(fis);
				BufferedReader br = new BufferedReader(isr);
				//파일을 찾는다, 
							
				
				 Clientinfo.clear();
				String line ="";
				while ((line = br.readLine())!=null) {  
					 
					if (line == null) {break; } //다시파일을 만들다.
					ClientInfo clfo = new ClientInfo();
					 String arr[] = line.toString().trim().split(",") ;
					 clfo.setName(arr[0]);
					 clfo.setSex(arr[1] );
					 clfo.setEmail(arr[2]);
					 Integer a = new Integer(arr[3]);
					
					  clfo.setBirthday(a) ;						 
						 
					 Clientinfo.add(clfo); 
					
					 
					 System.out.println(line.toString()); 
				}
				//배열에 담은 값을 ArrayList에 담다.
				
				
			}catch(Exception e) {e.printStackTrace(); }
		}
		
/////////////////////////////////////////////////////////////////////////////////////////////////////	
		
		public static void FileUpLoadings ( ) {
				//리스트에 있는 값을 파일에 저장한다,
			 	//ArrayList<String> list = new ArrayList<String>();
				//이게 잘되면 예외처리로서 파일이 없으면 생성하기
			   		try {
						
												
						File outFile = new File("result.txt"); //해당파일이 있느지 없느지를 확인해보자  new File("C:/javawork/result.txt")
						boolean isexists =   outFile.exists();
								 
						if (isexists = false ) { outFile.createNewFile(); }					 
						 
						FileOutputStream fos = new FileOutputStream(outFile); //선택된 파일에 쓰기 위해서 파일을 열고
						OutputStreamWriter osw = new OutputStreamWriter(fos); //선택된 파일에 스트림으로 열어서 통로를 만들고 
						BufferedWriter bw = new BufferedWriter(osw);		//버퍼에 실어서 작성하기 위해 
						 
					for(int i = 0; i < Clientinfo.size(); i++) {
						String str =  Clientinfo.get(i).getName() + "," + Clientinfo.get(i).getSex() + "," + 
								Clientinfo.get(i).getEmail() + "," + Clientinfo.get(i).getBirthday()  ;
						
							bw.write(str); //버퍼에 string을 넣는다. 
							bw.newLine();
						}
						bw.flush(); //이걸 해주지 않으면 실제 쓰여지지 않는다. 버퍼에만 썼기 때문에 //버퍼에 써준다.
						System.out.println("저장되었습니다. 확이하세요");
						
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println("에러 발생");
					}
		
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////		
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public static <Clientinfo> void ObjectFileDownLoad()  {
				 
				 
			
			try {
				
				File file = new File("result.bin"); //이렇게 작성하면 이클립스가 깔린곳에 저장한다.
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream isr = new ObjectInputStream(fis);   
			 	 Clientinfo =  (ArrayList<ClientInfo>)isr.readObject(); //배열에이쓴값을 오브젝트화해서 리스트에 저장한다.
			   
			    
			 	isr.close();
				System.out.println("리스트에 저장완료");
			 	System.out.println(Clientinfo.size());
			 	//잘 저장이 되었는지 확인하기 위해서 콘솔창에 뜨워봄			 	
				for (int i = 0; i < Clientinfo.size(); i++) {
						String str =  Clientinfo.get(i).getName() + "," + Clientinfo.get(i).getSex() + "," + 
								Clientinfo.get(i).getEmail() + "," + Clientinfo.get(i).getBirthday()  ;
					System.out.println(str);
					
				} 
				
				
			}catch(Exception e) 
			{e.printStackTrace(); }
			 
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////		
		
		public static void ObjectFileUpload() {
			
		   
			 try {
					
					
					File outFile = new File("result.bin"); //해당파일이 있느지 없느지를 확인해보자  new File("C:/javawork/result.txt")
					boolean isexists =   outFile.exists();
							 
					if (isexists = false ) { outFile.createNewFile(); }					 
					 
					FileOutputStream fos = new FileOutputStream(outFile);
					ObjectOutputStream osw = new ObjectOutputStream(fos);
					osw.writeObject(Clientinfo);
					osw.close();
					System.out.println("저장되었습니다. 확이하세요");
					
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("에러 발생");
				}
			
			
		}
/////////////////////////////////////////////////////////////////////////////////////////////////////		
	
	
	
}


/////////////////////////////////////////////////////////////////////////////////////////////////////		


