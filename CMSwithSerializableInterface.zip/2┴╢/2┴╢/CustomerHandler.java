package ClientInfo;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import ClientInfo.JTable1; 

import java.awt.BorderLayout;
import java.io.IOException;
import java.util.Scanner;	 		
	 
public class CustomerHandler extends Exception {
	
	
	 private static final int EXIT_ON_CLOSE = 0;
	 
	 static Scanner scan = new Scanner(System.in); //스켄어를 통해 값을 입력을 받을 수 있다.
	 static ClientMangement  clm = new ClientMangement();
	 static int index = -1;
	 static String str ="";
	 
	 
	 public static void  questionView() {	//원하는 작업을 호출하는 메소드	 
		 	
		  	System.out.println("****************************************");
			System.out.println(" 원하는 작업을 선택하세요. : ");
			System.out.println(" (I)Insert, (U)Update, (D)Delete,(S)Search, (A)All_Search,  (P)Prev, (N)Next,\n" + 
							   " (O)오브젝트 작업, (J)오브젝트 다운 , \n " + 
							   " (F)파일업, (R)파일다운, G(Graphics), (Q)Quit " );
		  	System.out.println("******************************************");
		   	
		   
			//여기서 예외처리하자
		  	str = scan.next();	//해당값을 받아주어야 한다.
		  	str = str.toUpperCase().trim(); // 해당값을 무조건 대문자로 바꾸어준다.	
		  	
		  	
		    int valueT = ClientMangement.strChak(str);
		   //int valueT = 2;
		   if (str.equalsIgnoreCase("Q")) {  valueT =2;   } 	
			 
			   
	       if (valueT== 1  ) {	// 사용할 수 없는 값을 반환한다
				System.out.println(" 작업 메뉴에 없는 호출정보입니다. 다시 입력해주세요.");				
				questionView(); //재귀함수
				
	       }
				 
		}
		     
		     
		 
		 
	
	 
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException, Exception  {
		//메인에서 호출한다. 		//정보를 입력받는다		
	
		//JTabbedPane tab;

	   //JTable1 j1;

	    
			
			while(true) {
							 
				
							questionView();
							
							switch(str.charAt(0)){ 	// 들어온 값
							//object를 이용한 파일 업로드를 하자 
							case 'O':
									 clm.ObjectFileUpload();
									
									break;
							case 'J':
								clm.ObjectFileDownLoad();
									break;
							
							case 'I':	
									 
									System.out.println(" 고객의 정보를 입력해주세요.");
									clm.clientSave();
									 
									break;	
									
							case 'D':	
									 	index = clm.searchNameCardByName(); 
									
									if (index >= 0 ) {
										System.out.printf(" 고객을 삭제하겠습니다 . ");									
										clm.deleteNameCardInfo(index);
										System.out.println(" 삭제되었습니다. ");
									}else {
										
										System.out.println(" 없는 고객정보 입니다.");
									}
									 
										break;
									
							case 'U': //수정하고자 하는 고객이 있는지를 확인하라
									 
									index = clm.searchNameCardByName();  //고객SEARCHING
									
									if (index >= 0 ) {
										//고객이 존재한다면 해당고객을 update하라										 
										clm.flag = true;
										clm.sexFlag = true;
										clm.updateNameCardInfo(index);										  
										
									}else {
										System.out.println("고객 정보가 없습니다.");
									}
									break;
								
							case 'S':
									 
									//searchClient();
									index = clm.searchNameCardByName();  
									if (index >= 0) {
										clm.printClientInfo(index);	
									}else {
										System.out.println("고객정보가 없습니다.");
									}
									break;
							case 'A':									 
									//모드고객을 출력하자
								clm.allPrintClientInfo();
									break;
							case 'C': //현재고객을 출력하세요.
									if (index <0 ) {
										System.out.println(" 현재 고객이 없습니다. ");
									}else {
										clm.printClientInfo(index);	
									}
									break;
									
							case 'P': //이전고객의 정보를 프린트 할 수 있도록 한다. 									 
									System.out.println("이전 데이타를 출력합니다.");
									if (index <= 0){
										System.out.println("이전데이타가 존재하지 않습니다.");
									}else {
										
										index--;
										clm.printClientInfo(index);										
									}
									break;
									
							case 'N':	
									 
									System.out.println("다음 고객을 출력합니다.");
									if (index >= ClientMangement.Clientinfo.size()-1) {
										System.out.println("더이상의 고객은 존재하지 않습니다.");
									}else {
										index++;
										clm.printClientInfo(index);											
									}
									break;
							case 'Q' :
									 
									System.out.println("프로그램을 종료합니다.");
									System.exit(0);
									
							case 'G':
								
									JTabbedPaneTest jt = new JTabbedPaneTest();
								    jt.setDefaultCloseOperation(EXIT_ON_CLOSE);
								    break;
							case 'F'://파일을 업로드하다
								clm.FileUpLoadings( );
								 break;
							case 'R'://파일을 다운로드하여 콘솔창에 띄워주다.
								clm.FileDownLoading();
								break;
									
							default :
								
									questionView();
									break;
								
							}
							
			
				} //while close 
			
			
		
		}//메인메소드 close	
	

} //현클래스 customerHandler close




