package ClientInfo;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;

import javax.swing.JScrollPane;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
//import javax.swing.text.html.HTMLDocument.Iterator;
import javax.swing.text.html.CSS;

public class JTable1 extends JPanel   
{	 
	JTable table ; 
	JScrollPane sp ; 
	//DefaultTable Model ;
	
		public JTable1(){
    	
	    	ClientInfo ccs = new ClientInfo();
	        String title[] = {"이름", "성별", "이메일", "생년월일"};
	
	        int count = ClientMangement.Clientinfo.size();
	        String data[][] = 	new String [count][4];
	    	
			 
	        System.out.println(count);
	         
	        if ( count <= 0 ) {
				System.out.println(" 고객정보가 없습니다. ");
		
			} else {
				
					 
					for(int i=0; i< count; i++) {
						ccs = ClientMangement.Clientinfo.get(i);
						for (int j=0; j< 4; j++) {
						 
					 	
						 data[i][0] = ccs.getName();
						 data[i][1] = ccs.getSex();
						 data[i][2] = ccs.getEmail();
						 data[i][3] = String.valueOf(ccs.getBirthday());
					 	}
						 
					}	// 이중 for문 close
					
					DefaultTableModel model = new DefaultTableModel(data, title);
					 table = new JTable(model);
					//JTable table = new JTable(data, title);
					 sp = new JScrollPane(table);
						     
			       this.add(sp); 			       
			        
			       DefaultTableCellRenderer tcr = new DefaultTableCellRenderer();
		           tcr.setHorizontalAlignment(SwingConstants.CENTER);     
		           TableColumnModel tcmSchedule = table.getColumnModel();  

			     
		           for (int i = 0; i < tcmSchedule.getColumnCount(); i++) {

		          	 tcmSchedule.getColumn(i).setCellRenderer(tcr); 
		          	 tcmSchedule.getColumn(i).setPreferredWidth(10);
		          	
		           }
			       
			}////else   
	        
    }//JTable1 
		
		
		
			 

 
		

} ////JTable1 class�� �ݴ�.
