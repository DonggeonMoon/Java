package ClientInfo;
import java.io.Serializable; 

public class ClientInfo implements Serializable{
	//이클립스가 이아이디를 생성해준다.
	//Update을 할때 버전을 계속 바꾸어주기 위해 아이디를 만든다.
	//알파버전에서 이 시리얼를 사용했다고 하자 
	//프로그램 개선후 베타버전을 만들시 베타버전 아이디와 구별하여 새로운 버전에서 새로운 아이디를 불러오도록 구분자를 두는것이다.
	//직렬화될때  제외시키는 것이다.transient //보여주기 싫은 은닉화를 위해서 사용한다.
	private String name;
	private String sex;
	private String email;
	private int birthday;
	
	public ClientInfo(String name, String sex, String email, int birthday){
		super();
		this.name = name;
		this.sex = sex;
		this.email= email;
		this.birthday = birthday;
	}

	public ClientInfo() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getBirthday() {
		return birthday;
	}

	public void setBirthday(int birthday) {
		this.birthday = birthday;
	}
	
	
	public String toString() {
			
		String a = "Name = " + name + ", sex= " + sex + ", email = " + email + ", birthday = " + birthday;
		return a;
			
	}
}
