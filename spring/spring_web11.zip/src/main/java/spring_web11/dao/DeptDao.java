package spring_web11.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import spring_web11.dto.DeptDTO;

public class DeptDao implements Dao {
	
	SqlSession ss;
	
	public void setSs(SqlSession ss) {
		this.ss = ss;
	}
	
	@Override
	public List<DeptDTO> selectAll() {
		return ss.selectList("selectAllDept");
	}
	
	@Override
	public void insertOne(DeptDTO deptDTO) {
		
		ss.insert("insertOneDept", deptDTO);		
	}

	@Override
	public DeptDTO selectBoardOne(int deptno) {		
		return ss.selectOne("selectBoardOne",deptno);
	}

	@Override
	public void updateBoard(DeptDTO deptDTO) {
		ss.update("updateBoard",deptDTO);		
	}

	@Override
	public void deleteBoardOne(int deptno) {
		ss.delete("deleteBoardOne", deptno);		
	}

	

	

}
