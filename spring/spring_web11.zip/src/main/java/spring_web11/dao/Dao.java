package spring_web11.dao;

import java.util.List;

import spring_web11.dto.DeptDTO;

public interface Dao {
	public List<DeptDTO> selectAll();
	public void insertOne(DeptDTO deptDTO);
	public DeptDTO selectBoardOne(int deptno);
	public void updateBoard(DeptDTO deptDTO);
	public void deleteBoardOne(int deptno);
}
