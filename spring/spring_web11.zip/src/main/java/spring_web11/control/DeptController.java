package spring_web11.control;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import spring_web11.dao.Dao;
import spring_web11.dto.DeptDTO;

@Controller
public class DeptController {
	@Autowired
	Dao dao;
			
	public void setDao(Dao dao) {
		this.dao = dao;
	}

	@RequestMapping("/deptList")
	public String list(Model model){
		
		List<DeptDTO> list = dao.selectAll();
		
		model.addAttribute("list", list);
		
		return "list";
	}
	
	@RequestMapping("/insert")
	public String processStep1(){
		
		return "insertForm";
	}
	
	@RequestMapping("/insertOk")
	public String processStep2(@ModelAttribute DeptDTO deptDTO) {
		dao.insertOne(deptDTO);
		return "redirect:/deptList";
	}
	
	@RequestMapping("/boardRead")
	public String boardRead(Model model, int deptno) {
		model.addAttribute("data", dao.selectBoardOne(deptno));
		return "boardRead";		
	}
	
	@RequestMapping("/update")
	public String update(Model model, int deptno) {
		model.addAttribute("data", dao.selectBoardOne(deptno));
		return "boardUpdate";		
	}
	
	@RequestMapping("/updateOk")
	public String updateBoard(@ModelAttribute DeptDTO dto) {
		dao.updateBoard(dto);
		return "redirect:/deptList";
	}
	
	@RequestMapping(value="/boardDelete", 
						method=RequestMethod.GET)
	public String boardDelete(@RequestParam int deptno){
			dao.deleteBoardOne(deptno);
			return "redirect:/deptList";
	}
}
