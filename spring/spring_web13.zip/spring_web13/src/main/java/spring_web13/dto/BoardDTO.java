package spring_web13.dto;

public class BoardDTO {
	private String brdno;
	private String brdtitle;
	private String brdwriter;
	private String brdmemo;
	private String brddate;
	
	public BoardDTO() {}
	
	public BoardDTO(String brdno, String brdtitle, String brdwriter, String brdmemo, String brddate) {
		super();
		this.brdno = brdno;
		this.brdtitle = brdtitle;
		this.brdwriter = brdwriter;
		this.brdmemo = brdmemo;
		this.brddate = brddate;
	}

	public String getBrdno() {
		return brdno;
	}

	public void setBrdno(String brdno) {
		this.brdno = brdno;
	}

	public String getBrdtitle() {
		return brdtitle;
	}

	public void setBrdtitle(String brdtitle) {
		this.brdtitle = brdtitle;
	}

	public String getBrdwriter() {
		return brdwriter;
	}

	public void setBrdwriter(String brdwriter) {
		this.brdwriter = brdwriter;
	}

	public String getBrdmemo() {
		return brdmemo;
	}

	public void setBrdmemo(String brdmemo) {
		this.brdmemo = brdmemo;
	}

	public String getBrddate() {
		return brddate;
	}

	public void setBrddate(String brddate) {
		this.brddate = brddate;
	}
		
}
