package spring_web13.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Service;

import spring_web13.dto.BoardDTO;;

public class BoardDao{
	
	SqlSession ss;

	public void setSs(SqlSession ss) {
		this.ss = ss;
	}

	public List<BoardDTO> selectBoardList() throws Exception{	
		return ss.selectList("selectBoardList");
	}
	
	public BoardDTO selectBoardOne(String brdno) throws Exception{
		return ss.selectOne("selectBoardOne", brdno);
	}

	public void insertBoard(BoardDTO dto) throws Exception{
		ss.insert("insertBoard", dto);
	}

	public void updateBoard(BoardDTO dto) throws Exception{
		ss.update("updateBoard",dto);
	}

	public void deleteBoard(String brdno) throws Exception{
		ss.delete("deleteBoardOne",brdno);
	}
	
	
}
