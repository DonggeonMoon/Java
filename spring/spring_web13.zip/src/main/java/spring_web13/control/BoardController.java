package spring_web13.control;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import spring_web13.dao.BoardDao;
import spring_web13.dto.BoardDTO;

@Controller
public class BoardController {
	
	@Autowired
	private BoardDao dao;
	
	@RequestMapping("/viewList")
	public String boardList(Model model) throws Exception{
		List<BoardDTO> list = dao.selectBoardList();
		model.addAttribute("list", list);
		return "boardList";
	}
	
	@RequestMapping("/viewRead")
	public String boardRead(HttpServletRequest request, 
			ModelMap modelMap) throws Exception {
       	String brdno = request.getParameter("brdno");
       	BoardDTO boardInfo = dao.selectBoardOne(brdno);
       	modelMap.addAttribute("boardInfo", boardInfo);
    	return "boardRead";
	}
	
	@RequestMapping("/viewForm")
	public String boardForm() throws Exception{
		return "boardForm";
	}
	
	@RequestMapping("/viewSave")
	public String boardSave(@ModelAttribute BoardDTO boardInfo) throws Exception{
		dao.insertBoard(boardInfo);
		
		return "redirect:/viewList";
	}
	
	@RequestMapping("/viewUpdate")
   	public String boardUpdate(HttpServletRequest request, 
   			ModelMap modelMap) throws Exception {
    	String brdno = request.getParameter("brdno");
    	BoardDTO boardInfo = dao.selectBoardOne(brdno);        
    	modelMap.addAttribute("boardInfo", boardInfo);
    	
        return "boardUpdate";
    }
	
	@RequestMapping("/viewUpdateSave")
   	public String viewsUpdateSave(@ModelAttribute BoardDTO boardInfo) 
   			throws Exception {    	
    	dao.updateBoard(boardInfo);    	
        return "redirect:/viewList";
    }
	
	@RequestMapping("/viewDelete")
   	public String boardDelete(HttpServletRequest request) 
   			throws Exception {
    	String brdno = request.getParameter("brdno");    	
    	dao.deleteBoard(brdno);
        
        return "redirect:/viewList";
	}
	
}
