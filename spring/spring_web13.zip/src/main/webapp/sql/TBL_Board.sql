create tabel TBL_BOARD(
BRDNO number(4),
BRDTITLE varchar2(20),
BRDWRITER varchar2(20),
BRDMEMO varchar2(1000),
BRDDATE date
);

create sequece tbl_seq;

insert into TBL_BOARD(BRDNO, BRDTITLE, BRDWRITER, BRDMEMO, BRDDATE)
values (tbl_seq.NEXTVAL, '11', '11', '11', sysdate);

insert into TBL_BOARD(BRDNO, BRDTITLE, BRDWRITER, BRDMEMO, BRDDATE)
values (tbl_seq.NEXTVAL, '22', '22', '22', sysdate);

insert into TBL_BOARD(BRDNO, BRDTITLE, BRDWRITER, BRDMEMO, BRDDATE)
values (tbl_seq.NEXTVAL, '33', '33', '33', sysdate);

commit;