package spring_web14.dao;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import spring_web14.dto.USER;

@Repository
public class MemberDao {

	@Inject
	private SqlSession ss;
	private static final String NameSpace = "memberMapper.";
	
	public int Login(USER u, HttpSession Hsession) {
		int Id_Search_Result = -1;
		try {
			Id_Search_Result = ss.selectOne(NameSpace + "Login", u);
		}catch(Exception e) {
			e.printStackTrace();
			return -1;
		}
		
		if(Id_Search_Result != 1) return Id_Search_Result;
		
		try {
			USER u_info = ss.selectOne(NameSpace + "Login_Info", u);
			Hsession.setAttribute("u", u_info);
			return 1;
		}catch(Exception e) {
			e.printStackTrace();
			return -2;
		}
	}
	public int Id_Check(USER u) {
		try {
			return ss.selectOne(NameSpace + "Id_Check",  u);
		}catch(Exception e) {
			e.printStackTrace();
			return -1;
		}
	}
	
	public int Register(USER u) {
		int Id_Check_Result = Id_Check(u);
		if(Id_Check_Result !=0)return Id_Check_Result;
		
		try {
			ss.insert(NameSpace + "Register", u);
			return 0;
		}catch(Exception e) {
			e.printStackTrace();
			return -2;
		}
		
	}
}
