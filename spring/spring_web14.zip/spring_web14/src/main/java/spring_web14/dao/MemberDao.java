package spring_web14.dao;

public class MemberDao {

}
