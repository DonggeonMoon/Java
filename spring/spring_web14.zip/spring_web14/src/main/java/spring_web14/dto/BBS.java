package spring_web14.dto;

import java.sql.Timestamp;

public class BBS {
	
	private int b_no;
	private int b_owner;
	private String b_owenernick;
	private String b_title;
	private String b_content;
	private Timestamp b_regdate;
	
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	
	public void setB_owner(int b_owner) {
		this.b_owner = b_owner;
	}
	
	public void setB_owenernick(String b_owenernick) {
		this.b_owenernick = b_owenernick;
	}
	
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	
	public void setB_content(String b_content) {
		this.b_content = b_content;
	}
	
	public void setB_regdate(Timestamp b_regdate) {
		this.b_regdate = b_regdate;
	}	
}
