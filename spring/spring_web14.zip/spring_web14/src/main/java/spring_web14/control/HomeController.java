package spring_web14.control;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.AbstractJsonpResponseBodyAdvice;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring_web14.dto.BBS;
import spring_web14.dto.USER;
import spring_web14.dao.BbsDao;
import spring_web14.dao.MemberDao;

@Controller
public class HomeController {
	
	@Inject
	private MemberDao mdao;
	
	@Inject
	private BbsDao bdao;
	
	@RequestMapping(value="/" , method=RequestMethod.GET)
	public String index() {
		return "index";
	}
	
	@ResponseBody
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public int login(USER u, HttpSession Hsession) {
		return mdao.Login(u, Hsession);
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(HttpSession Hsession) {
		Hsession.removeAttribute("u");
		return "redirect:/";
	}
	
	@RequestMapping(value="/main", method=RequestMethod.GET)
	public String main() {
		return "main";
	}
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String register() {
		return "register";
	}
	
	@ResponseBody
	@RequestMapping(value="/register", method = RequestMethod.POST)
	public int register(USER u) {
		return mdao.Register(u);
	}

}
