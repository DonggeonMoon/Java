package spring_web14.control;

import java.util.List;

import javax.inject.Inject;

import org.springframework.context.annotation.Bean;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.method.annotation.AbstractJsonpResponseBodyAdvice;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import spring_web14.dao.BbsDao;
import spring_web14.dao.MemberDao;
import spring_web14.dto.BBS;
import spring_web14.dto.USER;

@Controller
public class HomeController {
	
	@Inject
	private MemberDao mdao;
	
	@Inject
	private BbsDao bdao;
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String index( ) {
		return "index";
	}
	

	
}
