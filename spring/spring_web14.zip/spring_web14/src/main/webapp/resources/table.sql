DROP TABLE bbs;

CREATE TABLE bbs (
  b_no number(11) CONSTRAINT PK_bbs PRIMARY KEY,
  b_owner number(11) CONSTRAINT u_no REFERENCES users,
  b_title varchar2(50),
  b_content varchar2(1000),
  b_regdate timestamp
);

DROP SEQUENCE bbs_seq;
CREATE SEQUENCE bbs_seq;

INSERT INTO bbs (b_no, b_owner, b_title, b_content, b_regdate) 
VALUES (bbs_seq.NEXTVAl, 1, '�׽�Ʈ', '�׽�Ʈ', '2018-12-06 22:10:26');

DROP TABLE users;

CREATE TABLE users (
  u_no number(11) CONSTRAINT PK_users PRIMARY KEY,
  u_id varchar2(50) UNIQUE NOT NULL,
  u_pw varchar2(255) NOT NULL
);

DROP SEQUENCE users_seq;
CREATE SEQUENCE users_seq;

INSERT INTO users (u_no, u_id, u_pw) 
VALUES (users_seq.NEXTVAl, 'test', 'aa');