create table users(
  2  u_no number(11) constraint PK_users primary key,
  3  u_id varchar2(50) unique not null,
  4  u_pw varchar2(255) not null
  5  );
  
  create sequence user_seq;
  
  create table bbs(
  2  b_no number(11) constraint pk_bbs primary key,
  3  b_owner number(11) constraint u_no references users,
  4  b_title varchar2(50),
  5  b_content varchar2(1000),
  6  b_regdate timestamp
  7  );
  
   create sequence bbs_seq;