package test01;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {
	public static void main(String[] args) {
	BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
	
	Object obj = factory.getBean("b");
	
	TestImple1 t1 = (TestImple1)obj;
	
	t1.drink("홍길동");
	
	Object obj2 = factory.getBean("b2");
	
	TestImple2 t2 = (TestImple2)obj2;
	
	t2.drink("홍길동");
	}
}
