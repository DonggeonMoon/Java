package test07.control;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import test07.dto.MemberDTO;

@Controller
public class RegisterController {

	@RequestMapping("/register/step1.do")
	public String processStep1(){
		
		return "step1";
	}
	
	@RequestMapping("/register/step2.do")
	public String processStep2(HttpServletRequest req){
		
		String ck = req.getParameter("ck");
		if(ck==null){
			return "step1";
		}else {
			return "step2";
		}			
	}

	@RequestMapping("/register/step3.do")
	public String processStep3
	(@ModelAttribute()MemberDTO dto, Model model){
		model.addAttribute("dto", dto);
		return "welcome";
	}
	
	@RequestMapping("/main")
	public String processStep4(){
		return "main";
	}
	
}
