package test06;

public interface Test {
	public String sayHello();
}
