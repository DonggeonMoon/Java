package test04.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test04.dao.DAO;
import test04.dto.TestDTO;

public class UpdateOne {

	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		TestDTO dto = new TestDTO();
		
		String ename = "김수철";
		String job = "사원";
		int sal = 30000000;
		int comm = 100000;
		
		dto.setEname(ename);
		dto.setJob(job);
		dto.setSal(sal);
		dto.setComm(comm);
		
		d.updateOne(dto);
	}
}
