package test05;

public interface Test {
	public void printName();
	public void printEmail();
}
