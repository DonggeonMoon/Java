package test03.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test03.app.Test;

public class DeleteOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		Test dao = context.getBean("dao", Test.class);
		
		String ename = "박철수";
		
		dao.deleteOne(ename);
	}
}
