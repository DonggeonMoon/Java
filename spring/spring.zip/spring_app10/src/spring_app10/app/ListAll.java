package spring_app10.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app10.service.DAO;
import spring_app10.service.DeptDTO;

public class ListAll {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		List<DeptDTO> list = d.selectAll();
		
		for(DeptDTO dto: list) {
			System.out.print("deptno: "+dto.getDeptno());
			System.out.print("\t"+"dname: "+dto.getDname());
			System.out.print("\t"+"loc: "+dto.getLoc());
			System.out.println();
		}
		System.out.println("----------------------------------------------------------");
	}
}
