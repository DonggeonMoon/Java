package spring_app02;

public class CoffeeImple implements Beverage {
	String product;
	public CoffeeImple() {
		product="냉수";		
	}
	
	public CoffeeImple(String product) {
		this.product = product;
	}
	//오버로딩: 같은 클래스에서 같은 메서드 중복정의
	//조건: 매개변수의 개수, 타입이 다를 것.
	//오버라이딩: 부모의 메서드를 자식이 재정의하여 사용
	//조건: 상속. 구현부 다를 것.
	public void drink(String name) {
		System.out.println(name+"님이 "+product+"을/를 마십니다.");
	}
}
