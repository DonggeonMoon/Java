package spring_app11.dao;

import java.util.List;

import spring_app11.dto.EmpDTO;

public interface DAO {
	
	public List<EmpDTO> selectAll();
	public EmpDTO selectOne(int no);
	public void insertOne(EmpDTO dto);
	public void updateOne(EmpDTO dto);
	public void deleteOne(int no);
}
