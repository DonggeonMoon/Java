package spring_app11.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app11.dao.DAO;
import spring_app11.dto.EmpDTO;

public class ListAll {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		List<EmpDTO> list = d.selectAll();
		
		for(EmpDTO empDto:list) {
			System.out.println("empno: "+empDto.getEmpno()+" ename: "+empDto.getEname()+" sal: "+empDto.getSal()+" deptno: "+empDto.getDeptno());
		}
	}
}
