package spring_app11.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ContextAnnotationAutowireCandidateResolver;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app11.dao.DAO;
import spring_app11.dao.EmpDao;
import spring_app11.dto.EmpDTO;

public class SelectOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		EmpDTO empDto = new EmpDTO();
	
		empDto = d.selectOne(7900);
		
		System.out.println("empno: "+empDto.getEmpno()+" ename: "+empDto.getEname()+" sal: "+empDto.getSal()+" deptno: "+empDto.getDeptno());
	}
}
