package spring_aop04;

import org.aopalliance.intercept.MethodInvocation;
import org.aopalliance.intercept.MethodInterceptor;
import org.springframework.util.StopWatch;

public class CheckTime implements MethodInterceptor {

	@Override
	public Object invoke(MethodInvocation invocation) throws Throwable {
		long before = System.currentTimeMillis();
		long after = System.currentTimeMillis();
		
		StopWatch sw = new StopWatch();
		sw.start();
		Object obj = invocation.proceed();
		
		sw.stop();
		
		System.out.println("처리시간: "+ sw.getTotalTimeMillis());
		
		return obj;
	}
	
	
}
