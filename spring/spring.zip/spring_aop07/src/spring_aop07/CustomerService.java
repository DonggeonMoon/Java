package spring_aop07;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
