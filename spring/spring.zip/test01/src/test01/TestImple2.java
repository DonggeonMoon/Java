package test01;

public class TestImple2 implements Test {
	private String product = "카라멜 마끼아또";
	@Override
	public void drink(String name) {
		System.out.println(name+"님이 "+product+"를 마십니다.");		
	}
}
