package test01;

public class TestImple1 implements Test {
	private String product = "카페모카";

	@Override
	public void drink(String name) {
		System.out.println(name+"님이 "+product+"를 마십니다.");
	}
}
