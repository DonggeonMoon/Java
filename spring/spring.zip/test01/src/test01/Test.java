package test01;

public interface Test {
	public void drink(String name);

}
