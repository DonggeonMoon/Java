package spring_aop01;

public interface CustomerService {
	
	public void printName();
	public void printEmail();
}
