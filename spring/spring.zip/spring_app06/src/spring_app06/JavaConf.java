package spring_app06;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConf {
	@Bean
	public PhoneOs phoneOs() {
		PhoneOs po = new PhoneOs();
		po.setName("안드로이드");
		po.setVersion("19버전");
		return po;
	}
	
	@Bean
	public SmartPhone smartPhone() {
		SmartPhone sp = new SmartPhone();
		sp.setOs(phoneOs());
		return sp;
	}
	
}
