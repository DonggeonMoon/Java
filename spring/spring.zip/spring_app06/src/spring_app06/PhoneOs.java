package spring_app06;

public class PhoneOs {
	private String name;
	private String version;
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setVersion(String version) {
		this.version = version;
	}
	
	public void printOs() {
		System.out.println("Os Name:"+name);
	}
	
	public void version() {
		System.out.println("Version:"+version);
	}
	
}
