package spring_app06;

public interface Phone {
	public void call(String callNumber);
	public void sendMsg(String msg);
}
