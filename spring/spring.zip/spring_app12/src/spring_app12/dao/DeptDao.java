package spring_app12.dao;

import java.util.List;

import spring_app12.dto.DeptDTO;
import spring_app12.service.ConnectionManager;

public class DeptDao implements DAO {
	
	ConnectionManager cm;

	public void setCm(ConnectionManager cm) {
		this.cm = cm;
	}

	@Override
	public List<DeptDTO> selectAll() {
		return cm.getFactory().openSession(true).selectList("selectAll");
	}

	@Override
	public DeptDTO selectOne(int deptno) {
		return cm.getFactory().openSession(true).selectOne("selectOneByDept", deptno);
	}

	@Override
	public void insertOne(DeptDTO dto) {
		cm.getFactory().openSession(true).insert("insertOneByDept", dto);
	}

	@Override
	public void updateOne(DeptDTO dto) {
		cm.getFactory().openSession(true).update("updateOneByDept", dto);
	}

	@Override
	public void deleteOne(int deptno) {
		cm.getFactory().openSession(true).delete("deleteOneByDept", deptno);
	}

}
