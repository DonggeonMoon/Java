package spring_app12.dao;

import java.util.List;

import spring_app12.dto.DeptDTO;

public interface DAO {
	
	public List<DeptDTO> selectAll();
	public DeptDTO selectOne(int deptno);
	public void insertOne(DeptDTO dto);
	public void updateOne(DeptDTO dto);
	public void deleteOne(int deptno);
}
