package spring_app12.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app12.dao.DAO;
import spring_app12.dto.DeptDTO;

public class ListAll {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		List<DeptDTO> list = d.selectAll();
		for (DeptDTO dto:list) {
			System.out.println("deptno: "+dto.getDeptno()+"\t"+
								"dname: "+dto.getDname()+"\t"+
								"loc: "+dto.getLoc());	
		}
	}
}

