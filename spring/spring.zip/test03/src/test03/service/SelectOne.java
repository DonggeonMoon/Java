package test03.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test03.app.Test;
import test03.app.TestDTO;

public class SelectOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		Test dao = context.getBean("dao", Test.class);
		
		TestDTO testDTO = dao.selectOne("홍길동");
		
		System.out.print("ename: "+testDTO.getEname());
		System.out.print(", job: "+testDTO.getJob());
		System.out.print(", sal: "+testDTO.getSal());
		System.out.print(", comm: "+testDTO.getComm());
		System.out.println();
	}
}
