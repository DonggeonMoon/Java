package test03.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test03.app.Test;
import test03.app.TestDTO;

public class ListAll {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		Test dao = context.getBean("dao", Test.class);
		
		List<TestDTO> list = dao.selectAll();
		
		for(TestDTO dto: list) {
			System.out.println();
			System.out.print("ename: "+dto.getEname());
			System.out.print("\t"+"job: "+dto.getJob());
			System.out.print("\t"+"sal: "+dto.getSal());
			System.out.print("\t"+"sal: "+dto.getComm());
			System.out.println();
		}
		System.out.println("----------------------------------------------------------");
	}
}

