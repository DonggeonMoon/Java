package test03.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test03.app.Test;
import test03.app.TestDTO;
import test03.app.TestDao;

public class UpdateOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		Test dao = context.getBean("dao", Test.class);
		
		TestDTO testDto = new TestDTO();
		
		String ename = "박철수";
		String job = "수습";
		int sal = 1000000;
		int comm = 50000;
		
		testDto.setEname(ename);
		testDto.setJob(job);
		testDto.setSal(sal);
		testDto.setComm(comm);
		
		dao.updateOne(testDto);
	}
}
