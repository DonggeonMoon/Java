package test03.app;

import java.util.List;

public interface Test {
	
	public List<TestDTO> selectAll();
	public TestDTO selectOne(String ename);
	public void insertOne(TestDTO dto);
	public void updateOne(TestDTO dto);
	public void deleteOne(String ename);
}
