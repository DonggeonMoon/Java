package test03.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {

	ApplicationContext context = new GenericXmlApplicationContext();
	
	TestDao dao = context.getBean("dao", TestDao.class);
}
