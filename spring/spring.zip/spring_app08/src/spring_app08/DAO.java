package spring_app08;

public interface DAO {
	
	public int selectCount();
}
