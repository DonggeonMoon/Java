package spring_aop06;

public interface CustomerService {
	public void printName();
	public void printEmail();
}
