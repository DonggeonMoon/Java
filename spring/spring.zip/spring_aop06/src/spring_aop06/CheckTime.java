package spring_aop06;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.util.StopWatch;

@Aspect //관심사, 보조 업무
public class CheckTime {
	
	@Pointcut("execution (public * *(..))") //관여할 시점, pubilc * * (..) 모든 메서드에 관여
	public void publicTarget() {}
	
	@Around("publicTarget()") //around 앞 뒤에서 실행
	public Object logAround(ProceedingJoinPoint pjp) throws Throwable {
		
		String methodName = pjp.getSignature().getName();
		StopWatch sw = new StopWatch();
		sw.start();
		Object obj = pjp.proceed();
		sw.stop();
		
		System.out.println("처리 시간: "+sw.getTotalTimeSeconds());
		return obj;
	}
	
}

