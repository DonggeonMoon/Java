package spring_aop06;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy
public class JavaConf {
	@Bean
	public CustomerServiceImple cs() {
		CustomerServiceImple csi = new CustomerServiceImple();
		csi.setName("SuperMan");
		csi.setEmail("super@gmail.com");
		return csi;		
	}
	
	@Bean
	public CheckTime ct() {
		CheckTime cct = new CheckTime();
		cct.publicTarget();
		return cct;
	}

}
