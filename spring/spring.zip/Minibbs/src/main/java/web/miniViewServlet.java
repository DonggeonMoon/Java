package web;

public class miniViewServlet {

}
