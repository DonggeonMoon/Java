package web;

public class miniRemoveServlet {

}
