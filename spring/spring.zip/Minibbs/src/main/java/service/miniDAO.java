package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class miniDAO {
	
	private final String DRIVER ="oracle.jdbc.driver.OracleDriver";
	private final String URL = "jdbc:oracle:thin:@localhost";
	private final String USER = "scott";
	private final String PASSWORD = "tiger";
	
	public Connection getConnection() {
		Connection conn=null;
		try {
			Class.forName(DRIVER);
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			System.out.println("conn: "+conn);
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	public List<mini> selectBoardList() {
		List<mini> list = new ArrayList<mini>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from mini order by board_no desc "; 
			conn = this.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			System.out.println("여기1");
			while(rs.next()) {
				mini mini = new mini();
				mini.setBoardNo(rs.getInt(1));
				mini.setBoardPw(rs.getString(2));
				mini.setBoardTitle(rs.getString(3));
				System.out.println("여기2");
				list.add(mini);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			this.close(conn, pstmt, rs);
		}
		return list;
	}
	
	public int selectTotalBoardCount() {
		int rowCount = 0;
		String sql = "select count(*) from mini ";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = this.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				rowCount = rs.getInt(1);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			this.close(conn, pstmt, rs);
		}
		return rowCount;
	}
	
	public mini selectBoardByKey(int boardNo) {
		mini mini = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select board_title "
				+ "from board where board_no=? ";
		try {
			conn = this.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,boardNo);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				mini = new mini();
				mini.setBoardNo(boardNo);
				mini.setBoardTitle(rs.getString("board_title"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			this.close(conn, pstmt, rs);
		}		
		return mini;
	}
	
	public void close(Connection conn, PreparedStatement pstmt) {
		try {
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void close(Connection conn, PreparedStatement pstmt, ResultSet rs) {
		try {
			rs.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
