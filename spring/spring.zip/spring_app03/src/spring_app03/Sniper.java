package spring_app03;

public class Sniper implements Character{

	Weapon w;
	Gun g;
	StunGun s;
	int hp;
	
	public Sniper() {
		hp = 100;
	}
	
	public Sniper(Weapon w, int hp) {
		super();
		this.w = w;
		this.hp = hp;
	}
	
	public void walk() {}
	public void eat(String it) {}
	public void attack(Object obj) {
		System.out.println(obj + "조준하고 호흡을 멈추고 쏜다.");
		w.use();
	}
	public void get(Object obj) {}
	
}
