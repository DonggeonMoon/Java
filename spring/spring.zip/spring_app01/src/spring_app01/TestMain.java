package spring_app01;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {

	public static void main(String[] args) {
		
		/*HelloJp jp = new HelloJp();
		jp.sayHello("나까무라");
		
		Hello h = new HelloJp();//다형성, 상속
		h.sayHello("나까무라");*/
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
		
		
		Hello h = (Hello) factory.getBean("j");
		h.sayHello("나까무라 ");
		
		Object obj1 = factory.getBean("c");
		Hello h1 = (Hello)obj1;
		h1.sayHello("왕서방 ");
		
		Object obj2 = factory.getBean("k");
		Hello h2 = (Hello)obj2;
		h2.sayHello("홍길동 ");
		
		
	}

}
