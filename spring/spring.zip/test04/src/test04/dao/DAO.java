package test04.dao;

import java.util.List;

import test04.dto.TestDTO;

public interface DAO {
	public List<TestDTO> selectAll();
	public TestDTO selectOne(String ename);
	public int insertOne(TestDTO dto);
	public int updateOne(TestDTO dto);
	public int deleteOne(String ename);
}
