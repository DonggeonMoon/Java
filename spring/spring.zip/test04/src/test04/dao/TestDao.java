package test04.dao;

import java.util.List;

import test04.dto.TestDTO;
import test04.service.ConnectionManager;

public class TestDao implements DAO {
	
	ConnectionManager cm;
	
	@Override
	public List<TestDTO> selectAll() {
		return cm.getFactory().openSession(true).selectList("selectAll");
	}

	@Override
	public TestDTO selectOne(String ename) {
		return cm.getFactory().openSession(true).selectOne("selectOneByEname", ename);
	}

	@Override
	public int insertOne(TestDTO dto) {
		return cm.getFactory().openSession(true).insert("insertOneByEname", dto);
	}

	@Override
	public int updateOne(TestDTO dto) {
		return cm.getFactory().openSession(true).update("updateOneByEname", dto);
	}

	@Override
	public int deleteOne(String ename) {
		return cm.getFactory().openSession(true).delete("deleteOneByEname", ename);
	}
}
