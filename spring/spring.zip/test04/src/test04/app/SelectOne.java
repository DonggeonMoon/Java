package test04.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test04.dao.DAO;
import test04.dto.TestDTO;

public class SelectOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		TestDTO dto = d.selectOne("임꺽정");
		
		System.out.println("ename: "+dto.getEname()+" job: "+dto.getJob()+" sal: "+dto.getSal()+" comm: "+dto.getComm());
	}
}
