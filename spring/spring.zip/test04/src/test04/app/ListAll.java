package test04.app;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import test04.dao.DAO;
import test04.dto.TestDTO;

public class ListAll {
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		TestDTO dto = new TestDTO();
		List<TestDTO> list = d.selectAll();
		
		for (TestDTO testDto:list){
			System.out.println("ename: "+testDto.getEname()+" job: "+testDto.getJob()+" sal: "+testDto.getSal()+" comm: "+testDto.getComm());
		}
	}
}
