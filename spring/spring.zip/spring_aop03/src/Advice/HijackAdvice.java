package Advice;

import org.springframework. aop.ThrowsAdvice;

public class HijackAdvice implements ThrowsAdvice {
	
	public void afterThrowing(IllegalArgumentException e) {
		System.out.println("HijackThrow Exception");
	}

}
