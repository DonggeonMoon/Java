package test05;

public class TestImple implements Test {
	
	private String name;
	private String email;
	
	public void setName(String name) {
		this.name = name;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public void printName() {
		try {
			Thread.sleep(3000);
			System.out.println("당신의 이름은 "+name+"입니다.");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void printEmail() {
		System.out.println("당신의 이메일 주소는 "+email+"입니다.");
	}

}
