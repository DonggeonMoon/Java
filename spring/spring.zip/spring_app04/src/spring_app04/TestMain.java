package spring_app04;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
		GreetingImple gi = context.getBean("a", GreetingImple.class);
		gi.printMsg();
		
		Greeting gi1 = context.getBean("a", Greeting.class);
		gi1.printMsg();
		
	}
}
