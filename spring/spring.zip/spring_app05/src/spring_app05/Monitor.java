package spring_app05;

public interface Monitor {
	public void showMonitor();
}
