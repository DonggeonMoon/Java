package spring_app05;

public class Sender {
	
	public void show() {
		System.out.println("sender의 show() method이다.");
	}

}
