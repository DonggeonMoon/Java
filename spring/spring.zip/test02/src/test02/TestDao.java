package test02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TestDao implements Test {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public void init() throws SQLException, ClassNotFoundException {
		//String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost";
		String user = "scott";
		String password = "tiger";
		
		//Class.forName(driver);		
		conn = DriverManager.getConnection(url, user, password);
		System.out.println("conn: "+conn);
	}
	
	public void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public int selectCount() {
		int rowCount = 0;
		String sql = "select count(*) from salgrade";
				
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				System.out.println("행의 수는 "+rs.getInt(1)+"입니다.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowCount;
	}
}
