package spring_aop02;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {
	
	public static void main(String[] args) {
		
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		Customer cs = context.getBean("proxyBean", Customer.class);
		
		cs.printName();
		cs.printEmail();
	}
}
