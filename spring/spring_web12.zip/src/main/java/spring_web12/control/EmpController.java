package spring_web12.control;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import spring_web12.dao.Dao;
import spring_web12.dto.EmpDTO;

@Controller
public class EmpController {
	@Autowired
	Dao dao;
	
	public void setDao(Dao dao) {
		this.dao = dao;
	}
	
	@RequestMapping("/empList")
	public String list(Model model) {
		List<EmpDTO> list = dao.selectAll();
		model.addAttribute("list", list);
		
		return "listAll";
	}
	
	@RequestMapping("/insert")
	public String processStep1() {
		return "insertForm";
	}
	
	@RequestMapping("/insertOk")
	public String processStep2(@ModelAttribute EmpDTO empdto) {
		dao.insertOne(empdto);
		return "redirect:/empList";
	}
	@RequestMapping("/boardRead")
	public String boardRead(Model model, int empno) {
		model.addAttribute("data", dao.selectBoardOne(empno));
		return "boardRead";
	}
	@RequestMapping("/update")
	public String update(Model model, int empno) {
		model.addAttribute("data",dao.selectBoardOne(empno));
		return "boardUpdate";
	}
	@RequestMapping("/updateOk")
	public String updateBoard(@ModelAttribute EmpDTO dto) {
		dao.updateBoard(dto);
		return "redirect:/empList";
	}
	
	@RequestMapping(value="/boardDelete", method=RequestMethod.GET)
	public String boardDelete(@RequestParam int empno) {
		dao.deleteBoardOne(empno);
		return "redirect:/empList";
	}
}
