package spring_web12.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import spring_web12.dto.EmpDTO;

public class EmpDao implements Dao {
	SqlSession ss;
	
	public void setSs(SqlSession ss) {
		this.ss = ss;
	}

	@Override
	public List<EmpDTO> selectAll() {
		return ss.selectList("selectAllEmp");
	}
	
	@Override
	public int insertOne(EmpDTO empdto) {
		int rowCount = ss.insert("insertOneEmp", empdto);
		return rowCount;
	}
	
	@Override
	public EmpDTO selectBoardOne(int empno) {
		return ss.selectOne("selectBoardOne", empno);
	}
	
	@Override
	public int updateBoard(EmpDTO empdto) {
		int rowCount = ss.update("updateBoard", empdto);
		return rowCount;
	}

	@Override
	public int deleteBoardOne(int empno) {
		int rowCount = ss.delete("deleteBoardOne", empno);
		return rowCount;
	}
}
