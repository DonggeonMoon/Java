package spring_web12.dao;

import java.util.List;

import spring_web12.dto.EmpDTO;

public interface Dao {

	public List<EmpDTO> selectAll();
	public int insertOne(EmpDTO dto);
	public EmpDTO selectBoardOne(int empno);
	public int updateBoard(EmpDTO empdto);
	public int deleteBoardOne(int empno);
}
