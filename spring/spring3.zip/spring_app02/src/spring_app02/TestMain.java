package spring_app02;

import org.springframework.beans.factory.BeanFactory; 
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
		
		Object obj = factory.getBean("b");
		System.out.println("Obj: "+obj);
		Beverage b = (Beverage)obj;
		b.drink("꼬마아이");
		
		BeanFactory factory2 = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
		Object obj2 = factory.getBean("c");
		Beverage b2 = (Beverage)obj2;
		b2.drink("홍길동");
	}
	
}
