package spring_app03;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

public class TestMain {

	public static void main(String[] args) {
	
		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("src/app.xml"));
		
		Character ch1 = factory.getBean("sniper", Character.class);
		ch1.attack("도둑넘");
		
		Character ch2 = factory.getBean("p1",Character.class);
		ch2.attack("강도");

	}

}
