package spring_app10.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app10.service.DAO;
import spring_app10.service.DeptDTO;

public class updateOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		DeptDTO deptDto = new DeptDTO();
		
		int deptno = 60;
		String dname = "R&D";
		String loc = "Attlanta";
		
		deptDto.setDeptno(deptno);
		deptDto.setDname(dname);
		deptDto.setLoc(loc);
		
		d.updateOne(deptDto);
	}
}
