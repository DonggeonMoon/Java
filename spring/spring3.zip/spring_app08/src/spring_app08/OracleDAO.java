package spring_app08;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OracleDAO implements DAO {
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public void init() throws SQLException, ClassNotFoundException {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost";
		String user = "scott";
		String password = "tiger";
		
		Class.forName(driver);		
		conn = DriverManager.getConnection(url, user, password);
		System.out.println("conn: "+conn);
	}
	
	public void close() throws SQLException {
		try {
			rs.close();
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		conn.close();
		
	}
	
	@Override
	public int selectCount() {
		int rowCount = 0;
		try {
			String str = "select count(*) cnt from emp ";
			pstmt = conn.prepareStatement(str);
			rs = pstmt.executeQuery();
			rs.next();
			rowCount = rs.getInt("cnt");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rowCount;
	}
}
