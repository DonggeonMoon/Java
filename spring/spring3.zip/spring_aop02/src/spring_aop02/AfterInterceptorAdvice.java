package spring_aop02;

import java.lang.reflect.Method;
import org.springframework.aop.AfterReturningAdvice;

public class AfterInterceptorAdvice implements AfterReturningAdvice {

	@Override
	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
		System.out.println("메서드가 호출된 후에");
		System.out.println("실행됩니다.");
		
	}
	
}
