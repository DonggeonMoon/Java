package spring_app01;

public class HelloCn implements Hello{

	public void sayHello(String name) {
		System.out.println(name + "你好");
	}
}
