package spring_web07;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//이전까지는 하나의 클래스가 하나의 작업밖에 하지 못해서 controller가 많이 필요했다.
//단점을 보완하기 위해 annotation을 사용
//xml에 이 controller만 넣어두만 동작함.
@Controller
public class SelectMenuController {

	@RequestMapping(value = "selectMenu.do")
	public ModelAndView aaa() {//메서드 이름은 아무거나 줘도 상관없음..
		return new ModelAndView("menu", "test", "아무거나");
	}
	
	@RequestMapping(value = "data.do")
	public ModelAndView bbb() {
		return new ModelAndView("menu", "test2", "이것저것");
	}
}
