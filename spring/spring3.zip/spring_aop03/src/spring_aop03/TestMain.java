package spring_aop03;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TestMain {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		Message msg = context.getBean("proxy", Message.class);
		
		msg.printMsg();
		try {
			msg.printThrowException();
		} catch(Exception e) {
			//예외가 발생하지만 아무것도 안함..
		}
	}
	
}
