package spring_aop03;

public interface Message {
	public void printMsg();
	public void printThrowException();
}
