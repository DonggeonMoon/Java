package spring_app04;

public interface Greeting {
	public void printMsg();
}
