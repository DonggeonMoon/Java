package spring_web08;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@RequestMapping(value="/h.do")
	public ModelAndView Hello() {
		return new ModelAndView("test", "msg", "test2");
	}
	
	
	@RequestMapping(value="/hello.do")
	public String aaa(HttpServletRequest req) {
		String data = "Hello Controller";
		req.setAttribute("data", data);
		
		return "index";
	}
	
	@RequestMapping(value="/h2.do")
	public ModelAndView bbb() {
		return new ModelAndView("test", "msg", "test2");
	}
	
}
