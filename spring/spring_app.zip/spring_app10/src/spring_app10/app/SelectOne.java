package spring_app10.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app10.service.DAO;
import spring_app10.service.DeptDTO;

public class SelectOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO dao = context.getBean("dao", DAO.class);
		
		DeptDTO deptDto = dao.selectOne(20);
		 
		System.out.print("deptno: "+deptDto.getDeptno()); 
		System.out.print(", dname: "+deptDto.getDname());
		System.out.print(", loc: "+deptDto.getLoc());
		System.out.println();
	}

}
