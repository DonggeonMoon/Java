package spring_app10.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app10.service.DAO;
import spring_app10.service.DeptDTO;

public class deleteOne {

	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		int deptno = 60;
		
		d.deleteOne(deptno);
	}
}
