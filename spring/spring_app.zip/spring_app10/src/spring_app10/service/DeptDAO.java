package spring_app10.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class DeptDAO implements DAO{
	
	private JdbcTemplate jdbcTemplate;
	ResultSet rs =  null;
	StringBuffer sb = new StringBuffer();
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public List<DeptDTO> selectAll() {
		// TODO Auto-generated method stub
		sb.setLength(0);
		sb.append("select * from dept");
		
		RowMapper<DeptDTO> rm = new RowMapper<DeptDTO>() {
			@Override
			public DeptDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
			
				return new DeptDTO(rs.getInt("deptno"), rs.getString("dname"), rs.getString("loc"));
			}
		};
		List <DeptDTO> list = jdbcTemplate.query(sb.toString(), rm);
		
		return list;
	}

	@Override
	public DeptDTO selectOne(int no) {
		// TODO Auto-generated method stub
		sb.setLength(0);
		sb.append("select deptno, dname, loc from dept where deptno = ?");
		
		RowMapper<DeptDTO> rm = new RowMapper<DeptDTO>() {

			@Override
			public DeptDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
				DeptDTO dto = new DeptDTO(rs.getInt("deptno"), rs.getString("dname"), rs.getString("loc"));
				return dto;
			}
		};
		DeptDTO dto = jdbcTemplate.queryForObject(sb.toString(), rm, no);
		return dto;
}

	@Override
	public void insertOne(DeptDTO dto) {
		// TODO Auto-generated method stub
		sb.setLength(0);
		sb.append("insert into dept(deptno, dname, loc) values(?, ?, ?) ");
		
		int result = jdbcTemplate.update(sb.toString(), dto.getDeptno(), dto.getDname(), dto.getLoc());
		System.out.println("insert result: "+result);
		
	}

	@Override
	public void updateOne(DeptDTO dto) {
		// TODO Auto-generated method stub
		sb.setLength(0);
		sb.append("update dept set dname = ? , loc = ? where deptno = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), dto.getLoc(), dto.getDname(), dto.getDeptno());
		System.out.println("update result: "+result);
	}

	@Override
	public void deleteOne(int no) {
		// TODO Auto-generated method stub
		sb.setLength(0);
		sb.append("delete from dept where deptno = ? ");
		
		int result = jdbcTemplate.update(sb.toString(), no);
		System.out.println("delete result: "+result);
		
	}
}
