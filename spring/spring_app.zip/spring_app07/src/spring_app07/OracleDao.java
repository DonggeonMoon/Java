package spring_app07;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OracleDao implements DAO{

	Connection conn = null;	
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public void init() {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost";
		String user = "scott";
		String password = "tiger";
		try {
			conn = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void close() throws SQLException{
		conn.close();
		System.out.println("종료메서드 호출");
	}
	
	@Override
	public int selectCount() {
		String sql = "select count(*) cnt from dept ";					
		int result = 0;
		
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rs.next();
			result = rs.getInt("cnt");			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
}
