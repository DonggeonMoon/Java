package spring_app07;

public interface DAO {
	public int selectCount();
}
