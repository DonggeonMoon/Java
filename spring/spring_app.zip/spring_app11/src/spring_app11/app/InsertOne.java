package spring_app11.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app11.dao.DAO;
import spring_app11.dto.EmpDTO;

public class InsertOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		EmpDTO dto = new EmpDTO();
		
		int empno = 7901;
		String ename = "양만춘";
		int sal = 2500;
		int deptno = 30;
		
		dto.setEname(ename);
		dto.setEmpno(empno);
		dto.setSal(sal);
		dto.setDeptno(deptno);
		
		d.insertOne(dto);
	}
}
