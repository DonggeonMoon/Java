package spring_app11.dao;

import java.util.List;

import spring_app11.dto.EmpDTO;
import spring_app11.service.ConnectionManager;

public class EmpDao implements DAO {
	
	ConnectionManager cm;
	
	public void setCm(ConnectionManager cm) {
		this.cm = cm;
	}
	@Override
	public List<EmpDTO> selectAll() {
		// TODO Auto-generated method stub
		return cm.getFactory().openSession(true).selectList("selectAll");
	}

	@Override
	public EmpDTO selectOne(int no) {
		// TODO Auto-generated method stub
		return cm.getFactory().openSession(true).selectOne("selectOneByEmp", no);
	}

	@Override
	public void insertOne(EmpDTO dto) {
		// TODO Auto-generated method stub
		cm.getFactory().openSession(true).insert("insertOneByEmp", dto);
		
	}

	@Override
	public void updateOne(EmpDTO dto) {
		// TODO Auto-generated method stub
		cm.getFactory().openSession(true).update("updateOneByEmp", dto);
	}

	@Override
	public void deleteOne(int no) {
		// TODO Auto-generated method stub
		cm.getFactory().openSession(true).delete("deleteOneByEmp", no);
	}
	
}
