package spring_app01;

public class HelloKr implements Hello{

	public void sayHello(String name) {
		System.out.println(name+"안녕하세요.");
	}
}
