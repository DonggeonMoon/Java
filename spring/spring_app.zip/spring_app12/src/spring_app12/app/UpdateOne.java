package spring_app12.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app12.dao.DAO;
import spring_app12.dto.DeptDTO;

public class UpdateOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		DeptDTO deptDto = new DeptDTO();
		
		int deptno = 70;
		String dname  = "DELIVERY";
		String loc = "ATLANTA";
		
		deptDto.setDeptno(deptno);
		deptDto.setDname(dname);
		deptDto.setLoc(loc);
		
		d.updateOne(deptDto);
	}
}
