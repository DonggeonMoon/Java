package spring_app12.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import spring_app12.dao.DAO;
import spring_app12.dto.DeptDTO;

public class SelectOne {
	
	public static void main(String[] args) {
		ApplicationContext context = new GenericXmlApplicationContext("app.xml");
		DAO d = context.getBean("dao", DAO.class);
		
		DeptDTO deptDto = d.selectOne(70);
		
		System.out.println("deptno: "+deptDto.getDeptno()+" dname: "+deptDto.getDname()+" loc:"+deptDto.getLoc());
	}
}
